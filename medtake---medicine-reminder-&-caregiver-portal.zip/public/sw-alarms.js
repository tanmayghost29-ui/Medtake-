/**
 * MedTake Background Alarm Service Worker Script
 * Handles background task execution, alarm triggers, vibration,
 * and lock-screen notification interactions when the app is minimized or device is locked.
 */

// In-memory alarm cache for background evaluation
let scheduledAlarms = [];
let lastFiredKeys = new Set();

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// Helper: Formats current local time as HH:MM and YYYY-MM-DD
function getLocalTimeData() {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return {
    time: `${hours}:${minutes}`,
    date: `${year}-${month}-${day}`,
    fullKey: `${year}-${month}-${day} ${hours}:${minutes}`,
  };
}

// Background checker loop inside service worker
function checkBackgroundAlarms() {
  if (!scheduledAlarms || scheduledAlarms.length === 0) return;
  const { time, fullKey } = getLocalTimeData();

  for (const med of scheduledAlarms) {
    let isDue = false;

    if (med.snooze_until) {
      const snoozeTime = new Date(med.snooze_until).getTime();
      if (snoozeTime <= Date.now()) {
        isDue = true;
      }
    } else if (med.time === time && !lastFiredKeys.has(`${med.id}-${fullKey}`)) {
      isDue = true;
    }

    if (isDue) {
      lastFiredKeys.add(`${med.id}-${fullKey}`);
      showAlarmNotification(med);

      // Notify any currently connected clients
      self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
        clients.forEach((client) => {
          client.postMessage({
            type: "SW_ALARM_DUE",
            medicineId: med.id,
          });
        });
      });
    }
  }
}

// Check every 10 seconds in the background worker
setInterval(checkBackgroundAlarms, 10000);

// Show high-priority lock-screen notification
function showAlarmNotification(med) {
  const patient = med.patient || "Patient";
  const title = `⏰ Medicine Alert: ${med.name}`;
  const body = `Time for ${patient} to take ${med.name} (${med.dose} tablet). Tap to open fullscreen alarm.`;

  const options = {
    body,
    icon: "/pwa-192x192.png",
    badge: "/icon.svg",
    tag: `medtake-alarm-${med.id}`,
    renotify: true,
    requireInteraction: true,
    vibrate: [500, 250, 500, 250, 500, 250, 1000],
    data: {
      medicineId: med.id,
      patient: med.patient,
      name: med.name,
      dose: med.dose,
      url: `/?alarm=${encodeURIComponent(med.id)}`,
    },
    actions: [
      {
        action: "take",
        title: "✓ I Have Taken It",
      },
      {
        action: "snooze",
        title: "⏱ Snooze 5 Min",
      },
    ],
  };

  self.registration.showNotification(title, options).catch((err) => {
    console.warn("[SW] Failed to show notification:", err);
  });
}

// Handle messages sent from the MedTake app
self.addEventListener("message", (event) => {
  if (!event.data) return;

  switch (event.data.type) {
    case "SYNC_ALARMS":
      if (Array.isArray(event.data.medicines)) {
        scheduledAlarms = event.data.medicines;
      }
      break;

    case "TRIGGER_ALARM":
      if (event.data.medicine) {
        showAlarmNotification(event.data.medicine);
      }
      break;

    case "CLEAR_ALARM":
      if (event.data.medicineId) {
        const tag = `medtake-alarm-${event.data.medicineId}`;
        self.registration.getNotifications({ tag }).then((notifications) => {
          notifications.forEach((n) => n.close());
        });
      }
      break;

    case "PING":
      if (event.source) {
        event.source.postMessage({ type: "PONG", timestamp: Date.now() });
      }
      break;

    default:
      break;
  }
});

// Handle notification tap & action buttons on Android lock screen / notification shade
self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  const medId = event.notification.data?.medicineId;
  const action = event.action; // 'take' or 'snooze' or undefined (body tap)

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      // 1. If a MedTake window is already open, focus it and broadcast event
      for (const client of clientList) {
        if ("focus" in client) {
          client.focus();
          client.postMessage({
            type: "NOTIFICATION_ACTION_CLICKED",
            action: action || "open",
            medicineId: medId,
          });
          return;
        }
      }

      // 2. Otherwise open a new window to the alarm route
      if (self.clients.openWindow) {
        let targetUrl = `/?alarm=${encodeURIComponent(medId || "")}`;
        if (action) {
          targetUrl += `&action=${encodeURIComponent(action)}`;
        }
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

// Listen for periodic sync (Android Chromium PWA feature)
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "check-medtake-alarms") {
    event.waitUntil(Promise.resolve(checkBackgroundAlarms()));
  }
});

// Background Sync API for offline queue flushing when network is restored
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-pending-medicine-logs" || event.tag === "medtake-offline-sync") {
    event.waitUntil(
      self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
        clients.forEach((client) => {
          client.postMessage({ type: "TRIGGER_OFFLINE_SYNC" });
        });
      })
    );
  }
});
