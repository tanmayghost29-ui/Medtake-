// MedTake Service Worker for PWA compliance and offline functionality
// Ensures Chrome / Android installs immediately on first visit

const CACHE_NAME = "medtake-shell-v2";
const PRECACHE_ASSETS = [
  "/",
  "/index.html",
  "/manifest.json",
  "/icon.svg",
  "/pwa-192x192.png",
  "/pwa-512x512.png",
  "/pwa-maskable-512x512.png",
  "/apple-touch-icon.png",
  "/sw-alarms.js"
];

// Import background alarms and notification handlers
try {
  importScripts("/sw-alarms.js");
} catch (e) {
  console.warn("[SW] importScripts failed:", e);
}

// 1. Install event: skip waiting immediately
self.addEventListener("install", (e) => {
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn("[SW] Precache non-critical items warning:", err);
      });
    })
  );
});

// 2. Activate event: claim clients immediately
self.addEventListener("activate", (e) => {
  e.waitUntil(
    Promise.all([
      self.clients.claim(),
      caches.keys().then((keys) => {
        return Promise.all(
          keys
            .filter((key) => key !== CACHE_NAME)
            .map((key) => caches.delete(key))
        );
      }),
    ])
  );
});

// 3. Fetch event listener: network fetch with cache fallback
self.addEventListener("fetch", (e) => {
  // Only handle GET requests and skip API / SSE routes
  if (e.request.method !== "GET") return;
  const url = new URL(e.request.url);

  // Skip chrome-extension, internal Vite HMR, and /api routes
  if (
    url.pathname.startsWith("/api/") ||
    url.pathname.includes("@vite") ||
    url.pathname.includes("vite-hmr") ||
    !url.protocol.startsWith("http")
  ) {
    return;
  }

  // Handle request: fetch first, then fallback to cache
  e.respondWith(
    fetch(e.request)
      .then((networkResponse) => {
        if (
          networkResponse &&
          networkResponse.status === 200 &&
          networkResponse.type === "basic"
        ) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(e.request, responseToCache).catch(() => {});
          });
        }
        return networkResponse;
      })
      .catch(() => {
        return caches.match(e.request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          if (e.request.mode === "navigate") {
            return caches.match("/").then((rootMatch) => {
              return rootMatch || caches.match("/index.html");
            });
          }
          return new Response("Offline - MedTake", {
            status: 503,
            statusText: "Service Unavailable",
            headers: new Headers({ "Content-Type": "text/plain" }),
          });
        });
      })
  );
});
