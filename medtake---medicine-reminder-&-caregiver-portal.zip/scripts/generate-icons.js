import fs from 'fs';
import zlib from 'zlib';

function createPng(width, height, drawFn) {
  // RGBA buffer: height scanlines, each scanline has 1 filter byte (0) + width * 4 bytes
  const scanlineLength = 1 + width * 4;
  const rawData = Buffer.alloc(height * scanlineLength);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * scanlineLength;
    rawData[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // 8 bits per channel
  ihdrData[9] = 6; // RGBA
  ihdrData[10] = 0;
  ihdrData[11] = 0;
  ihdrData[12] = 0;
  const ihdrChunk = createChunk('IHDR', ihdrData);

  // IDAT
  const idatChunk = createChunk('IDAT', compressed);

  // IEND
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const crc = crc32(chunk.subarray(4, 8 + len));
  chunk.writeInt32BE(crc, 8 + len);
  return chunk;
}

function crc32(buf) {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  }
  return crc ^ -1;
}

const table = new Int32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let k = 0; k < 8; k++) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  table[i] = c;
}

// Drawer function for medtake brand icon
function drawBrand(x, y, w, h, isMaskable = false) {
  const u = x / w;
  const v = y / h;

  // Background / Base
  let r = 5, g = 150, b = 105, a = 255; // #059669

  // Margin for rounded card
  const margin = isMaskable ? 0 : 0.08;
  const rx = 0.22; // corner radius

  if (!isMaskable) {
    if (u < margin || u > 1 - margin || v < margin || v > 1 - margin) {
      // Check rounded corners
      const cx = u < 0.5 ? margin + rx : 1 - margin - rx;
      const cy = v < 0.5 ? margin + rx : 1 - margin - rx;
      const outsideX = u < margin + rx ? Math.abs(u - cx) : (u > 1 - margin - rx ? Math.abs(u - cx) : 0);
      const outsideY = v < margin + rx ? Math.abs(v - cy) : (v > 1 - margin - rx ? Math.abs(v - cy) : 0);
      if (outsideX > 0 && outsideY > 0 && Math.hypot(outsideX, outsideY) > rx) {
        return [0, 0, 0, 0]; // Transparent
      }
      if (u < margin || u > 1 - margin || v < margin || v > 1 - margin) {
        return [0, 0, 0, 0];
      }
    }
  }

  // Clock Circle
  const clockX = 0.5;
  const clockY = 0.54;
  const clockRadius = 0.30;
  const distClock = Math.hypot(u - clockX, v - clockY);

  // Outer ring of clock (white stroke thickness ~ 0.04)
  if (Math.abs(distClock - clockRadius) < 0.035) {
    return [255, 255, 255, 255];
  }

  // Clock Hand 1 (Hour - 12 o'clock)
  if (Math.abs(u - clockX) < 0.03 && v < clockY && v > clockY - 0.20) {
    return [251, 191, 36, 255]; // Gold #FBBF24
  }

  // Clock Hand 2 (Minute - ~4 o'clock)
  const hand2VecX = 0.18;
  const hand2VecY = 0.11;
  const hand2Len = Math.hypot(hand2VecX, hand2VecY);
  const dot = (u - clockX) * (hand2VecX / hand2Len) + (v - clockY) * (hand2VecY / hand2Len);
  const perp = Math.abs((u - clockX) * (-hand2VecY / hand2Len) + (v - clockY) * (hand2VecX / hand2Len));
  if (dot > 0 && dot < hand2Len && perp < 0.03) {
    return [251, 191, 36, 255];
  }

  // Pill Capsule (Bottom Right angle)
  const pillCenterX = 0.68;
  const pillCenterY = 0.68;
  const distPill = Math.hypot(u - pillCenterX, v - pillCenterY);
  if (distPill < 0.16) {
    // Pill border (white)
    if (distPill > 0.13) {
      return [255, 255, 255, 255];
    }
    // Pill center line
    if (Math.abs(u - pillCenterX) < 0.015) {
      return [255, 255, 255, 255];
    }
    return [245, 158, 11, 255]; // Amber #F59E0B
  }

  // Top cap (white bell notch)
  if (v > 0.13 && v < 0.19 && Math.abs(u - 0.5) < 0.08) {
    return [255, 255, 255, 255];
  }

  return [r, g, b, a];
}

// Write icons to public/
fs.mkdirSync('public', { recursive: true });

fs.writeFileSync('public/pwa-192x192.png', createPng(192, 192, (x, y, w, h) => drawBrand(x, y, w, h, false)));
fs.writeFileSync('public/pwa-512x512.png', createPng(512, 512, (x, y, w, h) => drawBrand(x, y, w, h, false)));
fs.writeFileSync('public/apple-touch-icon.png', createPng(180, 180, (x, y, w, h) => drawBrand(x, y, w, h, false)));
fs.writeFileSync('public/pwa-maskable-512x512.png', createPng(512, 512, (x, y, w, h) => drawBrand(x, y, w, h, true)));

console.log('PWA PNG assets successfully generated in public/ directory!');
