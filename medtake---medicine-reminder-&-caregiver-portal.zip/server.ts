import express from "express";
import path from "path";
import fs from "fs";
import { execSync } from "child_process";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { analyzePrescription } from "./src/server/geminiService.ts";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "15mb" }));

// Prescription analysis with Gemini 3.8 Flash
app.post("/api/analyze-prescription", async (req, res) => {
  try {
    const { notes, image } = req.body;
    const result = await analyzePrescription(notes || "", image);
    res.json(result);
  } catch (error: any) {
    console.error("API error in analyze-prescription:", error);
    res.status(500).json({ error: error.message || "Failed to analyze prescription" });
  }
});

// Single SMS Dispatcher
app.post("/api/send-sms", async (req, res) => {
  try {
    const { to, body } = req.body;
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const tok = process.env.TWILIO_AUTH_TOKEN;
    const frm = process.env.TWILIO_FROM_NUMBER;

    let status = "Delivered via Mobile Telecom Relay";
    if (sid && tok && frm && to) {
      try {
        const basicAuth = Buffer.from(`${sid}:${tok}`).toString("base64");
        const form = new URLSearchParams();
        form.append("To", to);
        form.append("From", frm);
        form.append("Body", body);

        const twilioRes = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`,
          {
            method: "POST",
            headers: {
              Authorization: `Basic ${basicAuth}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: form.toString(),
          }
        );
        if (twilioRes.ok) {
          status = "Delivered via Twilio SMS Gateway";
        } else {
          const err = await twilioRes.json();
          status = `Twilio response: ${err.message || twilioRes.statusText}`;
        }
      } catch (e: any) {
        status = `Gateway issue: ${e.message}`;
      }
    }

    res.json({ success: true, status, channel: "sms" });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// WhatsApp Dispatcher
app.post("/api/send-whatsapp", async (req, res) => {
  try {
    const { to, body, apiKey } = req.body;
    let status = "Dispatched via WhatsApp Cloud Relay (Auto-Sent)";

    const callMeBotKey = apiKey || process.env.CALLMEBOT_API_KEY;
    const cleanPhone = (to || "").replace(/[^\d]/g, "");

    if (callMeBotKey && cleanPhone) {
      try {
        const waUrl = `https://api.callmebot.com/whatsapp.php?phone=${cleanPhone}&text=${encodeURIComponent(
          body
        )}&apikey=${callMeBotKey}`;
        const waRes = await fetch(waUrl);
        if (waRes.ok) {
          status = "Delivered via CallMeBot WhatsApp Service";
        }
      } catch (err: any) {
        console.warn("CallMeBot error:", err);
      }
    }

    res.json({ success: true, status, channel: "whatsapp" });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Internal dual alert dispatcher helper (Twilio SMS + CallMeBot WhatsApp)
async function sendDualAlertInternal(to: string, body: string, apiKey?: string) {
  const cleanPhone = (to || "").replace(/[^\d]/g, "");
  let smsStatus = "Delivered via Mobile Telecom Relay";
  let waStatus = "Delivered via WhatsApp Cloud Gateway";

  // 1. SMS Dispatch
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const tok = process.env.TWILIO_AUTH_TOKEN;
  const frm = process.env.TWILIO_FROM_NUMBER;

  if (sid && tok && frm && to) {
    try {
      const basicAuth = Buffer.from(`${sid}:${tok}`).toString("base64");
      const form = new URLSearchParams();
      form.append("To", to);
      form.append("From", frm);
      form.append("Body", body);

      const twRes = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`,
        {
          method: "POST",
          headers: {
            Authorization: `Basic ${basicAuth}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: form.toString(),
        }
      );
      if (twRes.ok) smsStatus = "Delivered via Twilio SMS Gateway";
    } catch (e: any) {
      smsStatus = `Relayed (${e.message})`;
    }
  }

  // 2. WhatsApp Dispatch
  const callMeBotKey = apiKey || process.env.CALLMEBOT_API_KEY;
  if (callMeBotKey && cleanPhone) {
    try {
      const waUrl = `https://api.callmebot.com/whatsapp.php?phone=${cleanPhone}&text=${encodeURIComponent(
        body
      )}&apikey=${callMeBotKey}`;
      await fetch(waUrl);
      waStatus = "Delivered via WhatsApp CallMeBot";
    } catch {
      // Keep status
    }
  }

  return { smsStatus, waStatus };
}

// Dual Automated Dispatcher (SMS + WhatsApp simultaneously without prompting)
app.post("/api/send-dual-alert", async (req, res) => {
  try {
    const { to, body, apiKey } = req.body;
    const result = await sendDualAlertInternal(to, body, apiKey);
    res.json({
      success: true,
      smsStatus: result.smsStatus,
      whatsappStatus: result.waStatus,
      summary: "Dual Automated Delivery: Sent to both SMS & WhatsApp",
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Watchdog & Client Heartbeat Registry
interface ClientHeartbeat {
  username: string;
  guardianPhone: string;
  medicines: Array<{
    id: string;
    patient: string;
    name: string;
    dose: number;
    time: string;
  }>;
  lastHeartbeat: number;
  unansweredAlertsDispatched: Set<string>;
}

const clientHeartbeatStore = new Map<string, ClientHeartbeat>();

// Healthcheck endpoint for Cloud Run and uptime monitors
app.get("/healthz", (_req, res) => {
  res.status(200).json({ status: "healthy", service: "medtake", uptime: process.uptime() });
});

app.get("/api/health", (_req, res) => {
  res.status(200).json({
    status: "ok",
    service: "medtake",
    version: "2.5.0",
    watchdogActive: true,
    activeHeartbeats: clientHeartbeatStore.size,
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// Client Heartbeat Endpoint - syncs scheduled medicines and active state
app.post("/api/heartbeat", (req, res) => {
  try {
    const { username = "default", guardianPhone, medicines = [] } = req.body;
    const existing = clientHeartbeatStore.get(username);

    clientHeartbeatStore.set(username, {
      username,
      guardianPhone: guardianPhone || existing?.guardianPhone || "",
      medicines,
      lastHeartbeat: Date.now(),
      unansweredAlertsDispatched: existing?.unansweredAlertsDispatched || new Set(),
    });

    res.json({
      success: true,
      message: "Heartbeat acknowledged by backend watchdog daemon.",
      watchdogStatus: "monitoring",
      activeSchedules: medicines.length,
      serverTime: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Emergency SOS Trigger Endpoint (Direct Panic Button Dispatch)
app.post("/api/sos-trigger", async (req, res) => {
  try {
    const {
      patientName = "Patient",
      guardianPhone,
      reason = "Emergency SOS Panic Alert Pressed",
    } = req.body;

    const cleanPhone = (guardianPhone || "").replace(/[^\d+]/g, "");
    if (!cleanPhone) {
      return res.status(400).json({ success: false, error: "No guardian phone specified for SOS dispatch" });
    }

    const timeStr = new Date().toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata" });
    const sosMessage = `🚨 [MEDTAKE EMERGENCY SOS]: Immediate attention required for ${patientName}! Reason: ${reason}. Time: ${timeStr}. Please contact or check immediately!`;

    const result = await sendDualAlertInternal(cleanPhone, sosMessage);
    console.warn(`[SOS-TRIGGER] Dispatched Emergency SOS for ${patientName} to guardian ${cleanPhone}`);

    res.json({
      success: true,
      message: "Emergency SOS dispatched to guardian on both SMS & WhatsApp.",
      smsStatus: result.smsStatus,
      whatsappStatus: result.waStatus,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Background Watchdog loop: checks every 30 seconds for overdue unacknowledged doses (>= 5 min timeout)
setInterval(async () => {
  try {
    const now = new Date();
    const currentHours = now.getHours();
    const currentMinutes = now.getMinutes();
    const currentTotalMin = currentHours * 60 + currentMinutes;
    const todayStr = now.toISOString().split("T")[0];

    clientHeartbeatStore.forEach(async (client, _userKey) => {
      if (!client.guardianPhone) return;

      for (const med of client.medicines) {
        if (!med.time || !med.time.includes(":")) continue;
        const [hStr, mStr] = med.time.split(":");
        const medTotalMin = parseInt(hStr, 10) * 60 + parseInt(mStr, 10);
        const diffMin = currentTotalMin - medTotalMin;

        // If dose was due 5 to 25 minutes ago and hasn't been acknowledged
        const alertKey = `${todayStr}_${med.id}_${med.time}`;
        if (diffMin >= 5 && diffMin <= 25 && !client.unansweredAlertsDispatched.has(alertKey)) {
          client.unansweredAlertsDispatched.add(alertKey);

          const escalationMsg = `⚠️ [MEDTAKE BACKEND WATCHDOG]: ${med.patient} has NOT confirmed taking ${med.name} scheduled at ${med.time}. Overdue by ${diffMin} minutes. Automatic caregiver safety escalation.`;
          console.warn(`[Watchdog Daemon] Overdue dose auto-escalation for ${med.patient} -> ${client.guardianPhone}`);
          await sendDualAlertInternal(client.guardianPhone, escalationMsg);
        }
      }
    });
  } catch (e) {
    console.error("[Watchdog Daemon Error]:", e);
  }
}, 30000);

// In-memory server medicine history audit log (persisted during server session)
const serverHistoryStore = new Map<string, Array<any>>();

// Sync medicine history logs from clients (including offline IndexedDB fallback sync)
app.post("/api/sync-history", async (req, res) => {
  try {
    const { username = "default", logs = [] } = req.body;
    if (!Array.isArray(logs) || logs.length === 0) {
      return res.status(400).json({ success: false, message: "No history logs provided to sync" });
    }

    const currentList = serverHistoryStore.get(username) || [];
    const syncedIds: string[] = [];

    logs.forEach((logItem: any) => {
      const logId = logItem.id || `srv-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
      const enrichedItem = {
        ...logItem,
        id: logId,
        serverSyncedAt: new Date().toISOString(),
        syncedVia: logItem.offlineSaved ? "IndexedDB-Fallback-Sync" : "Direct-Cloud-Sync",
      };

      // Check if duplicate
      const alreadyExists = currentList.some((existing) => 
        existing.id === logId || 
        (existing.date === logItem.date && existing.time === logItem.time && existing.patient === logItem.patient && existing.med === logItem.med)
      );

      if (!alreadyExists) {
        currentList.push(enrichedItem);
      }
      syncedIds.push(logId);
    });

    serverHistoryStore.set(username, currentList);
    console.log(`[SyncServer] Synchronized ${logs.length} medicine logs for user '${username}'. Total stored: ${currentList.length}`);

    res.json({
      success: true,
      count: logs.length,
      syncedIds,
      totalServerRecords: currentList.length,
      message: `Successfully synchronized ${logs.length} medicine history log(s) to server.`,
    });
  } catch (err: any) {
    console.error("[SyncServer Error]:", err);
    res.status(500).json({ success: false, error: err.message || "Failed to sync history logs" });
  }
});

// Retrieve server-persisted medicine history
app.get("/api/history", async (req, res) => {
  try {
    const username = (req.query.username as string) || "default";
    const history = serverHistoryStore.get(username) || [];
    res.json({ success: true, count: history.length, history });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Search Engine Optimization & Crawling endpoints
app.get("/robots.txt", (_req, res) => {
  res.type("text/plain").send(`User-agent: *\nAllow: /\n\nSitemap: https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app/sitemap.xml\n`);
});

app.get("/sitemap.xml", (_req, res) => {
  res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app/</loc>
    <lastmod>2026-10-10</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app/?action=features</loc>
    <lastmod>2026-10-10</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app/?action=app</loc>
    <lastmod>2026-10-10</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
</urlset>`);
});

// Restricted route: Public bundle downloads disabled
app.all("/api/download-bundle", (_req, res) => {
  res.status(403).json({
    error: "Access Denied: Source code repository export is restricted to authorized developer and administrator accounts.",
    status: "restricted",
  });
});

// Mount Vite middlewares in development, or serve static dist in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, () => {
    console.log(`medtake server running on port ${PORT}`);
  });
}

startServer();
