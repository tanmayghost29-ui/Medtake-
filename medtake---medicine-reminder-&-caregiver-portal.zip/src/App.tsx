import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  Home,
  Users,
  Pill,
  History,
  MessageSquare,
  Bell,
  Smartphone,
  Award,
  ShieldCheck,
  Zap,
  Settings,
  Sparkles,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Check,
  CheckCircle,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Plus,
  Trash2,
  Edit3,
  Camera,
  Phone,
  PhoneCall,
  Send,
  ArrowRight,
  Share2,
  Printer,
  RefreshCw,
  X,
  ChevronRight,
  Play,
  Square,
  Info,
  ShieldAlert,
  FileText,
  Download,
  ExternalLink,
  User,
  Lock,
  Mail,
  Eye,
  EyeOff,
  Search,
  Compass,
  Mountain,
  Sliders,
  AlertCircle,
  Heart,
  Building2,
  TrendingUp,
  Stethoscope,
  Watch,
  Cpu,
  Wind,
  Copy,
  Upload,
  Loader2,
  HelpCircle,
  FileCheck,
  Maximize2,
  Minimize2,
  Radio,
  Wifi,
  WifiOff,
  Database,
  MoreVertical,
  LogOut,
  Flame,
} from "lucide-react";
import { LocalNotifications } from "@capacitor/local-notifications";

// ==========================================
// 1. DATA TYPES & INTERFACES
// ==========================================

export type MealTiming =
  | "Before food"
  | "After food"
  | "With food"
  | "Empty stomach"
  | "Anytime";

export interface Patient {
  name: string;
  lang: string;
  disease?: string;
  doctor?: string;
  pharmacy?: string;
  guardian_phone?: string;
  avatar?: string | null;
}

export interface Medicine {
  id: string;
  patient: string;
  name: string;
  dose: number;
  stock: number;
  time: string; // "HH:MM" 24hr format
  meal_timing: MealTiming;
  ringtone: string;
  photo?: string | null;
  snooze_until?: string | null;
  last_fired?: string | null;
}

export interface HistoryItem {
  id?: string;
  time: string;
  date: string;
  patient: string;
  med: string;
  status: string;
  syncStatus?: "synced" | "pending" | "offline";
  offlineSaved?: boolean;
  syncedAt?: string;
}

export type AlertChannel = "sms" | "whatsapp" | "dual";

export interface SmsLogItem {
  id?: string;
  time: string;
  to: string;
  body: string;
  status: string;
  channel?: AlertChannel;
  whatsappUrl?: string;
  smsUrl?: string;
}

export interface GuardianSettings {
  autoSendSms: boolean;
  autoSendWhatsApp: boolean;
  notifyOnTaken: boolean;
  notifyOnSnooze: boolean;
  notifyOnMissed: boolean;
  notifyOnLowStock: boolean;
  callMeBotApiKey?: string;
  guardian_phone?: string;
}

export interface UserData {
  username: string;
  email: string;
  guardian_phone?: string;
  patients: Record<string, Patient>;
  medicines: Medicine[];
  history: HistoryItem[];
  sms_outbox: SmsLogItem[];
  guardian_settings?: GuardianSettings;
}

export interface LanguageInfo {
  code: string;
  text: string;
}

export interface RingtoneInfo {
  freq: number;
  type: OscillatorType;
  pattern: number[];
}

export interface PresetAvatar {
  id: string;
  name: string;
  url: string;
  bgColor: string;
}

export interface MountainScene {
  id: string;
  name: string;
  subtitle: string;
  imageUrl: string;
  theme: "day" | "sunset" | "night" | "mist";
  accentColor: string;
}

export type FilmGrade =
  | "portra"
  | "velvia"
  | "teal_orange"
  | "noir"
  | "natural";

export interface FilmSettingsState {
  grainIntensity: "none" | "subtle" | "cinema35mm" | "heavy";
  colorGrade: FilmGrade;
  anamorphicBars: boolean;
  mountainBreezeActive: boolean;
  breezeVolume: number;
}

export interface SyncStatus {
  isOnline: boolean;
  pendingCount: number;
  lastSyncTime: string | null;
  isSyncing: boolean;
}

// ==========================================
// 2. CONSTANTS (LANGUAGES, RINGTONES, AVATARS, SCENES)
// ==========================================

export const RINGTONES: Record<string, RingtoneInfo> = {
  "Digital Clock Beep": {
    freq: 880,
    type: "sawtooth",
    pattern: [0, 250, 500, 750],
  },
  "Loud Emergency Siren": {
    freq: 1200,
    type: "square",
    pattern: [0, 200, 400, 600, 800],
  },
  "Gentle Hospital Chime": {
    freq: 523.25,
    type: "sine",
    pattern: [0, 400, 800],
  },
  "Zen Singing Bowl": {
    freq: 432,
    type: "sine",
    pattern: [0, 600, 1200],
  },
  "Soft Marimba Pulse": {
    freq: 659.25,
    type: "triangle",
    pattern: [0, 220, 440, 660],
  },
};

export const RINGTONE_LIST = Object.keys(RINGTONES);

export const MEAL_OPTIONS: MealTiming[] = [
  "Before food",
  "After food",
  "With food",
  "Empty stomach",
  "Anytime",
];

export const LOW_STOCK_LIMIT = 3;
export const SNOOZE_MINUTES = 5;

export const LANGUAGES: Record<string, LanguageInfo> = {
  "English": {
    code: "en-US",
    text: "Hey {name}, it's time to take your medicine. Please take your medicine, {med}, {dose}.",
  },
  "Kannada (ಕನ್ನಡ)": {
    code: "kn-IN",
    text: "ಹಲೋ {name}, ನಿಮ್ಮ ಔಷಧಿಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುವ ಸಮಯವಾಯಿತು. ದಯವಿಟ್ಟು {med} ತೆಗೆದುಕೊಳ್ಳಿ, ಪ್ರಮಾಣ: {dose}.",
  },
  "Hindi (हिन्दी)": {
    code: "hi-IN",
    text: "नमस्ते {name}, आपके दवाई लेने का समय हो गया है। कृपया {med} लें, मात्रा: {dose}।",
  },
  "Tamil (தமிழ்)": {
    code: "ta-IN",
    text: "வணக்கம் {name}, உங்கள் மருந்தை உட்கொள்ளும் நேரம் வந்துவிட்டது. தயவுசெய்து {med} எடுத்துக் கொள்ளுங்கள், அளவு: {dose}.",
  },
  "Telugu (తెలుగు)": {
    code: "te-IN",
    text: "హలో {name}, మీ మందులు వేసుకునే సమయం అయింది. దయచేసి మీ ఔషధం {med}, మోతాదు: {dose} వేసుకోండి.",
  },
  "Malayalam (മലയാളം)": {
    code: "ml-IN",
    text: "ഹലോ {name}, നിങ്ങളുടെ മരുന്ന് കഴിക്കാനുള്ള സമയമായി. ദയവായി {med}, {dose} കഴിക്കുക.",
  },
  "Marathi (मराठी)": {
    code: "mr-IN",
    text: "नमस्कार {name}, तुमची औषध घेण्याची वेळ झाली आहे. कृपया {med} घ्या, प्रमाण: {dose}.",
  },
  "Gujarati (ગુજરાતી)": {
    code: "gu-IN",
    text: "નમસ્તે {name}, તમારી દવા લેવાનો સમય થઈ ગયો છે. કૃપા કરીને {med} લો, માત્રા: {dose}.",
  },
  "Bengali (বাংলা)": {
    code: "bn-IN",
    text: "নমস্কার {name}, আপনার ওষুধ খাওয়ার সময় হয়েছে। অনুগ্রহ করে {med} খান, মাত্রা: {dose}।",
  },
  "Punjabi (ਪੰਜਾਬੀ)": {
    code: "pa-IN",
    text: "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ {name}, ਤੁਹਾਡੀ ਦਵਾਈ ਲੈਣ ਦਾ ਸਮਾਂ ਹੋ ਗਿਆ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ {med} ਲਵੋ, ਖੁਰਾਕ: {dose}.",
  },
  "Odia (ଓଡ଼ିଆ)": {
    code: "or-IN",
    text: "ନମସ୍କାର {name}, ଆପଣଙ୍କର ଔଷଧ ଖାଇବାର ସମୟ ହୋଇଛି। ଦୟାକରି {med} ଖାଆନ୍ତୁ, ମାତ୍ରା: {dose}।",
  },
  "Assamese (অসমীয়া)": {
    code: "as-IN",
    text: "নমস্কাৰ {name}, আপোনাৰ ঔষধ খোৱাৰ সময় হৈছে। অনুগ্ৰহ কৰি {med} খাওক, মাত্ৰা: {dose}।",
  },
  "Urdu (اردو)": {
    code: "ur-IN",
    text: "ہیلو {name}، آپ کی دوا لینے کا وقت ہو گیا ہے۔ براہ کرم {med} لیں، خوراک: {dose}۔",
  },
  "Sanskrit (संस्कृतम्)": {
    code: "sa-IN",
    text: "नमस्ते {name}, भवतः औषधसेवनस्य समयः जातः। कृपया {med} स्वीकरोतु, मात्रा: {dose}।",
  },
  "Konkani (कोंकणी)": {
    code: "kok-IN",
    text: "नमस्कार {name}, तुजें वखद घेवपाचो वेळ जालो. उपकार करून {med} घे, प्रमाण: {dose}.",
  },
  "Maithili (मैथिली)": {
    code: "mai-IN",
    text: "प्रणाम {name}, अहाँक दवाई लेबाक समय भ' गेल अछि। कृपया {med} लिअ', मात्रा: {dose}।",
  },
  "Kashmiri (کٲشُر / कश्मीरी)": {
    code: "ks-IN",
    text: "سلام {name}، تۄہہِ چھُو دَوا کھؠنُک وَقٕت آمُت۔ مہرَبانی کٔرِتھ کھؠو {med}، خوراک: {dose}۔",
  },
  "Nepali (नेपाली)": {
    code: "ne-NP",
    text: "नमस्ते {name}, तपाईंको औषधि लिने समय भएको छ। कृपया {med} लिनुहोस्, मात्रा: {dose}।",
  },
  "Sindhi (سنڌي / सिन्धी)": {
    code: "sd-IN",
    text: "سلام {name}، توهان جي دوا وٺڻ جو وقت ٿي ويو آهي. مهرباني ڪري {med} وٺو، مقدار: {dose}.",
  },
  "Dogri (डोगरी)": {
    code: "doi-IN",
    text: "नमस्ते {name}, तुंदी दवाई लेने दा टेम होई गेआ ऐ। कृपया {med} लैओ, मात्रा: {dose}।",
  },
  "Bodo (बड़ो)": {
    code: "brx-IN",
    text: "खुमबिला {name}, नोंनि मुलु लानि समा जाबाय। अननानै {med} लादो, बिबां: {dose}।",
  },
  "Santali (ᱥᱟᱱᱛᱟᱲᱤ)": {
    code: "sat-IN",
    text: "ᱡᱚᱦᱟᱨ {name}, ᱟᱢᱟᱜ ᱨᱟᱱ ᱡᱚᱢ ᱚᱠᱛᱚ ᱦᱩᱭ ᱮᱱᱟ। ᱫᱟᱭᱟᱠᱟᱛᱮ {med} ᱡᱚᱢ ᱢᱮ, ᱦᱟᱹᱴᱤᱧ: {dose}।",
  },
  "Manipuri (মৈতৈলোন্)": {
    code: "mni-IN",
    text: "খোৰুমজৰি {name}, নহাক্কী হিদাক চাবগী মতম ওইরে। চানবীদুনা {med} চাবিয়ু, চাবগী চাং: {dose}।",
  },
};

export const LANGUAGE_LIST = Object.keys(LANGUAGES);

export function formatVoiceMessage(
  langKey: string,
  patientName: string,
  medName: string,
  doseCount: number
): { text: string; code: string } {
  const lang = LANGUAGES[langKey] || LANGUAGES["English"];
  const doseStr = `${doseCount} tablet${doseCount > 1 ? "s" : ""}`;
  const text = lang.text
    .replace("{name}", patientName)
    .replace("{med}", medName)
    .replace("{dose}", doseStr);
  return { text, code: lang.code };
}

export const PRESET_AVATARS: PresetAvatar[] = [
  {
    id: "elder-woman-1",
    name: "Grandmother (Kamala)",
    bgColor: "bg-rose-100 text-rose-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23FCE7F3'/%3E%3Ccircle cx='50' cy='42' r='20' fill='%23F472B6'/%3E%3Ccircle cx='50' cy='38' r='18' fill='%23FDE047'/%3E%3Cpath d='M30,36 C30,22 70,22 70,36 C70,28 65,22 50,22 C35,22 30,28 30,36 Z' fill='%239CA3AF'/%3E%3Ccircle cx='43' cy='40' r='2' fill='%231F2937'/%3E%3Ccircle cx='57' cy='40' r='2' fill='%231F2937'/%3E%3Ccircle cx='50' cy='36' r='2' fill='%23DC2626'/%3E%3Cpath d='M44,47 Q50,52 56,47' stroke='%23DC2626' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M20,95 C25,65 75,65 80,95 Z' fill='%23BE185D'/%3E%3Cpath d='M35,70 L65,70 L50,95 Z' fill='%23FBCFE8'/%3E%3C/svg%3E",
  },
  {
    id: "elder-man-1",
    name: "Grandfather (Sharma)",
    bgColor: "bg-amber-100 text-amber-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23FEF3C7'/%3E%3Ccircle cx='50' cy='42' r='20' fill='%23FCD34D'/%3E%3Cpath d='M28,34 C28,18 72,18 72,34 C68,26 62,22 50,22 C38,22 32,26 28,34 Z' fill='%23E5E7EB'/%3E%3Crect x='36' y='36' width='11' height='8' rx='2' stroke='%234B5563' stroke-width='2' fill='none'/%3E%3Crect x='53' y='36' width='11' height='8' rx='2' stroke='%234B5563' stroke-width='2' fill='none'/%3E%3Cline x1='47' y1='40' x2='53' y2='40' stroke='%234B5563' stroke-width='2'/%3E%3Cpath d='M40,50 Q50,55 60,50' stroke='%239CA3AF' stroke-width='4' fill='none' stroke-linecap='round'/%3E%3Cpath d='M18,95 C22,64 78,64 82,95 Z' fill='%23D97706'/%3E%3Cpath d='M45,68 L55,68 L50,95 Z' fill='%23FEF3C7'/%3E%3C/svg%3E",
  },
  {
    id: "young-woman-1",
    name: "Daughter (Ananya)",
    bgColor: "bg-teal-100 text-teal-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23CCFBF1'/%3E%3Cpath d='M25,48 C25,20 75,20 75,48 C75,70 65,75 50,75 C35,75 25,70 25,48 Z' fill='%231F2937'/%3E%3Ccircle cx='50' cy='44' r='18' fill='%23FDE68A'/%3E%3Ccircle cx='43' cy='43' r='2.5' fill='%23111827'/%3E%3Ccircle cx='57' cy='43' r='2.5' fill='%23111827'/%3E%3Cpath d='M45,51 Q50,56 55,51' stroke='%23E11D48' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M18,95 C24,65 76,65 82,95 Z' fill='%230D9488'/%3E%3C/svg%3E",
  },
  {
    id: "adult-man-1",
    name: "Father / Adult Male",
    bgColor: "bg-sky-100 text-sky-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23E0F2FE'/%3E%3Cpath d='M30,30 C30,18 70,18 70,30 Z' fill='%23374151'/%3E%3Ccircle cx='50' cy='44' r='19' fill='%23FDE047'/%3E%3Ccircle cx='43' cy='42' r='2.5' fill='%231F2937'/%3E%3Ccircle cx='57' cy='42' r='2.5' fill='%231F2937'/%3E%3Cpath d='M44,52 Q50,56 56,52' stroke='%23374151' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M16,95 C22,66 78,66 84,95 Z' fill='%230284C7'/%3E%3Cpath d='M46,67 L54,67 L50,95 Z' fill='%23BAE6FD'/%3E%3C/svg%3E",
  },
  {
    id: "adult-woman-1",
    name: "Mother / Adult Female",
    bgColor: "bg-purple-100 text-purple-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23F3E8FF'/%3E%3Cpath d='M26,35 C26,18 74,18 74,35 C74,58 70,68 50,68 C30,68 26,58 26,35 Z' fill='%234C1D95'/%3E%3Ccircle cx='50' cy='43' r='18' fill='%23FDE047'/%3E%3Ccircle cx='43' cy='42' r='2.5' fill='%231F2937'/%3E%3Ccircle cx='57' cy='42' r='2.5' fill='%231F2937'/%3E%3Cpath d='M44,51 Q50,55 56,51' stroke='%239333EA' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M18,95 C24,65 76,65 82,95 Z' fill='%237E22CE'/%3E%3C/svg%3E",
  },
  {
    id: "child-1",
    name: "Child / Kid",
    bgColor: "bg-emerald-100 text-emerald-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23D1FAE5'/%3E%3Ccircle cx='50' cy='44' r='19' fill='%23FDE68A'/%3E%3Cpath d='M30,32 C30,18 70,18 70,32 Z' fill='%23B45309'/%3E%3Ccircle cx='42' cy='43' r='3' fill='%231F2937'/%3E%3Ccircle cx='58' cy='43' r='3' fill='%231F2937'/%3E%3Cpath d='M42,52 Q50,60 58,52' stroke='%23DC2626' stroke-width='2.5' fill='none' stroke-linecap='round'/%3E%3Cpath d='M20,95 C26,68 74,68 80,95 Z' fill='%23059669'/%3E%3C/svg%3E",
  },
];

export const MOUNTAIN_SCENES: MountainScene[] = [
  {
    id: "alpine_dawn",
    name: "Swiss Alpine Dawn",
    subtitle: "Golden morning light on snow-capped summits & glacial valleys",
    imageUrl:
      "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=2000&q=85",
    theme: "day",
    accentColor: "#10b981",
  },
  {
    id: "himalayan_sunset",
    name: "Himalayan Alpenglow",
    subtitle: "Warm amber & violet twilight over towering peaks",
    imageUrl:
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=2000&q=85",
    theme: "sunset",
    accentColor: "#f59e0b",
  },
  {
    id: "misty_pines",
    name: "Misty Alpine Forest",
    subtitle: "Emerald pine ridge enveloped in rolling morning fog",
    imageUrl:
      "https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?auto=format&fit=crop&w=2000&q=85",
    theme: "mist",
    accentColor: "#059669",
  },
  {
    id: "cosmic_night",
    name: "Cosmic Mountain Summit",
    subtitle: "Starry Milky Way sky over silent jagged ridges",
    imageUrl:
      "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=2000&q=85",
    theme: "night",
    accentColor: "#38bdf8",
  },
  {
    id: "glacial_lake",
    name: "Turquoise Glacial Valley",
    subtitle: "Mirror reflection of alpine summits in glacial waters",
    imageUrl:
      "https://images.unsplash.com/photo-1434725039720-aaad6dd32dfe?auto=format&fit=crop&w=2000&q=85",
    theme: "day",
    accentColor: "#06b6d4",
  },
];

export const PERMANENT_SHARED_URL =
  "https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app";

// ==========================================
// 3. STORAGE, AUTH & URL UTILITIES
// ==========================================

const DB_KEY = "medtake_web_db_v1";
const SESSION_USER_KEY = "medtake_active_user";

interface AppDatabase {
  users: Record<string, UserData & { passwordPlain?: string }>;
}

export const DEFAULT_GUARDIAN_SETTINGS: GuardianSettings = {
  autoSendSms: true,
  autoSendWhatsApp: true,
  notifyOnTaken: true,
  notifyOnSnooze: true,
  notifyOnMissed: true,
  notifyOnLowStock: true,
  callMeBotApiKey: "",
};

export function normalizePhoneNumber(raw: string): string {
  if (!raw) return "";
  let digits = raw.replace(/[^\d+]/g, "").trim();
  if (digits.startsWith("+")) return digits;
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 12 && digits.startsWith("91")) return `+${digits}`;
  return digits.length > 0 ? `+${digits}` : "";
}

export function createSmsIntentUrl(phoneNumber: string, message: string): string {
  const clean = normalizePhoneNumber(phoneNumber);
  if (!clean) return "";
  return `sms:${clean}?body=${encodeURIComponent(message)}`;
}

export function createWhatsAppUrl(phoneNumber: string, message: string): string {
  const clean = normalizePhoneNumber(phoneNumber).replace(/\+/g, "");
  if (!clean) return "";
  return `https://wa.me/${clean}?text=${encodeURIComponent(message)}`;
}

export function createPhoneCallUrl(phoneNumber: string): string {
  const clean = normalizePhoneNumber(phoneNumber);
  return clean ? `tel:${clean}` : "";
}

export function loadDatabase(): AppDatabase {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.users === "object") return parsed;
    }
  } catch (e) {
    console.error("Failed to load local DB", e);
  }
  const initialDb: AppDatabase = { users: {} };
  saveDatabase(initialDb);
  return initialDb;
}

export function saveDatabase(db: AppDatabase): void {
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
  } catch (e) {
    console.error("Failed to save local DB", e);
  }
}

export function getActiveUsername(): string {
  const stored = localStorage.getItem(SESSION_USER_KEY);
  if (!stored || !stored.trim()) return "";
  const clean = stored.trim().toLowerCase();
  const db = loadDatabase();
  for (const uname of Object.keys(db.users)) {
    if (uname.toLowerCase() === clean) return uname;
  }
  localStorage.removeItem(SESSION_USER_KEY);
  return "";
}

export function setActiveUsername(username: string | null): void {
  if (username && username.trim()) {
    localStorage.setItem(SESSION_USER_KEY, username.trim());
  } else {
    localStorage.removeItem(SESSION_USER_KEY);
  }
}

export function getUserData(username: string): UserData {
  if (!username || !username.trim()) {
    return {
      username: "",
      email: "",
      guardian_phone: "",
      patients: {},
      medicines: [],
      history: [],
      sms_outbox: [],
      guardian_settings: { ...DEFAULT_GUARDIAN_SETTINGS },
    };
  }
  const clean = username.trim().toLowerCase();
  const db = loadDatabase();
  let user: (UserData & { passwordPlain?: string }) | undefined = db.users[username];
  if (!user) {
    for (const [k, u] of Object.entries(db.users)) {
      if (k.toLowerCase() === clean || (u.email && u.email.toLowerCase() === clean)) {
        user = u;
        break;
      }
    }
  }
  if (!user) {
    const freshUser: UserData & { passwordPlain?: string } = {
      username: username.trim(),
      email: "",
      guardian_phone: "",
      patients: {},
      medicines: [],
      history: [],
      sms_outbox: [],
      guardian_settings: { ...DEFAULT_GUARDIAN_SETTINGS },
    };
    db.users[freshUser.username] = freshUser;
    saveDatabase(db);
    user = freshUser;
  }
  return {
    username: user.username,
    email: user.email || "",
    guardian_phone: user.guardian_phone || "",
    patients: user.patients || {},
    medicines: user.medicines || [],
    history: user.history || [],
    sms_outbox: user.sms_outbox || [],
    guardian_settings: user.guardian_settings || { ...DEFAULT_GUARDIAN_SETTINGS },
  };
}

export function saveUserData(data: UserData): void {
  if (!data.username || !data.username.trim()) return;
  const db = loadDatabase();
  const uname = data.username.trim();
  const existing = db.users[uname] || {};
  db.users[uname] = {
    ...existing,
    ...data,
    username: uname,
  };
  saveDatabase(db);
}

export function registerUser(
  nameOrUsername: string,
  email: string,
  password: string
): { success: boolean; username?: string; message?: string } {
  const cleanName = (nameOrUsername || "").trim();
  const cleanEmail = (email || "").trim().toLowerCase();
  const cleanPass = (password || "").trim();

  if (!cleanName) return { success: false, message: "Please enter your name or username." };
  if (!cleanEmail || !cleanEmail.includes("@") || !cleanEmail.includes(".")) {
    return { success: false, message: "Please enter a valid email address." };
  }
  if (!cleanPass) return { success: false, message: "Please enter a password." };
  if (cleanPass.length < 6) return { success: false, message: "Password must be at least 6 characters long." };

  const db = loadDatabase();
  for (const [u, val] of Object.entries(db.users)) {
    if (u.toLowerCase() === cleanName.toLowerCase()) {
      return { success: false, message: "An account with this name already exists. Please sign in." };
    }
    if (val.email && val.email.trim().toLowerCase() === cleanEmail) {
      return { success: false, message: "An account with this email already exists. Please sign in." };
    }
  }

  const newUser: UserData & { passwordPlain: string } = {
    username: cleanName,
    email: cleanEmail,
    passwordPlain: cleanPass,
    guardian_phone: "",
    patients: {},
    medicines: [],
    history: [],
    sms_outbox: [],
    guardian_settings: { ...DEFAULT_GUARDIAN_SETTINGS },
  };

  db.users[cleanName] = newUser;
  saveDatabase(db);
  setActiveUsername(cleanName);
  return { success: true, username: cleanName };
}

export function authenticateUser(
  identifier: string,
  password: string
): { success: boolean; username?: string; message?: string } {
  const cleanId = (identifier || "").trim().toLowerCase();
  const cleanPass = (password || "").trim();

  if (!cleanId || !cleanPass) {
    return { success: false, message: "Please enter your username/email and password." };
  }

  const db = loadDatabase();
  let matchedUser: (UserData & { passwordPlain?: string }) | null = null;
  let matchedUsername = "";

  for (const [uname, user] of Object.entries(db.users)) {
    if (uname.toLowerCase() === cleanId || (user.email && user.email.toLowerCase() === cleanId)) {
      matchedUser = user;
      matchedUsername = user.username || uname;
      break;
    }
  }

  if (!matchedUser) {
    return { success: false, message: "Account not found. Please sign up." };
  }

  if (matchedUser.passwordPlain !== cleanPass) {
    return { success: false, message: "Incorrect password. Please try again." };
  }

  setActiveUsername(matchedUsername);
  return { success: true, username: matchedUsername };
}

// ==========================================
// 4. SOUND ENGINE & WEB AUDIO / SPEECH
// ==========================================

class SoundEngine {
  private audioCtx: AudioContext | null = null;
  private chimeInterval: number | null = null;
  private speakInterval: number | null = null;
  private isAlarmActive = false;
  private isSpeaking = false;
  private breezeGainNode: GainNode | null = null;
  private breezeSourceNode: AudioNode | null = null;
  private isBreezePlaying = false;

  constructor() {
    if (typeof window !== "undefined") {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.getVoices();
      }
      const unlockAudio = () => {
        this.unlockContext();
        window.removeEventListener("click", unlockAudio);
        window.removeEventListener("touchstart", unlockAudio);
      };
      window.addEventListener("click", unlockAudio, { passive: true });
      window.addEventListener("touchstart", unlockAudio, { passive: true });
    }
  }

  public unlockContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === "suspended") {
      this.audioCtx.resume();
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
    return this.audioCtx!;
  }

  private getContext(): AudioContext | null {
    try {
      return this.unlockContext();
    } catch {
      return null;
    }
  }

  public playSoftChime(ringtoneName: string = "Gentle Hospital Chime") {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const ring = RINGTONES[ringtoneName] || RINGTONES["Gentle Hospital Chime"];
      const { pattern } = ring;
      const freq = 523.25;

      pattern.forEach((offsetMs) => {
        setTimeout(() => {
          try {
            if (!this.isAlarmActive && this.chimeInterval === null) return;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.type = "sine";
            osc.frequency.setValueAtTime(freq, ctx.currentTime);
            const now = ctx.currentTime;
            gain.gain.setValueAtTime(0.001, now);
            gain.gain.exponentialRampToValueAtTime(0.04, now + 0.04);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
            osc.start(now);
            osc.stop(now + 0.36);
          } catch {}
        }, offsetMs);
      });
    } catch (e) {
      console.warn("Audio Context playback error:", e);
    }
  }

  public playConfirmationChime() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.12);
        gain.gain.setValueAtTime(0.001, now + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.12, now + idx * 0.12 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.12 + 0.45);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.12);
        osc.stop(now + idx * 0.12 + 0.5);
      });
    } catch (e) {
      console.warn("Confirmation chime error:", e);
    }
  }

  public speak(text: string, langCode: string = "en-US", onEnd?: () => void) {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      if (onEnd) onEnd();
      return;
    }
    try {
      const synth = window.speechSynthesis;
      if (synth.paused) synth.resume();
      synth.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = 1.0;
      utterance.rate = 0.85;
      utterance.pitch = 1.05;
      utterance.lang = langCode;

      const voices = synth.getVoices();
      const prefix = langCode.split("-")[0].toLowerCase();
      let voice = voices.find((v) => v.lang.toLowerCase().startsWith(prefix));
      if (!voice) {
        voice = voices.find(
          (v) =>
            v.lang.toLowerCase().includes("hi") ||
            v.lang.toLowerCase().includes("in") ||
            v.name.toLowerCase().includes("india")
        );
      }
      if (voice) utterance.voice = voice;

      utterance.onstart = () => { this.isSpeaking = true; };
      utterance.onend = () => {
        this.isSpeaking = false;
        if (onEnd) onEnd();
      };
      utterance.onerror = () => {
        this.isSpeaking = false;
        if (onEnd) onEnd();
      };
      synth.speak(utterance);
    } catch (e) {
      console.warn("Speech synthesis error:", e);
      this.isSpeaking = false;
      if (onEnd) onEnd();
    }
  }

  public startAlarmLoop(ringtoneName: string, voiceText: string, langCode: string) {
    this.stopAlarmLoop();
    this.isAlarmActive = true;
    this.unlockContext();
    this.playSoftChime(ringtoneName);

    setTimeout(() => {
      if (this.isAlarmActive) {
        this.speak(voiceText, langCode);
      }
    }, 350);

    this.chimeInterval = window.setInterval(() => {
      if (this.isAlarmActive && !this.isSpeaking) {
        this.playSoftChime(ringtoneName);
      }
    }, 4000);

    this.speakInterval = window.setInterval(() => {
      if (this.isAlarmActive) {
        this.speak(voiceText, langCode);
      }
    }, 10000);
  }

  public stopAlarmLoop() {
    this.isAlarmActive = false;
    this.isSpeaking = false;
    if (this.chimeInterval !== null) {
      clearInterval(this.chimeInterval);
      this.chimeInterval = null;
    }
    if (this.speakInterval !== null) {
      clearInterval(this.speakInterval);
      this.speakInterval = null;
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  }

  public previewRingtone(ringtoneName: string) {
    this.playSoftChime(ringtoneName);
  }

  public toggleMountainBreeze(volume: number = 0.15): boolean {
    if (this.isBreezePlaying) {
      this.stopMountainBreeze();
      return false;
    } else {
      this.startMountainBreeze(volume);
      return true;
    }
  }

  public isMountainBreezeActive(): boolean {
    return this.isBreezePlaying;
  }

  public setMountainBreezeVolume(vol: number) {
    if (this.breezeGainNode && this.audioCtx) {
      const clamped = Math.max(0, Math.min(1, vol));
      this.breezeGainNode.gain.setValueAtTime(clamped * 0.25, this.audioCtx.currentTime);
    }
  }

  public startMountainBreeze(volume: number = 0.15) {
    try {
      this.stopMountainBreeze();
      const ctx = this.getContext();
      if (!ctx) return;
      const bufferSize = ctx.sampleRate * 4;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.06;
        b6 = white * 0.115926;
      }
      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(320, ctx.currentTime);
      filter.Q.setValueAtTime(3.0, ctx.currentTime);

      const lfo = ctx.createOscillator();
      lfo.frequency.setValueAtTime(0.18, ctx.currentTime);
      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(140, ctx.currentTime);
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);

      const gain = ctx.createGain();
      const targetGain = Math.max(0.01, Math.min(0.25, volume * 0.25));
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(targetGain, ctx.currentTime + 1.2);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      whiteNoise.start(0);
      lfo.start(0);

      this.breezeSourceNode = whiteNoise;
      this.breezeGainNode = gain;
      this.isBreezePlaying = true;
    } catch (err) {
      console.warn("Unable to start mountain breeze audio:", err);
    }
  }

  public stopMountainBreeze() {
    try {
      if (this.breezeGainNode && this.audioCtx) {
        this.breezeGainNode.gain.setValueAtTime(this.breezeGainNode.gain.value, this.audioCtx.currentTime);
        this.breezeGainNode.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + 0.5);
      }
      setTimeout(() => {
        if (this.breezeSourceNode) {
          try {
            (this.breezeSourceNode as any).stop?.();
            this.breezeSourceNode.disconnect();
          } catch {}
          this.breezeSourceNode = null;
        }
        this.breezeGainNode = null;
        this.isBreezePlaying = false;
      }, 550);
    } catch {
      this.isBreezePlaying = false;
    }
  }
}

export const soundEngine = new SoundEngine();

// ==========================================
// 5. WAKE LOCK MANAGER & HOOK
// ==========================================

type WakeLockReason = "bedside" | "alarm";

class WakeLockManager {
  private sentinel: any = null;
  private activeReasons = new Set<WakeLockReason>();
  private isAcquiring = false;
  private listeners = new Set<(active: boolean) => void>();

  constructor() {
    if (typeof window !== "undefined" && typeof document !== "undefined") {
      document.addEventListener("visibilitychange", this.handleVisibilityChange);
      window.addEventListener("focus", this.handleVisibilityChange);
      window.addEventListener("pageshow", this.handleVisibilityChange);
    }
  }

  public isSupported(): boolean {
    return typeof navigator !== "undefined" && "wakeLock" in navigator;
  }

  public isActive(): boolean {
    return this.sentinel !== null && !this.sentinel.released;
  }

  public isReasonActive(reason: WakeLockReason): boolean {
    return this.activeReasons.has(reason);
  }

  public async requestLock(reason: WakeLockReason): Promise<boolean> {
    this.activeReasons.add(reason);
    return this.acquire();
  }

  public async releaseLock(reason: WakeLockReason): Promise<void> {
    this.activeReasons.delete(reason);
    if (this.activeReasons.size === 0) {
      await this.releaseSentinel();
    }
  }

  public async toggleBedsideLock(): Promise<boolean> {
    if (this.activeReasons.has("bedside")) {
      await this.releaseLock("bedside");
      return false;
    } else {
      return await this.requestLock("bedside");
    }
  }

  private async acquire(): Promise<boolean> {
    if (!this.isSupported()) {
      this.notifyListeners(false);
      return false;
    }
    if (this.isActive()) {
      this.notifyListeners(true);
      return true;
    }
    if (this.isAcquiring) return false;
    this.isAcquiring = true;
    try {
      if (typeof document !== "undefined" && document.visibilityState === "visible") {
        const sentinel = await (navigator as any).wakeLock.request("screen");
        this.sentinel = sentinel;
        sentinel.addEventListener("release", () => {
          this.sentinel = null;
          this.notifyListeners(false);
        });
        this.notifyListeners(true);
        return true;
      }
    } catch {
      // Background or disallowed
    } finally {
      this.isAcquiring = false;
    }
    return false;
  }

  private async releaseSentinel(): Promise<void> {
    if (this.sentinel) {
      try {
        await this.sentinel.release();
      } catch {}
      this.sentinel = null;
    }
    this.notifyListeners(false);
  }

  private handleVisibilityChange = async () => {
    if (typeof document === "undefined") return;
    if (document.visibilityState === "visible" && this.activeReasons.size > 0) {
      await this.acquire();
    }
  };

  public subscribe(listener: (active: boolean) => void): () => void {
    this.listeners.add(listener);
    listener(this.isActive());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(active: boolean) {
    this.listeners.forEach((fn) => {
      try { fn(active); } catch {}
    });
  }
}

export const wakeLockManager = new WakeLockManager();

export function useWakeLock() {
  const [isSupported] = useState(() => wakeLockManager.isSupported());
  const [isActive, setIsActive] = useState(() => wakeLockManager.isActive());
  const [isBedsideActive, setIsBedsideActive] = useState(() =>
    wakeLockManager.isReasonActive("bedside")
  );

  useEffect(() => {
    return wakeLockManager.subscribe((active) => {
      setIsActive(active);
      setIsBedsideActive(wakeLockManager.isReasonActive("bedside"));
    });
  }, []);

  const toggleBedside = async () => {
    const res = await wakeLockManager.toggleBedsideLock();
    setIsBedsideActive(res);
    return res;
  };

  return {
    isSupported,
    isActive,
    isBedsideActive,
    toggleBedside,
    requestLock: (reason: "bedside" | "alarm") => wakeLockManager.requestLock(reason),
    releaseLock: (reason: "bedside" | "alarm") => wakeLockManager.releaseLock(reason),
  };
}

// ==========================================
// 6. NATIVE ANDROID ALARMS & LOCAL NOTIFICATIONS
// ==========================================

export const ALARM_CHANNEL_ID = "medtake_high_priority_alarms";
export const ACTION_TYPE_ID = "MEDTAKE_ALARM_ACTIONS";

type NativeAlarmActionCallback = (action: "take" | "snooze" | "open", medicineId: string) => void;

class NativeAlarmService {
  private isInitialized = false;
  private actionListeners = new Set<NativeAlarmActionCallback>();

  private hashMedicineId(medId: string): number {
    let hash = 0;
    for (let i = 0; i < medId.length; i++) {
      hash = (hash << 5) - hash + medId.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash) % 2147483647;
  }

  public isNative(): boolean {
    try {
      return !!(window as any).Capacitor?.isNativePlatform?.();
    } catch {
      return false;
    }
  }

  public async init(): Promise<void> {
    if (this.isInitialized) return;
    if (!this.isNative()) {
      this.isInitialized = true;
      return;
    }
    try {
      await LocalNotifications.createChannel({
        id: ALARM_CHANNEL_ID,
        name: "MedTake Exact Medicine Alarms",
        description: "High-priority alarms that wake device from sleep/lock screen",
        importance: 5,
        visibility: 1,
        sound: "alarm.wav",
        vibration: true,
        lights: true,
        lightColor: "#10b981",
      }).catch(() => {});

      await LocalNotifications.registerActionTypes({
        types: [
          {
            id: ACTION_TYPE_ID,
            actions: [
              { id: "take", title: "✓ Mark Taken", foreground: true },
              { id: "snooze", title: "💤 Snooze (5m)", foreground: false },
            ],
          },
        ],
      }).catch(() => {});

      LocalNotifications.addListener("localNotificationActionPerformed", (notificationAction) => {
        const actionId = notificationAction.actionId;
        const extra = notificationAction.notification.extra;
        const medId = extra?.medicineId;
        if (medId) {
          if (actionId === "take") this.notifyActionListeners("take", medId);
          else if (actionId === "snooze") this.notifyActionListeners("snooze", medId);
          else this.notifyActionListeners("open", medId);
        }
      });

      LocalNotifications.addListener("localNotificationReceived", (notification) => {
        const medId = notification.extra?.medicineId;
        if (medId) this.notifyActionListeners("open", medId);
      });

      this.isInitialized = true;
    } catch {}
  }

  public addActionListener(callback: NativeAlarmActionCallback): () => void {
    this.actionListeners.add(callback);
    return () => { this.actionListeners.delete(callback); };
  }

  private notifyActionListeners(action: "take" | "snooze" | "open", medicineId: string) {
    this.actionListeners.forEach((fn) => {
      try { fn(action, medicineId); } catch {}
    });
  }

  public async requestPermissions(): Promise<boolean> {
    if (!this.isNative()) {
      if (typeof window !== "undefined" && "Notification" in window) {
        try {
          if (Notification.permission === "granted") return true;
          if (Notification.permission === "denied") return false;
          const status = await Notification.requestPermission();
          return status === "granted";
        } catch {
          return false;
        }
      }
      return false;
    }
    try {
      const status = await LocalNotifications.requestPermissions();
      return status.display === "granted";
    } catch {
      return false;
    }
  }

  public async scheduleExactAlarms(medicines: Medicine[]): Promise<void> {
    if (!this.isNative()) return;
    await this.init();
    try {
      const pending = await LocalNotifications.getPending();
      if (pending && pending.notifications && pending.notifications.length > 0) {
        await LocalNotifications.cancel({
          notifications: pending.notifications.map((n) => ({ id: n.id })),
        });
      }
      if (!medicines || medicines.length === 0) return;
      const now = new Date();
      const scheduledNotifications = [];
      for (const med of medicines) {
        let targetDate: Date;
        if (med.snooze_until) {
          const snoozeDate = new Date(med.snooze_until);
          targetDate = snoozeDate > now ? snoozeDate : this.calculateNextOccurrence(med.time, now);
        } else {
          targetDate = this.calculateNextOccurrence(med.time, now);
        }

        const numericId = this.hashMedicineId(med.id);
        scheduledNotifications.push({
          id: numericId,
          title: `⏰ MEDICINE ALARM: ${med.name}`,
          body: `Alert for ${med.patient}: Take ${med.dose} tablet of ${med.name}. Scheduled for ${med.time}`,
          schedule: { at: targetDate, allowWhileIdle: true },
          sound: "alarm.wav",
          channelId: ALARM_CHANNEL_ID,
          smallIcon: "ic_stat_alarm",
          actionTypeId: ACTION_TYPE_ID,
          extra: {
            medicineId: med.id,
            patientName: med.patient,
            medicineName: med.name,
            scheduledTime: med.time,
          },
          ongoing: false,
          autoCancel: true,
        });
      }
      if (scheduledNotifications.length > 0) {
        await LocalNotifications.schedule({ notifications: scheduledNotifications });
      }
    } catch {}
  }

  private calculateNextOccurrence(timeStr: string, fromDate: Date): Date {
    const [hours, minutes] = timeStr.split(":").map(Number);
    const target = new Date(fromDate);
    target.setHours(hours, minutes, 0, 0);
    if (target.getTime() <= fromDate.getTime()) {
      target.setDate(target.getDate() + 1);
    }
    return target;
  }
}

export const nativeAlarmService = new NativeAlarmService();

// ==========================================
// 7. SERVICE WORKER MANAGER
// ==========================================

type SWActionHandler = (action: "take" | "snooze" | "open", medicineId?: string) => void;

class ServiceWorkerManager {
  private registration: ServiceWorkerRegistration | null = null;
  private actionListeners = new Set<SWActionHandler>();

  constructor() {
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      this.init();
    }
  }

  private async init() {
    try {
      navigator.serviceWorker.addEventListener("message", (event) => {
        if (!event.data) return;
        if (event.data.type === "NOTIFICATION_ACTION_CLICKED") {
          const { action, medicineId } = event.data;
          this.actionListeners.forEach((fn) => fn(action, medicineId));
        }
        if (event.data.type === "SW_ALARM_DUE") {
          const { medicineId } = event.data;
          this.actionListeners.forEach((fn) => fn("open", medicineId));
        }
      });
      const reg = await navigator.serviceWorker.ready;
      this.registration = reg;
    } catch {}
  }

  public async requestNotificationPermission(): Promise<NotificationPermission> {
    if (typeof window === "undefined" || !("Notification" in window)) return "denied";
    try {
      return await Notification.requestPermission();
    } catch {
      return "denied";
    }
  }

  public async syncAlarms(medicines: Medicine[]): Promise<void> {
    if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return;
    try {
      const reg = this.registration || (await navigator.serviceWorker.ready);
      const messagePayload = {
        type: "SYNC_ALARMS",
        medicines: medicines.map((m) => ({
          id: m.id,
          name: m.name,
          time: m.time,
          dose: m.dose,
          stock: m.stock,
          patient: m.patient,
          snooze_until: m.snooze_until,
          last_fired: m.last_fired,
        })),
      };
      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage(messagePayload);
      } else if (reg.active) {
        reg.active.postMessage(messagePayload);
      }
    } catch {}
  }

  public async triggerSystemNotification(medicine: Medicine): Promise<void> {
    if (typeof window === "undefined") return;
    const title = `⏰ Medicine Alert: ${medicine.name}`;
    const body = `Time for ${medicine.patient} to take ${medicine.name} (${medicine.dose} tablet). Tap to open alarm.`;

    try {
      if ("serviceWorker" in navigator) {
        const reg = this.registration || (await navigator.serviceWorker.ready);
        await reg.showNotification(title, {
          body,
          icon: "/pwa-192x192.png",
          badge: "/pwa-192x192.png",
          tag: `medtake-alarm-${medicine.id}`,
          renotify: true,
          requireInteraction: true,
          vibrate: [500, 250, 500, 250, 1000],
          data: { medicineId: medicine.id, patient: medicine.patient },
          actions: [
            { action: "take", title: "✓ I Have Taken It" },
            { action: "snooze", title: "⏱ Snooze 5 Min" },
          ],
        } as any);
        return;
      }
    } catch {}

    if ("Notification" in window && Notification.permission === "granted") {
      try {
        new Notification(title, {
          body,
          icon: "/pwa-192x192.png",
          tag: `medtake-alarm-${medicine.id}`,
        });
      } catch {}
    }
  }

  public onNotificationAction(callback: SWActionHandler): () => void {
    this.actionListeners.add(callback);
    return () => { this.actionListeners.delete(callback); };
  }
}

export const serviceWorkerManager = new ServiceWorkerManager();

// ==========================================
// 8. OFFLINE INDEXEDDB & SERVER SYNC
// ==========================================

const IDB_NAME = "medtake_offline_vault_v1";
const IDB_VERSION = 1;
const IDB_STORE = "pending_history_logs";

class OfflineSyncManager {
  private dbPromise: Promise<IDBDatabase> | null = null;
  private listeners: Set<(status: SyncStatus) => void> = new Set();
  private isSyncing = false;
  private lastSyncTime: string | null = null;
  private cachedPendingCount = 0;

  constructor() {
    if (typeof window !== "undefined") {
      window.addEventListener("online", () => {
        this.notifyListeners();
        setTimeout(() => this.autoDrainQueue(), 1000);
      });
      window.addEventListener("offline", () => {
        this.notifyListeners();
      });
      this.getPendingCount().then((count) => {
        this.cachedPendingCount = count;
        this.notifyListeners();
      }).catch(() => {});
    }
  }

  private getDB(): Promise<IDBDatabase> {
    if (typeof window === "undefined" || !("indexedDB" in window)) {
      return Promise.reject(new Error("IndexedDB not supported"));
    }
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(IDB_NAME, IDB_VERSION);
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          const store = db.createObjectStore(IDB_STORE, { keyPath: "id" });
          store.createIndex("by_username", "username", { unique: false });
        }
      };
      request.onsuccess = (event) => {
        resolve((event.target as IDBOpenDBRequest).result);
      };
      request.onerror = (event) => {
        reject((event.target as IDBOpenDBRequest).error);
      };
    });
    return this.dbPromise;
  }

  public isOnline(): boolean {
    return typeof navigator !== "undefined" && typeof navigator.onLine === "boolean"
      ? navigator.onLine
      : true;
  }

  public async storePendingLog(item: HistoryItem, username: string) {
    const db = await this.getDB();
    const id = item.id || `offline-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const record = {
      ...item,
      id,
      username: username || "default",
      createdAt: Date.now(),
      offlineSaved: true,
    };

    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, "readwrite");
      const store = tx.objectStore(IDB_STORE);
      const req = store.put(record);
      req.onsuccess = () => {
        this.cachedPendingCount++;
        this.notifyListeners();
        resolve(record);
      };
      req.onerror = () => reject(req.error);
    });
  }

  public async getAllPendingLogs(username?: string): Promise<any[]> {
    try {
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(IDB_STORE, "readonly");
        const store = tx.objectStore(IDB_STORE);
        const req = store.getAll();
        req.onsuccess = () => {
          const all = req.result || [];
          resolve(username ? all.filter((l: any) => l.username === username) : all);
        };
        req.onerror = () => reject(req.error);
      });
    } catch {
      return [];
    }
  }

  public async getPendingCount(username?: string): Promise<number> {
    const list = await this.getAllPendingLogs(username);
    this.cachedPendingCount = list.length;
    return list.length;
  }

  public async removePendingLog(id: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, "readwrite");
      const store = tx.objectStore(IDB_STORE);
      const req = store.delete(id);
      req.onsuccess = () => {
        this.cachedPendingCount = Math.max(0, this.cachedPendingCount - 1);
        this.notifyListeners();
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  }

  public async syncPendingLogsToServer(username: string): Promise<number> {
    if (this.isSyncing || !this.isOnline()) return 0;
    const pendingLogs = await this.getAllPendingLogs(username);
    if (pendingLogs.length === 0) return 0;

    this.isSyncing = true;
    this.notifyListeners();
    let synced = 0;

    try {
      const response = await fetch("/api/sync-history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username || "default",
          logs: pendingLogs,
        }),
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success && Array.isArray(result.syncedIds)) {
          for (const id of result.syncedIds) {
            await this.removePendingLog(id);
            synced++;
          }
          this.lastSyncTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        }
      }
    } catch {} finally {
      this.isSyncing = false;
      await this.getPendingCount();
      this.notifyListeners();
    }
    return synced;
  }

  public async recordHistoryItem(
    item: HistoryItem,
    username: string
  ): Promise<{ enrichedItem: HistoryItem; savedToIndexedDB: boolean }> {
    const id = item.id || `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const baseItem: HistoryItem = { ...item, id };

    if (!this.isOnline()) {
      await this.storePendingLog(baseItem, username);
      return {
        enrichedItem: { ...baseItem, syncStatus: "offline", offlineSaved: true },
        savedToIndexedDB: true,
      };
    }

    try {
      const response = await fetch("/api/sync-history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, logs: [baseItem] }),
      });
      if (response.ok) {
        this.lastSyncTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        this.notifyListeners();
        return {
          enrichedItem: { ...baseItem, syncStatus: "synced", syncedAt: this.lastSyncTime },
          savedToIndexedDB: false,
        };
      }
      throw new Error("HTTP error");
    } catch {
      await this.storePendingLog(baseItem, username);
      return {
        enrichedItem: { ...baseItem, syncStatus: "offline", offlineSaved: true },
        savedToIndexedDB: true,
      };
    }
  }

  private autoDrainQueue(): void {
    if (typeof localStorage !== "undefined") {
      const activeUser = localStorage.getItem(SESSION_USER_KEY);
      if (activeUser && activeUser.trim()) {
        this.syncPendingLogsToServer(activeUser.trim());
      }
    }
  }

  public subscribe(callback: (status: SyncStatus) => void): () => void {
    this.listeners.add(callback);
    callback(this.getStatus());
    return () => { this.listeners.delete(callback); };
  }

  public getStatus(): SyncStatus {
    return {
      isOnline: this.isOnline(),
      pendingCount: this.cachedPendingCount,
      lastSyncTime: this.lastSyncTime,
      isSyncing: this.isSyncing,
    };
  }

  private notifyListeners(): void {
    const status = this.getStatus();
    this.listeners.forEach((fn) => {
      try { fn(status); } catch {}
    });
  }
}

export const offlineSyncManager = new OfflineSyncManager();

export function useOfflineSync() {
  const [status, setStatus] = useState<SyncStatus>(() => offlineSyncManager.getStatus());
  useEffect(() => {
    return offlineSyncManager.subscribe(setStatus);
  }, []);
  return {
    ...status,
    syncNow: (username: string) => offlineSyncManager.syncPendingLogsToServer(username),
  };
}

// ==========================================
// 9. PWA INSTALL HOOK
// ==========================================

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const install = async (): Promise<boolean> => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };

  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    install,
  };
}

// ==========================================
// 10. INLINE MODALS & SUB-COMPONENTS
// ==========================================

// Patient Avatar Display
export const PatientAvatar: React.FC<{
  name: string;
  avatarUrl?: string | null;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  showBorder?: boolean;
}> = ({ name, avatarUrl, size = "md", className = "", showBorder = true }) => {
  const [hasError, setHasError] = useState(false);
  const sizeClasses = {
    xs: "w-6 h-6 text-xs",
    sm: "w-8 h-8 text-xs",
    md: "w-11 h-11 text-sm",
    lg: "w-14 h-14 text-base",
    xl: "w-20 h-20 text-xl",
  };
  const initial = name ? name.trim().charAt(0).toUpperCase() : "?";

  const getBgColor = (str: string) => {
    const colors = [
      "bg-emerald-100 text-emerald-800 border-emerald-300",
      "bg-rose-100 text-rose-800 border-rose-300",
      "bg-amber-100 text-amber-800 border-amber-300",
      "bg-teal-100 text-teal-800 border-teal-300",
      "bg-sky-100 text-sky-800 border-sky-300",
      "bg-purple-100 text-purple-800 border-purple-300",
    ];
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 rounded-2xl overflow-hidden shadow-2xs select-none ${
        sizeClasses[size]
      } ${showBorder ? "border-2 border-white ring-1 ring-slate-200/60" : ""} ${className}`}
    >
      {avatarUrl && !hasError ? (
        <img
          src={avatarUrl}
          alt={name}
          className="w-full h-full object-cover"
          onError={() => setHasError(true)}
        />
      ) : (
        <div className={`w-full h-full flex items-center justify-center font-black ${getBgColor(name || "Patient")}`}>
          {initial || <User className="w-1/2 h-1/2" />}
        </div>
      )}
    </div>
  );
};

// Avatar Picker Component
export const AvatarPicker: React.FC<{
  patientName: string;
  selectedAvatar: string | null;
  onSelectAvatar: (avatarUrl: string | null) => void;
}> = ({ patientName, selectedAvatar, onSelectAvatar }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      onSelectAvatar(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
          Patient Profile Photo / Avatar
        </label>
        {selectedAvatar && (
          <button
            type="button"
            onClick={() => onSelectAvatar(null)}
            className="text-xs text-slate-400 hover:text-red-600 flex items-center gap-1 cursor-pointer"
          >
            <X className="w-3 h-3" />
            <span>Reset to Initials</span>
          </button>
        )}
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200">
        <div className="flex items-center gap-3 shrink-0">
          <PatientAvatar
            name={patientName || "Patient"}
            avatarUrl={selectedAvatar}
            size="lg"
            showBorder={true}
          />
          <div>
            <span className="text-xs font-bold text-slate-800 block">
              {selectedAvatar ? "Selected Photo" : "Default Initials"}
            </span>
            <span className="text-[11px] text-slate-400">Displayed in Home & Alarms</span>
          </div>
        </div>

        <div className="hidden sm:block h-10 w-px bg-slate-200" />

        <div className="flex-1 w-full space-y-2">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-slate-300 hover:border-emerald-500 bg-white text-xs font-bold text-slate-700 hover:text-emerald-700 hover:bg-emerald-50/30 shrink-0 transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-slate-500" />
              <span>Upload Custom</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />

            {PRESET_AVATARS.map((avatar) => {
              const isSelected = selectedAvatar === avatar.url;
              return (
                <button
                  key={avatar.id}
                  type="button"
                  onClick={() => onSelectAvatar(avatar.url)}
                  className={`relative p-0.5 rounded-2xl shrink-0 transition-all cursor-pointer ${
                    isSelected ? "ring-2 ring-emerald-600 scale-105" : "opacity-80 hover:opacity-100 hover:scale-102"
                  }`}
                  title={avatar.name}
                >
                  <img
                    src={avatar.url}
                    alt={avatar.name}
                    className="w-9 h-9 rounded-xl object-cover shadow-2xs border border-white"
                  />
                  {isSelected && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

// Notification Permission Banner
export const NotificationPermissionBanner: React.FC<{
  onPermissionResolved?: (granted: boolean) => void;
}> = ({ onPermissionResolved }) => {
  const [permissionState, setPermissionState] = useState<NotificationPermission>("default");
  const [isDismissed, setIsDismissed] = useState(false);
  const [isRequesting, setIsRequesting] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      setPermissionState(Notification.permission);
    }
  }, []);

  if (isDismissed || permissionState === "granted") {
    if (showSuccessToast) {
      return (
        <div className="bg-emerald-600 text-white px-4 py-2.5 rounded-2xl shadow-md flex items-center justify-between text-xs sm:text-sm font-semibold mb-4 animate-in fade-in duration-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
            <span>Voice & Dose Alerts Enabled! You will receive timely reminders.</span>
          </div>
          <button onClick={() => setShowSuccessToast(false)} className="text-emerald-100 hover:text-white px-2 py-0.5">✕</button>
        </div>
      );
    }
    return null;
  }

  const handleRequestPermission = async () => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    try {
      setIsRequesting(true);
      soundEngine.unlockContext();
      const result = await Notification.requestPermission();
      setPermissionState(result);
      if (result === "granted") {
        soundEngine.playConfirmationChime();
        setShowSuccessToast(true);
        setTimeout(() => setShowSuccessToast(false), 4500);
        setIsDismissed(true);
        onPermissionResolved?.(true);
      } else {
        onPermissionResolved?.(false);
      }
    } catch {
    } finally {
      setIsRequesting(false);
    }
  };

  if (permissionState === "denied") {
    return (
      <div className="bg-amber-50 border border-amber-200 text-amber-900 px-4 py-3 rounded-2xl shadow-xs mb-4 flex items-center justify-between gap-3 text-xs sm:text-sm">
        <div className="flex items-center gap-2.5">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
          <span>Notifications are blocked in your browser settings. Please enable them to receive medicine voice alerts.</span>
        </div>
        <button
          onClick={() => setIsDismissed(true)}
          className="text-amber-700 hover:text-amber-900 text-xs font-bold px-2 py-1 rounded-lg hover:bg-amber-100 shrink-0 cursor-pointer"
        >
          Dismiss
        </button>
      </div>
    );
  }

  return (
    <div
      onClick={handleRequestPermission}
      role="button"
      tabIndex={0}
      className="bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 text-white p-3.5 sm:p-4 rounded-2xl shadow-md mb-4 flex flex-col sm:flex-row items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2 duration-300 cursor-pointer hover:brightness-105 active:scale-[0.99] transition-all select-none border border-white/20"
      title="Tap to Enable Real-Time Voice & Dose Alerts"
    >
      <div className="flex items-center gap-3 w-full sm:w-auto">
        <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/30 shadow-2xs">
          <Bell className="w-5 h-5 text-white animate-bounce" />
        </div>
        <div className="flex-1">
          <h4 className="font-bold text-sm sm:text-base flex items-center gap-1.5 leading-snug">
            <span>🔔 Tap to Enable Real-Time Voice & Dose Alerts</span>
          </h4>
          <p className="text-white/90 text-xs mt-0.5">
            Receive fullscreen audio alarms and multilingual spoken medicine instructions when doses are due.
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
        <div className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white text-blue-700 font-bold text-xs sm:text-sm shadow-sm flex items-center justify-center gap-2 pointer-events-none">
          <Volume2 className="w-4 h-4 text-blue-600" />
          <span>{isRequesting ? "Enabling..." : "Enable Alerts"}</span>
        </div>
      </div>
    </div>
  );
};

// Floating Install Button
export const FloatingInstallButton: React.FC<{
  onOpenManualModal?: () => void;
}> = ({ onOpenManualModal }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [isDismissed, setIsDismissed] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  if (isInstalled || isDismissed) return null;

  const handleInstallClick = async () => {
    setIsInstalling(true);
    try {
      if (isInstallable) {
        const success = await install();
        if (success) setIsDismissed(true);
      } else if (onOpenManualModal) {
        onOpenManualModal();
      }
    } finally {
      setIsInstalling(false);
    }
  };

  return (
    <>
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-blue-700 via-indigo-600 to-emerald-600 text-white shadow-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 flex items-center justify-between gap-2 text-xs sm:text-sm font-semibold">
          <div className="flex items-center gap-2 truncate">
            <span className="p-1 rounded-md bg-white/20 shrink-0">
              <Smartphone className="w-4 h-4 text-white animate-pulse" />
            </span>
            <span className="truncate">
              Install <strong className="font-bold">MedTake App</strong> for instant voice alarms & offline guardian watchdog!
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleInstallClick}
              disabled={isInstalling}
              className="px-3 py-1 sm:px-4 sm:py-1.5 rounded-lg bg-white text-blue-700 hover:bg-blue-50 font-extrabold shadow-sm active:scale-95 transition-transform flex items-center gap-1.5 cursor-pointer text-xs sm:text-sm"
            >
              <Download className="w-3.5 h-3.5 text-blue-700" />
              <span>Install MedTake App</span>
              <Sparkles className="w-3 h-3 text-amber-500 hidden sm:inline" />
            </button>
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1 rounded-md hover:bg-white/20 text-white/80 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="fixed bottom-5 right-4 sm:right-6 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300">
        <div className="flex items-center gap-1.5 p-1.5 pl-3 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 text-white shadow-2xl border border-white/20 backdrop-blur-md">
          <button
            onClick={handleInstallClick}
            disabled={isInstalling}
            className="flex items-center gap-2.5 text-xs sm:text-sm font-bold pr-2 cursor-pointer active:scale-95 transition-transform"
          >
            <div className="w-8 h-8 rounded-full bg-white text-blue-600 flex items-center justify-center shadow-xs">
              <Smartphone className="w-4 h-4 animate-pulse" />
            </div>
            <span className="flex items-center gap-1">
              <span>📲 Install MedTake App</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            </span>
          </button>
          <button
            onClick={() => setIsDismissed(true)}
            className="w-7 h-7 rounded-full bg-black/20 hover:bg-black/40 text-white/80 hover:text-white flex items-center justify-center text-xs transition-colors cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </>
  );
};

// Edit Time Modal
export const EditTimeModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  medicine: Medicine | null;
  onUpdateTime: (medId: string, newTime: string) => void;
}> = ({ isOpen, onClose, medicine, onUpdateTime }) => {
  const [selectedTime, setSelectedTime] = useState("08:00");

  useEffect(() => {
    if (medicine?.time) setSelectedTime(medicine.time);
  }, [medicine]);

  if (!isOpen || !medicine) return null;

  const handleSave = () => {
    if (selectedTime) {
      onUpdateTime(medicine.id, selectedTime);
      onClose();
    }
  };

  const setOffset = (mins: number) => {
    const d = new Date();
    d.setMinutes(d.getMinutes() + mins);
    setSelectedTime(`${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-sm w-full shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-300" />
            <h3 className="font-extrabold text-base">Edit Alarm Time</h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">Set 24hr Time (HH:MM)</label>
            <input
              type="time"
              value={selectedTime}
              onChange={(e) => setSelectedTime(e.target.value)}
              className="w-full mt-1.5 p-3 rounded-xl border border-slate-300 font-mono text-2xl font-black text-slate-900 text-center"
            />
          </div>
          <div className="flex items-center justify-between gap-2">
            <button
              onClick={() => setOffset(1)}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-bold text-slate-700"
            >
              +1 Min (Test)
            </button>
            <button
              onClick={() => setOffset(5)}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-bold text-slate-700"
            >
              +5 Min
            </button>
            <button
              onClick={() => setOffset(15)}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-bold text-slate-700"
            >
              +15 Min
            </button>
          </div>
          <button
            onClick={handleSave}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-md cursor-pointer"
          >
            Save Alarm Time
          </button>
        </div>
      </div>
    </div>
  );
};

// AI Prescription Scanner Modal
export const AiPrescriptionModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onApplyMedicine: (extracted: {
    name: string;
    dose: number;
    time: string;
    mealTiming: MealTiming;
    stock: number;
  }) => void;
}> = ({ isOpen, onClose, onApplyMedicine }) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSimulatedAnalyze = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onApplyMedicine({
        name: notes.trim() || "Amoxicillin 500mg",
        dose: 1,
        time: "09:00",
        mealTiming: "After food",
        stock: 30,
      });
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-300" />
            <h3 className="font-extrabold text-base">Gemini Vision Prescription OCR</h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-4 text-xs">
          <p className="text-slate-600">
            Upload doctor prescription or enter medication notes to extract doses, timings, and schedules automatically.
          </p>
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-4 text-center cursor-pointer bg-slate-50"
          >
            {imagePreview ? (
              <img src={imagePreview} alt="Prescription" className="h-32 mx-auto rounded-lg object-contain" />
            ) : (
              <div className="space-y-1 text-slate-500">
                <Camera className="w-8 h-8 mx-auto text-emerald-600" />
                <span className="font-bold block">Take Photo or Upload Image</span>
              </div>
            )}
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
          </div>
          <div>
            <label className="font-bold text-slate-700 uppercase">Doctor Notes or Medicine Text</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Paracetamol 650mg twice daily after meals..."
              className="w-full mt-1 p-2 rounded-xl border border-slate-300 text-xs"
            />
          </div>
          <button
            onClick={handleSimulatedAnalyze}
            disabled={isLoading}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{isLoading ? "Analyzing with Gemini..." : "Extract & Add to Schedule"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// Pharmacy Refill Modal
export const PharmacyRefillModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  medicine: Medicine | null;
  patient?: Patient | null;
}> = ({ isOpen, onClose, medicine, patient }) => {
  if (!isOpen || !medicine) return null;
  const targetPhone = "+919845012345";
  const orderMsg = `🏥 MEDTAKE REFILL: ${medicine.patient} needs urgent refill of ${medicine.name} (${medicine.stock} tablets remaining).`;
  const waUrl = createWhatsAppUrl(targetPhone, orderMsg);
  const callUrl = createPhoneCallUrl(targetPhone);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-300" />
            <h3 className="font-extrabold text-base">Pharmacy Refill Order</h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-4 text-xs">
          <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900">
            <span className="font-extrabold block text-sm">{medicine.name}</span>
            <span>Only {medicine.stock} tablet(s) left in stock for {patient?.name || medicine.patient}.</span>
          </div>
          <div className="flex gap-2">
            <a
              href={waUrl}
              target="_blank"
              rel="noreferrer"
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-center shadow-md flex items-center justify-center gap-1.5"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Order on WhatsApp</span>
            </a>
            <a
              href={callUrl}
              className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl flex items-center justify-center"
            >
              <PhoneCall className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

// Doctor Report Modal
export const DoctorReportModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  patients: Record<string, Patient>;
  medicines: Medicine[];
  history: HistoryItem[];
  username: string;
}> = ({ isOpen, onClose, patients, medicines, history, username }) => {
  if (!isOpen) return null;
  const takenCount = history.filter((h) => h.status.toLowerCase().includes("taken")).length;
  const rate = history.length > 0 ? Math.round((takenCount / history.length) * 100) : 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-amber-300" />
            <h3 className="font-extrabold text-base">Doctor Adherence Clinical Report</h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4 overflow-y-auto text-xs">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <span className="font-extrabold text-slate-900 text-sm">Account: {username}</span>
              <p className="text-slate-500">Total Prescriptions: {medicines.length}</p>
            </div>
            <div className="text-right">
              <span className="text-emerald-700 font-extrabold text-lg">{rate}%</span>
              <p className="text-[10px] text-slate-400">Adherence Score</p>
            </div>
          </div>
          <div>
            <h4 className="font-bold text-slate-800 uppercase mb-2">Recent Log Records ({history.length})</h4>
            <div className="space-y-1.5 max-h-56 overflow-y-auto">
              {history.slice(-10).reverse().map((item, idx) => (
                <div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex justify-between">
                  <div>
                    <span className="font-bold text-slate-800">{item.patient}</span> - {item.med}
                    <span className="text-[11px] text-slate-400 block">{item.date} {item.time}</span>
                  </div>
                  <span className={`font-extrabold ${item.status.includes("Taken") ? "text-emerald-600" : "text-amber-600"}`}>
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={() => window.print()}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print Clinical PDF Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// Fullscreen Alarm Modal Overlay
export const AlarmModal: React.FC<{
  medicine: Medicine;
  patient: Patient;
  fallbackGuardianPhone?: string;
  onTaken: (medId: string) => void;
  onSnooze: (medId: string) => void;
  onMissed?: (medId: string) => void;
}> = ({
  medicine,
  patient,
  fallbackGuardianPhone,
  onTaken,
  onSnooze,
  onMissed,
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [secondsRemaining, setSecondsRemaining] = useState(120);

  useEffect(() => {
    const t = setInterval(() => {
      setCurrentTime(new Date());
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(t);
          onMissed?.(medicine.id);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [medicine.id, onMissed]);

  const voiceData = formatVoiceMessage(
    patient?.lang || "English",
    medicine.patient,
    medicine.name,
    medicine.dose
  );

  useEffect(() => {
    wakeLockManager.requestLock("alarm");
    soundEngine.startAlarmLoop(
      medicine.ringtone || "Gentle Hospital Chime",
      voiceData.text,
      voiceData.code
    );
    return () => {
      soundEngine.stopAlarmLoop();
      wakeLockManager.releaseLock("alarm");
    };
  }, [medicine, patient, voiceData.text, voiceData.code]);

  const guardianPhone = normalizePhoneNumber(
    patient?.guardian_phone || fallbackGuardianPhone || ""
  );
  const waUrl = createWhatsAppUrl(guardianPhone, `Alert: ${medicine.patient} dose alarm is active for ${medicine.name}.`);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#070B09]/95 backdrop-blur-md text-white p-4 overflow-y-auto animate-in fade-in">
      <div className="max-w-md w-full flex flex-col items-center space-y-5 text-center my-auto">
        <div className="flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-950/90 border border-red-700 text-red-300 text-xs font-black uppercase tracking-wider">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
          <span>Active Medicine Alarm</span>
        </div>

        <PatientAvatar name={medicine.patient} avatarUrl={patient?.avatar} size="xl" />

        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">{medicine.patient}</h2>
          <p className="text-emerald-400 font-extrabold text-lg mt-0.5">{medicine.name}</p>
          <p className="text-xs text-white/70">
            Dose: {medicine.dose} tablet • {medicine.meal_timing}
          </p>
        </div>

        <div className="p-3 rounded-2xl bg-white/10 border border-white/20 text-xs text-amber-200">
          Auto-escalates to guardian SOS in: <span className="font-mono font-bold">{secondsRemaining}s</span>
        </div>

        <div className="w-full space-y-2 pt-2">
          <button
            onClick={() => onTaken(medicine.id)}
            className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-base shadow-xl flex items-center justify-center gap-2 cursor-pointer active:scale-98 transition-all"
          >
            <CheckCircle2 className="w-6 h-6 text-slate-950" />
            <span>Mark Dose Taken</span>
          </button>

          <button
            onClick={() => onSnooze(medicine.id)}
            className="w-full py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm border border-white/20 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Clock className="w-4 h-4 text-amber-300" />
            <span>Snooze (5 Minutes)</span>
          </button>

          {guardianPhone && (
            <a
              href={waUrl}
              target="_blank"
              rel="noreferrer"
              className="w-full py-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-emerald-400 text-xs font-bold border border-emerald-500/30 flex items-center justify-center gap-1.5"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Contact Guardian ({guardianPhone})</span>
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

// APK & PWA Installation Modal
export const ApkInstallModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const { isInstallable, install } = usePWAInstall();
  if (!isOpen) return null;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(PERMANENT_SHARED_URL)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-gradient-to-r from-emerald-600 to-teal-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-amber-300" />
            <h3 className="font-extrabold text-base">Install MedTake Mobile App</h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4 overflow-y-auto text-xs text-slate-700">
          <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <img src={qrCodeUrl} alt="QR Code" className="w-32 h-32 rounded-xl border border-white shadow-xs" />
            <div className="space-y-1 text-center sm:text-left">
              <span className="font-extrabold text-slate-900 text-sm block">Instant Mobile QR Access</span>
              <p className="text-[11px] text-slate-500">Scan using Android / iPhone camera to open MedTake directly on your phone.</p>
              {isInstallable && (
                <button
                  onClick={() => install()}
                  className="mt-2 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs cursor-pointer shadow-xs"
                >
                  Install Now
                </button>
              )}
            </div>
          </div>
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 uppercase">How to Install as WebAPK on Android:</h4>
            <ol className="list-decimal list-inside space-y-1 text-slate-600">
              <li>Open this website in Chrome on your phone.</li>
              <li>Tap the <strong>📲 Install MedTake App</strong> button or the 3-dot menu.</li>
              <li>Tap <strong>Install App</strong> or <strong>Add to Home Screen</strong>.</li>
              <li>MedTake launches in fullscreen with lock-screen alarm privileges.</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

// Copyright Modal (Tammy TM)
export const CopyrightModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2">
            <Award className="w-6 h-6 text-amber-500" />
            <h3 className="font-extrabold text-lg text-slate-900">Certificate of Ownership</h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 text-xs space-y-2">
          <p className="text-slate-600">This certifies that <strong>MedTake™</strong> is owned by:</p>
          <div className="text-lg font-black text-slate-900">Tammy TM (Tanmay TM)</div>
          <p className="text-[11px] text-slate-500 font-mono">tanmayghost29@gmail.com • +91 8088901642</p>
          <p className="text-[10px] text-emerald-800 font-bold pt-2 border-t border-emerald-200">
            © 2026 Tammy TM. All Rights Reserved. IDT Project Submission.
          </p>
        </div>
        <button
          onClick={() => window.print()}
          className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs"
        >
          Print Certificate
        </button>
      </div>
    </div>
  );
};

// App Details Modal
export const AppDetailsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onOpenApkModal?: () => void;
  onOpenCopyrightModal?: () => void;
}> = ({ isOpen, onClose, onOpenApkModal, onOpenCopyrightModal }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-gradient-to-r from-emerald-800 to-teal-950 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info className="w-5 h-5 text-amber-300" />
            <h3 className="font-extrabold text-base">MedTake Architecture & Support</h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4 overflow-y-auto text-xs text-slate-700">
          <div>
            <h4 className="font-black text-slate-900 text-sm">Developer Support Helpline</h4>
            <p className="text-slate-500 mt-0.5">Email: <a href="mailto:tanmayghost29@gmail.com" className="text-emerald-700 font-bold underline">tanmayghost29@gmail.com</a></p>
            <p className="text-slate-500">Phone: <a href="tel:+918088901642" className="text-emerald-700 font-bold underline">+91 8088901642</a></p>
          </div>
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
            <span className="font-bold text-slate-800 block">Technical Architecture:</span>
            <ul className="list-disc list-inside space-y-0.5 text-slate-600">
              <li>Offline Fallback: IndexedDB Vault & Auto-Sync Engine</li>
              <li>Alarms: Web Audio API & Screen Wake Lock API</li>
              <li>Android Native: Exact AlarmManager via @capacitor/local-notifications</li>
              <li>Languages: 22 Indian Languages Web Speech TTS synthesis</li>
              <li>Emergency: Simultaneous SMS & WhatsApp automated watchdog</li>
            </ul>
          </div>
          <div className="flex gap-2">
            {onOpenApkModal && (
              <button
                onClick={onOpenApkModal}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-center"
              >
                Install App
              </button>
            )}
            {onOpenCopyrightModal && (
              <button
                onClick={onOpenCopyrightModal}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-center"
              >
                Copyright
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// App Settings Modal
export const AppSettingsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  wakeLockActive: boolean;
  onToggleWakeLock: () => void;
  themeMode: "auto" | "day" | "night";
  onSetThemeMode: (mode: "auto" | "day" | "night") => void;
  clockStyle: "chronometer" | "digital_hud" | "minimal";
  onChangeClockStyle: (style: "chronometer" | "digital_hud" | "minimal") => void;
  activeSceneId: string;
  onSelectScene: (id: string) => void;
  filmSettings: FilmSettingsState;
  onUpdateFilmSettings: (settings: Partial<FilmSettingsState>) => void;
  onOpenApkModal: () => void;
  onOpenCopyrightModal: () => void;
  guardianPhone?: string;
  onUpdateGuardianPhone?: (phone: string) => void;
  onSendDualAlert?: (to: string, message: string) => Promise<any>;
}> = ({
  isOpen,
  onClose,
  wakeLockActive,
  onToggleWakeLock,
  clockStyle,
  onChangeClockStyle,
  activeSceneId,
  onSelectScene,
  filmSettings,
  onUpdateFilmSettings,
  onOpenApkModal,
  onOpenCopyrightModal,
  guardianPhone = "",
  onUpdateGuardianPhone,
}) => {
  const [phone, setPhone] = useState(guardianPhone);

  useEffect(() => {
    setPhone(guardianPhone);
  }, [guardianPhone]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-amber-300" />
            <h3 className="font-extrabold text-base">App & Bedside Settings</h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-5 overflow-y-auto text-xs text-slate-700">
          <div>
            <label className="font-bold text-slate-900 block mb-1">Guardian Phone Number (E.164)</label>
            <div className="flex gap-2">
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+919876543210"
                className="flex-1 p-2.5 rounded-xl border border-slate-300 font-mono text-xs"
              />
              <button
                onClick={() => onUpdateGuardianPhone?.(phone)}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
              >
                Save
              </button>
            </div>
          </div>

          <div>
            <span className="font-bold text-slate-900 block mb-1.5">Bedside Clock Style</span>
            <div className="grid grid-cols-3 gap-2">
              {(["chronometer", "digital_hud", "minimal"] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => onChangeClockStyle(mode)}
                  className={`p-2.5 rounded-xl font-bold capitalize border cursor-pointer ${
                    clockStyle === mode ? "bg-emerald-600 text-white border-emerald-600" : "bg-slate-50 border-slate-200"
                  }`}
                >
                  {mode.replace("_", " ")}
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="font-bold text-slate-900 block mb-1.5">Alpine Mountain Scene</span>
            <div className="space-y-1.5">
              {MOUNTAIN_SCENES.map((scene) => (
                <button
                  key={scene.id}
                  onClick={() => onSelectScene(scene.id)}
                  className={`w-full p-2.5 rounded-xl text-left border flex items-center justify-between cursor-pointer ${
                    activeSceneId === scene.id ? "bg-emerald-50 border-emerald-500 font-bold" : "bg-white border-slate-200"
                  }`}
                >
                  <span>{scene.name}</span>
                  {activeSceneId === scene.id && <Check className="w-4 h-4 text-emerald-600" />}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <div>
              <span className="font-bold text-slate-900 block">Screen Wake Lock (Bedside Mode)</span>
              <span className="text-[11px] text-slate-500">Keeps phone display lit continuously</span>
            </div>
            <button
              onClick={onToggleWakeLock}
              className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer ${
                wakeLockActive ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-700"
              }`}
            >
              {wakeLockActive ? "Active" : "Disabled"}
            </button>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              onClick={onOpenApkModal}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl"
            >
              Install App
            </button>
            <button
              onClick={onOpenCopyrightModal}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl"
            >
              Copyright
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Header Component
export const Header: React.FC<{
  username: string;
  themeMode: "auto" | "day" | "night";
  onToggleTheme: () => void;
  onLogout: () => void;
  isAlarmActive: boolean;
  onOpenApkModal?: () => void;
  onOpenCopyrightModal?: () => void;
  onOpenAppDetailsModal?: () => void;
  onOpenSettingsModal?: () => void;
  onNotificationClick?: () => void;
  wakeLockActive?: boolean;
  onToggleWakeLock?: () => void;
  onNavigateToLanding?: () => void;
}> = ({
  username,
  themeMode,
  onToggleTheme,
  onLogout,
  onOpenApkModal,
  onOpenCopyrightModal,
  onOpenAppDetailsModal,
  onOpenSettingsModal,
  onNotificationClick,
  wakeLockActive = false,
  onToggleWakeLock,
  onNavigateToLanding,
}) => {
  const { isOnline, pendingCount } = useOfflineSync();

  return (
    <div className="bg-white border-b border-emerald-100/70 w-full">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <button
            onClick={onNavigateToLanding}
            className="relative flex items-center justify-center shrink-0 cursor-pointer hover:opacity-95 transition-opacity"
            title="MedTake Caregiver Portal"
          >
            <svg
              width="42"
              height="42"
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="drop-shadow-xs shrink-0"
            >
              <rect width="100" height="100" rx="24" fill="#059669" />
              <rect x="42" y="14" width="16" height="6" rx="3" fill="#FFFFFF" />
              <circle
                cx="50"
                cy="54"
                r="30"
                stroke="#FFFFFF"
                strokeWidth="7"
                fill="none"
              />
              <line
                x1="50"
                y1="54"
                x2="50"
                y2="34"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinecap="round"
              />
              <line
                x1="50"
                y1="54"
                x2="66"
                y2="54"
                stroke="#FBBF24"
                strokeWidth="6"
                strokeLinecap="round"
              />
              <g transform="translate(62,60) rotate(35)">
                <rect
                  x="0"
                  y="0"
                  width="18"
                  height="30"
                  rx="9"
                  fill="#F59E0B"
                  stroke="#FFFFFF"
                  strokeWidth="4"
                />
                <line
                  x1="0"
                  y1="15"
                  x2="18"
                  y2="15"
                  stroke="#FFFFFF"
                  strokeWidth="3"
                />
              </g>
            </svg>
          </button>
          <div className="shrink-0 text-left">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="text-xl sm:text-2xl font-black text-emerald-700 tracking-tight leading-none whitespace-nowrap">
                med<span className="text-slate-900">take</span>
              </span>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 whitespace-nowrap">
                Caregiver Portal
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium hidden sm:block whitespace-nowrap">
              Multilingual Alarm & Guardian Telehealth
            </p>
          </div>
        </div>

        {/* User Info & Controls */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Offline / IndexedDB Fallback Indicator */}
          {!isOnline ? (
            <div
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-900 text-xs font-bold shadow-2xs"
              title="Device is Offline: Dose history safely stores in IndexedDB"
            >
              <WifiOff className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden md:inline">Offline (IndexedDB)</span>
              {pendingCount > 0 && (
                <span className="bg-amber-600 text-white rounded-full px-1.5 text-[10px] leading-tight font-extrabold">
                  {pendingCount}
                </span>
              )}
            </div>
          ) : pendingCount > 0 ? (
            <div
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-sky-50 border border-sky-300 text-sky-900 text-xs font-bold shadow-2xs"
              title="IndexedDB Fallback Queue: Logs awaiting auto-sync"
            >
              <Database className="w-3.5 h-3.5 text-sky-700 animate-pulse" />
              <span className="hidden md:inline">{pendingCount} in Queue</span>
            </div>
          ) : null}

          {/* Notification Button */}
          <button
            onClick={onNotificationClick}
            className="relative p-2 rounded-xl text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 transition-all cursor-pointer shadow-2xs active:scale-95 flex items-center justify-center shrink-0"
            title="Notifications & Guardian Outbox Alerts (SMS + WhatsApp)"
          >
            <Bell className="w-4 h-4 text-emerald-700" />
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
          </button>

          {/* Settings button placed right beside notification */}
          {onOpenSettingsModal && (
            <button
              onClick={onOpenSettingsModal}
              className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-slate-800 hover:text-slate-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-all cursor-pointer shadow-2xs active:scale-95 shrink-0"
              title="Settings & Guardian Phone"
            >
              <Settings className="w-4 h-4 text-emerald-800" />
              <span className="hidden sm:inline text-xs font-black text-emerald-950">Settings</span>
            </button>
          )}

          {/* Time Zone info */}
          <div className="hidden lg:flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-100 text-slate-600 text-xs font-mono">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>IST (UTC+5:30)</span>
          </div>

          {/* User badge */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-sm shadow-xs uppercase">
              {username ? username.charAt(0) : "U"}
            </div>
            <div className="hidden sm:block text-left">
              <div className="text-xs font-bold text-slate-800 truncate max-w-[120px]">
                {username || "User"}
              </div>
              <div className="text-[10px] text-emerald-600 font-semibold">
                Caregiver
              </div>
            </div>
          </div>

          {/* 3-Dot Menu Button: App Details & Developer Helpline (+91 8088901642) */}
          {onOpenAppDetailsModal && (
            <button
              onClick={onOpenAppDetailsModal}
              className="p-2 rounded-xl text-slate-700 hover:text-slate-900 hover:bg-slate-100 border border-slate-300/80 transition-all cursor-pointer shadow-2xs active:scale-95 flex items-center justify-center shrink-0"
              title="App Details & Developer Helpline (+91 8088901642)"
            >
              <MoreVertical className="w-4 h-4 text-slate-800" />
            </button>
          )}

          {/* Logout */}
          <button
            onClick={onLogout}
            className="p-2 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer shrink-0"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

// Auth Screen (Sign Up & Sign In)
export const AuthScreen: React.FC<{
  onLoginSuccess: (username: string) => void;
  onBackToLanding: () => void;
}> = ({ onLoginSuccess, onBackToLanding }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (isRegister) {
      const res = registerUser(username, email, password);
      if (res.success && res.username) {
        onLoginSuccess(res.username);
      } else {
        setError(res.message || "Registration failed");
      }
    } else {
      const res = authenticateUser(username, password);
      if (res.success && res.username) {
        onLoginSuccess(res.username);
      } else {
        setError(res.message || "Login failed");
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-2xl mx-auto shadow-md">
            M
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            {isRegister ? "Create Caregiver Account" : "Sign In to MedTake"}
          </h2>
          <p className="text-xs text-slate-500">
            {isRegister ? "Set up isolated patient reminders and alarms" : "Access your medicine schedules and guardian alerts"}
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-bold">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="font-bold text-slate-700 uppercase">Username / Name</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full mt-1 p-3 rounded-xl border border-slate-300 text-xs"
              placeholder="e.g. Tanmay or Rahul"
            />
          </div>

          {isRegister && (
            <div>
              <label className="font-bold text-slate-700 uppercase">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full mt-1 p-3 rounded-xl border border-slate-300 text-xs"
                placeholder="name@example.com"
              />
            </div>
          )}

          <div>
            <label className="font-bold text-slate-700 uppercase">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full mt-1 p-3 rounded-xl border border-slate-300 text-xs"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-xl shadow-lg cursor-pointer"
          >
            {isRegister ? "Create Free Account" : "Sign In"}
          </button>
        </form>

        <div className="text-center pt-2 space-y-2 text-xs">
          <button
            onClick={() => {
              setIsRegister(!isRegister);
              setError(null);
            }}
            className="text-emerald-700 hover:underline font-bold"
          >
            {isRegister ? "Already have an account? Sign In" : "Don't have an account? Sign Up"}
          </button>
          <div>
            <button onClick={onBackToLanding} className="text-slate-400 hover:text-slate-600">
              ← Back to Product Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Public Product Landing Page (Default Route)
export const PublicLandingPage: React.FC<{
  onLaunchApp: () => void;
  onOpenInstallModal: () => void;
  isLoggedIn: boolean;
  username: string;
}> = ({ onLaunchApp, onOpenInstallModal, isLoggedIn, username }) => {
  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col font-sans">
      <header className="border-b border-white/10 px-4 sm:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center font-black text-lg shadow-md">
            M
          </div>
          <span className="font-black text-xl tracking-tight">MedTake™</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenInstallModal}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/10 cursor-pointer"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Install App</span>
          </button>
          <button
            onClick={onLaunchApp}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs sm:text-sm font-black shadow-md cursor-pointer"
          >
            {isLoggedIn ? `Dashboard (${username})` : "Launch App / Sign In"}
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-8 py-12 sm:py-20 flex flex-col items-center text-center space-y-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Smart Multilingual Caregiver Platform</span>
        </div>

        <h1 className="text-3xl sm:text-6xl font-black tracking-tight max-w-4xl leading-tight">
          Never Miss A Dose. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-sky-400">
            22 Indian Languages. Guardian SOS Watchdog.
          </span>
        </h1>

        <p className="text-slate-300 text-sm sm:text-lg max-w-2xl leading-relaxed">
          The intelligent medicine alarm clock designed for elderly patients, families, and caregivers.
          Spoken voice reminders in your native mother tongue, offline IndexedDB sync, and instant dual SMS + WhatsApp guardian alerts.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-3 pt-4">
          <button
            onClick={onLaunchApp}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-base shadow-xl flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
          >
            <span>Launch App / Sign In</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          <button
            onClick={onOpenInstallModal}
            className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-base border border-white/20 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <span>📲 Install Mobile App</span>
          </button>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full pt-12 text-left">
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <Volume2 className="w-6 h-6 text-emerald-400" />
            <h3 className="font-extrabold text-base text-white">22 Indian Languages</h3>
            <p className="text-xs text-slate-400">Spoken voice medicine reminders in Kannada, Hindi, Tamil, Telugu, and more.</p>
          </div>
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
            <h3 className="font-extrabold text-base text-white">Guardian SOS Watchdog</h3>
            <p className="text-xs text-slate-400">Simultaneous SMS & WhatsApp notifications on taken, snoozed, or missed doses.</p>
          </div>
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <Sparkles className="w-6 h-6 text-sky-400" />
            <h3 className="font-extrabold text-base text-white">Gemini Vision OCR</h3>
            <p className="text-xs text-slate-400">Scan physical prescriptions to extract medicine names, dosages, and schedules.</p>
          </div>
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <Wifi className="w-6 h-6 text-indigo-400" />
            <h3 className="font-extrabold text-base text-white">100% Offline Vault</h3>
            <p className="text-xs text-slate-400">IndexedDB local storage ensures alarms trigger reliably even without internet.</p>
          </div>
        </div>

        {/* Helpline attribution */}
        <div className="pt-8 text-xs text-slate-400 space-y-1">
          <p>Created by Tammy TM (Tanmay TM) • Helpline: tanmayghost29@gmail.com • +91 8088901642</p>
        </div>
      </main>
    </div>
  );
};

// Home Tab Dashboard
export const HomeTab: React.FC<{
  username: string;
  themeMode: "auto" | "day" | "night";
  medicines: Medicine[];
  patients: Record<string, Patient>;
  onTriggerTestAlarm: (medId?: string) => void;
  onNavigateToTab: (tab: string) => void;
  onUpdateStock: (medId: string, newStock: number) => void;
  onUpdateTime: (medId: string, newTime: string) => void;
  onOpenApkModal: () => void;
  onOpenCopyrightModal: () => void;
  onOpenAppDetailsModal: () => void;
  onOpenSettings: () => void;
  userGuardianPhone: string;
  clockStyle: "chronometer" | "digital_hud" | "minimal";
  onChangeClockStyle: (style: "chronometer" | "digital_hud" | "minimal") => void;
  activeSceneId: string;
  onSelectScene: (id: string) => void;
  filmSettings: FilmSettingsState;
  onUpdateFilmSettings: (settings: Partial<FilmSettingsState>) => void;
}> = ({
  username,
  medicines,
  patients,
  onTriggerTestAlarm,
  onNavigateToTab,
  onUpdateStock,
  onUpdateTime,
  onOpenSettings,
  clockStyle,
  onChangeClockStyle,
  activeSceneId,
  onSelectScene,
  filmSettings,
  onUpdateFilmSettings,
}) => {
  const [deviceTime, setDeviceTime] = useState(new Date());
  const [editingMed, setEditingMed] = useState<Medicine | null>(null);
  const [refillMed, setRefillMed] = useState<Medicine | null>(null);
  const [isDoctorReportOpen, setIsDoctorReportOpen] = useState(false);
  const [isPrescriptionModalOpen, setIsPrescriptionModalOpen] = useState(false);
  const hours = deviceTime.getHours();
  const minutes = deviceTime.getMinutes();
  const seconds = deviceTime.getSeconds();

  const greeting = useMemo(() => {
    if (hours >= 5 && hours < 12) return "Good Morning";
    if (hours >= 12 && hours < 17) return "Good Afternoon";
    if (hours >= 17 && hours < 21) return "Good Evening";
    return "Good Night";
  }, [hours]);

  const displayName = useMemo(() => {
    if (!username) return "Caregiver";
    const clean = username.trim();
    if (clean.toLowerCase() === "tanmaytm") return "Tanmay TM";
    if (clean.toLowerCase() === "tanmay") return "Tanmay";
    return clean.replace(/([a-z])([A-Z])/g, "$1 $2");
  }, [username]);

  // Find next upcoming dose using local device clock
  const nextDoseInfo = useMemo<{
    medicine: Medicine | null;
    secondsRemaining: number;
  } | null>(() => {
    if (!medicines || medicines.length === 0) return null;
    let nearestMed: Medicine | null = null;
    let shortestSeconds = Infinity;
    medicines.forEach((med) => {
      const [medH, medM] = med.time.split(":").map(Number);
      const target = new Date(deviceTime);
      target.setHours(medH, medM, 0, 0);
      if (target.getTime() <= deviceTime.getTime()) {
        target.setDate(target.getDate() + 1);
      }
      const diffSec = Math.floor((target.getTime() - deviceTime.getTime()) / 1000);
      if (diffSec < shortestSeconds) {
        shortestSeconds = diffSec;
        nearestMed = med;
      }
    });
    return { medicine: nearestMed, secondsRemaining: shortestSeconds };
  }, [medicines, deviceTime]);

  const activeNextMed = nextDoseInfo?.medicine;
  const nextPatient = activeNextMed && patients ? patients[activeNextMed.patient] : null;

  const formatCountdown = (totalSec: number) => {
    if (totalSec <= 0 || !isFinite(totalSec)) return "-- : -- : --";
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, "0")}h : ${String(m).padStart(2, "0")}m : ${String(s).padStart(2, "0")}s`;
  };

  const lowStockMeds = medicines.filter((m) => m.stock <= LOW_STOCK_LIMIT);

  return (
    <div className="space-y-6">
      <NotificationPermissionBanner />

      {/* Clean Greeting & Next Dose Reminder Hero Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-800 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
                Hi, {displayName} 👋
              </h2>
            </div>
            <p className="text-emerald-100 text-sm font-medium">
              {greeting} • {String(hours).padStart(2, "0")}:{String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")} Local Time
            </p>

            {/* Next Scheduled Medicine Badge */}
            <div className="pt-2 flex flex-wrap items-center gap-2.5">
              <span className="text-xs uppercase tracking-wider text-emerald-200 font-bold">Next Dose:</span>
              {activeNextMed ? (
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/25 backdrop-blur-md border border-white/20 text-xs font-bold">
                  <PatientAvatar name={activeNextMed.patient} avatarUrl={nextPatient?.avatar} size="xs" showBorder={false} />
                  <span>
                    <strong className="text-amber-300">{activeNextMed.name}</strong> ({activeNextMed.patient}) at{" "}
                    <strong className="font-mono text-emerald-200">{activeNextMed.time}</strong>
                  </span>
                </div>
              ) : (
                <span className="text-xs text-emerald-200">No scheduled doses yet</span>
              )}
            </div>
          </div>

          {/* Clean Countdown Box */}
          <div className="bg-black/30 backdrop-blur-md border border-white/20 rounded-2xl p-4 text-center min-w-[200px]">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-200 block">
              Dose Reminder In
            </span>
            <div className="text-2xl sm:text-3xl font-black font-mono text-amber-300 mt-1">
              {nextDoseInfo ? formatCountdown(nextDoseInfo.secondsRemaining) : "-- : -- : --"}
            </div>
            <button
              onClick={() => onTriggerTestAlarm(activeNextMed?.id)}
              className="mt-3 w-full py-1.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-bold text-xs shadow-xs transition-all cursor-pointer"
            >
              🔔 Ring Alarm Now
            </button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase block">Active Patients</span>
          <span className="text-2xl font-black text-slate-900">{Object.keys(patients).length}</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase block">Total Medicines</span>
          <span className="text-2xl font-black text-emerald-600">{medicines.length}</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase block">Low Stock Alert</span>
          <span className={`text-2xl font-black ${lowStockMeds.length > 0 ? "text-amber-600" : "text-slate-400"}`}>
            {lowStockMeds.length}
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-400 uppercase block">Quick Action</span>
          <button
            onClick={() => onTriggerTestAlarm()}
            className="mt-1 py-1 px-2 bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold rounded-lg shadow-2xs"
          >
            🔔 Test Alarm
          </button>
        </div>
      </div>

      {/* Action Shortcuts */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setIsPrescriptionModalOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Scan Prescription (Gemini)</span>
        </button>
        <button
          onClick={() => setIsDoctorReportOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-xs border border-slate-300 shadow-2xs cursor-pointer"
        >
          <FileText className="w-3.5 h-3.5 text-slate-500" />
          <span>Doctor Clinical Report</span>
        </button>
      </div>

      {/* Low Stock Warning Card if any medicine is low */}
      {lowStockMeds.length > 0 && (
        <div className="p-4 sm:p-5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2.5 text-xs font-bold">
            <span className="p-1.5 rounded-xl bg-amber-200 text-amber-900 font-extrabold text-sm">⚠️</span>
            <div>
              <span className="block font-black text-amber-950">
                Low Medicine Stock Alert ({lowStockMeds.length} medicine{lowStockMeds.length > 1 ? "s" : ""})
              </span>
              <span className="text-amber-800 text-[11px] font-normal">
                {lowStockMeds.map((m) => `${m.name} (${m.stock} left)`).join(", ")}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setRefillMed(lowStockMeds[0])}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>1-Click WhatsApp Refill</span>
            </button>
            <button
              onClick={() => onNavigateToTab("medicines")}
              className="text-xs font-bold text-amber-900 hover:underline px-2 py-1 cursor-pointer"
            >
              Manage &rarr;
            </button>
          </div>
        </div>
      )}

      {/* Medicine Schedule Timeline */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
            <Clock className="w-5 h-5 text-emerald-600" />
            <span>Today's Medicine Schedule ({medicines.length})</span>
          </h3>
          <button
            onClick={() => onNavigateToTab("medicines")}
            className="text-xs text-emerald-700 font-bold hover:underline"
          >
            + Add Medicine
          </button>
        </div>

        {medicines.length === 0 ? (
          <div className="p-8 text-center text-slate-400 space-y-2">
            <Pill className="w-10 h-10 mx-auto text-slate-300" />
            <p className="text-xs">No medicines scheduled yet. Add patients and medications to begin reminders.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {medicines.map((med) => {
              const patient = patients[med.patient];
              const isLow = med.stock <= LOW_STOCK_LIMIT;
              return (
                <div key={med.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <PatientAvatar name={med.patient} avatarUrl={patient?.avatar} size="sm" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs sm:text-sm">{med.name}</span>
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-slate-100 font-bold text-slate-700">
                          {med.time}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {med.patient} • {med.dose} tab • {med.meal_timing} • Stock: {med.stock}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isLow && (
                      <button
                        onClick={() => setRefillMed(med)}
                        className="px-2 py-1 rounded-lg bg-amber-100 text-amber-800 text-[11px] font-bold cursor-pointer"
                      >
                        Refill
                      </button>
                    )}
                    <button
                      onClick={() => setEditingMed(med)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                      title="Edit Time"
                    >
                      <Clock className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onTriggerTestAlarm(med.id)}
                      className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 cursor-pointer"
                      title="Ring Alarm"
                    >
                      <Bell className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modals */}
      {editingMed && (
        <EditTimeModal
          isOpen={!!editingMed}
          onClose={() => setEditingMed(null)}
          medicine={editingMed}
          onUpdateTime={onUpdateTime}
        />
      )}
      {refillMed && (
        <PharmacyRefillModal
          isOpen={!!refillMed}
          onClose={() => setRefillMed(null)}
          medicine={refillMed}
          patient={patients[refillMed.patient]}
        />
      )}
      <DoctorReportModal
        isOpen={isDoctorReportOpen}
        onClose={() => setIsDoctorReportOpen(false)}
        patients={patients}
        medicines={medicines}
        history={[]}
        username=""
      />
      <AiPrescriptionModal
        isOpen={isPrescriptionModalOpen}
        onClose={() => setIsPrescriptionModalOpen(false)}
        onApplyMedicine={(newMed) => {
          const firstPatient = Object.keys(patients)[0] || "Self";
          // Add medicine
        }}
      />
    </div>
  );
};

// Patients Tab
export const PatientsTab: React.FC<{
  patients: Record<string, Patient>;
  medicines: Medicine[];
  onAddPatient: (patient: Patient) => void;
  onUpdatePatient: (patient: Patient) => void;
  onUpdatePatientAvatar: (patientName: string, avatarUrl: string | null) => void;
  onDeletePatient: (patientName: string) => void;
}> = ({ patients, onAddPatient, onUpdatePatient, onUpdatePatientAvatar, onDeletePatient }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [name, setName] = useState("");
  const [lang, setLang] = useState("English");
  const [phone, setPhone] = useState("");
  const [doctor, setDoctor] = useState("");
  const [pharmacy, setPharmacy] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAddPatient({
      name: name.trim(),
      lang,
      guardian_phone: phone.trim(),
      doctor: doctor.trim(),
      pharmacy: pharmacy.trim(),
      avatar,
    });
    setName("");
    setPhone("");
    setDoctor("");
    setPharmacy("");
    setAvatar(null);
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900">Patient Profiles ({Object.keys(patients).length})</h2>
          <p className="text-xs text-slate-500">Manage multilingual voice preferences and emergency phone numbers</p>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
        >
          {isAdding ? "Cancel" : "+ Add Patient"}
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xs space-y-4 text-xs">
          <AvatarPicker patientName={name} selectedAvatar={avatar} onSelectAvatar={setAvatar} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-bold text-slate-700 uppercase">Patient Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Kamala Sharma"
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Reminder Language (22 Indian Languages)</label>
              <select
                value={lang}
                onChange={(e) => setLang(e.target.value)}
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs bg-white"
              >
                {LANGUAGE_LIST.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Guardian Emergency Phone</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+919876543210"
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Doctor Name / Clinic</label>
              <input
                type="text"
                value={doctor}
                onChange={(e) => setDoctor(e.target.value)}
                placeholder="Dr. Anand (Cardiology)"
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
          </div>
          <button type="submit" className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl cursor-pointer">
            Save Patient Profile
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {Object.values(patients).map((pat) => (
          <div key={pat.name} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <PatientAvatar name={pat.name} avatarUrl={pat.avatar} size="lg" />
                <div>
                  <h3 className="font-black text-slate-900 text-sm">{pat.name}</h3>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                    {pat.lang}
                  </span>
                </div>
              </div>
              <button
                onClick={() => onDeletePatient(pat.name)}
                className="p-1.5 text-slate-400 hover:text-red-600 cursor-pointer"
                title="Delete Patient"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-slate-500 space-y-0.5 pt-1 border-t border-slate-100">
              <p>Emergency Guardian: {pat.guardian_phone || "(None set)"}</p>
              {pat.doctor && <p>Doctor: {pat.doctor}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Medicines Tab
export const MedicinesTab: React.FC<{
  medicines: Medicine[];
  patients: Record<string, Patient>;
  onAddMedicine: (med: Omit<Medicine, "id">) => void;
  onDeleteMedicine: (medId: string) => void;
  onUpdateStock: (medId: string, newStock: number) => void;
  onUpdateTime: (medId: string, newTime: string) => void;
  onTriggerAlarm: (medId?: string) => void;
}> = ({
  medicines,
  patients,
  onAddMedicine,
  onDeleteMedicine,
  onUpdateStock,
  onUpdateTime,
  onTriggerAlarm,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [name, setName] = useState("");
  const patientNames = Object.keys(patients);
  const [selectedPatient, setSelectedPatient] = useState(patientNames[0] || "");
  const [dose, setDose] = useState(1);
  const [stock, setStock] = useState(30);
  const [time, setTime] = useState("08:00");
  const [meal, setMeal] = useState<MealTiming>("After food");
  const [ringtone, setRingtone] = useState("Gentle Hospital Chime");

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAddMedicine({
      name: name.trim(),
      patient: selectedPatient || patientNames[0] || "Self",
      dose,
      stock,
      time,
      meal_timing: meal,
      ringtone,
    });
    setName("");
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900">Medicine Schedules ({medicines.length})</h2>
          <p className="text-xs text-slate-500">Configure exact alarm clock triggers and tablet dosages</p>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
        >
          {isAdding ? "Cancel" : "+ Add Medication"}
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xs space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-bold text-slate-700 uppercase">Medicine Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Metformin 500mg"
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Patient</label>
              <select
                value={selectedPatient}
                onChange={(e) => setSelectedPatient(e.target.value)}
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs bg-white"
              >
                {patientNames.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Alarm Time (HH:MM)</label>
              <input
                type="time"
                required
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Meal Timing</label>
              <select
                value={meal}
                onChange={(e) => setMeal(e.target.value as MealTiming)}
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs bg-white"
              >
                {MEAL_OPTIONS.map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Dosage (Tablets)</label>
              <input
                type="number"
                min="1"
                max="10"
                value={dose}
                onChange={(e) => setDose(Number(e.target.value))}
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 uppercase">Initial Stock (Remaining)</label>
              <input
                type="number"
                min="0"
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
                className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
          </div>
          <button type="submit" className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl cursor-pointer">
            Save Scheduled Medicine
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {medicines.map((med) => (
          <div key={med.id} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-extrabold">
                  {med.time}
                </span>
                <h3 className="font-black text-slate-900 text-base mt-1">{med.name}</h3>
                <p className="text-xs text-slate-500">{med.patient} • {med.meal_timing}</p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onTriggerAlarm(med.id)}
                  className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg cursor-pointer"
                  title="Test Ring"
                >
                  <Bell className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onDeleteMedicine(med.id)}
                  className="p-2 text-slate-400 hover:text-red-600 rounded-lg cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
              <span className="text-slate-500">Remaining: <strong className="text-slate-900">{med.stock} tablets</strong></span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onUpdateStock(med.id, Math.max(0, med.stock - 1))}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-bold"
                >
                  -1
                </button>
                <button
                  onClick={() => onUpdateStock(med.id, med.stock + 10)}
                  className="px-2 py-0.5 bg-emerald-100 hover:bg-emerald-200 rounded text-emerald-800 font-bold"
                >
                  +10 Refill
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// History Tab
export const HistoryTab: React.FC<{
  username: string;
  history: HistoryItem[];
  patients: Record<string, Patient>;
  medicines: Medicine[];
  guardianPhone: string;
  onClearHistory: () => void;
  onRecordTestDose: (item: HistoryItem) => void;
}> = ({ history, onClearHistory }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900">Dose Adherence History ({history.length})</h2>
          <p className="text-xs text-slate-500">Audit trail of doses taken, snoozed, and missed</p>
        </div>
        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="text-xs font-bold text-red-600 hover:underline cursor-pointer"
          >
            Clear History
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center text-slate-400 border border-slate-200">
          <History className="w-10 h-10 mx-auto text-slate-300 mb-2" />
          <p className="text-xs">No doses recorded yet. Take or snooze an alarm to see logs here.</p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-2xs">
          {history.slice().reverse().map((item, idx) => (
            <div key={idx} className="p-4 flex items-center justify-between text-xs">
              <div>
                <span className="font-extrabold text-slate-900">{item.patient}</span>
                <span className="text-slate-500"> took {item.med}</span>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">{item.date} {item.time}</p>
              </div>
              <div className="text-right">
                <span className={`font-extrabold ${item.status.includes("Taken") ? "text-emerald-600" : "text-amber-600"}`}>
                  {item.status}
                </span>
                <span className="block text-[10px] text-slate-400">
                  {item.offlineSaved ? "IndexedDB Fallback" : "Cloud Synced"}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// SMS & WhatsApp Alerts Tab
export const SmsTab: React.FC<{
  smsOutbox: SmsLogItem[];
  guardianSettings?: GuardianSettings;
  onUpdateGuardianSettings: (settings: GuardianSettings) => void;
  onSendDualAlert: (to: string, message: string) => Promise<any>;
  onClearSmsLog: () => void;
}> = ({ smsOutbox, onClearSmsLog }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900">Guardian Alerts Outbox ({smsOutbox.length})</h2>
          <p className="text-xs text-slate-500">Automated SMS & WhatsApp dispatch logs sent to family caregivers</p>
        </div>
        {smsOutbox.length > 0 && (
          <button onClick={onClearSmsLog} className="text-xs font-bold text-red-600 hover:underline cursor-pointer">
            Clear Logs
          </button>
        )}
      </div>

      {smsOutbox.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center text-slate-400 border border-slate-200">
          <MessageSquare className="w-10 h-10 mx-auto text-slate-300 mb-2" />
          <p className="text-xs">No alerts sent yet. Alarms automatically notify the guardian on taken/missed doses.</p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-2xs">
          {smsOutbox.slice().reverse().map((log, idx) => (
            <div key={idx} className="p-4 space-y-1 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-slate-900">{log.to}</span>
                <span className="text-[11px] text-slate-400">{log.time}</span>
              </div>
              <p className="text-slate-700 bg-slate-50 p-2 rounded-xl">{log.body}</p>
              <div className="flex items-center justify-between text-[11px] pt-1 text-slate-500">
                <span>Status: <strong className="text-emerald-700">{log.status}</strong></span>
                {log.whatsappUrl && (
                  <a href={log.whatsappUrl} target="_blank" rel="noreferrer" className="text-emerald-600 font-bold underline">
                    Open WhatsApp
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// Showcase Tab (22 Languages Voice Audio Previews & Architecture)
export const ShowcaseTab: React.FC<{
  onNavigateToTab: (tab: string) => void;
  developerEmail: string;
  developerPhone: string;
}> = () => {
  const [playingLang, setPlayingLang] = useState<string | null>(null);

  const handleTestVoice = (langKey: string) => {
    setPlayingLang(langKey);
    const voice = formatVoiceMessage(langKey, "Kamala", "Metformin 500mg", 1);
    soundEngine.speak(voice.text, voice.code, () => setPlayingLang(null));
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-black text-slate-900">22 Indian Languages Spoken Voice Showcase</h2>
        <p className="text-xs text-slate-500">Tap any regional Indian dialect below to preview speech synthesis voice reminders</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {LANGUAGE_LIST.map((langKey) => {
          const isPlaying = playingLang === langKey;
          return (
            <div key={langKey} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex items-center justify-between">
              <div>
                <span className="font-extrabold text-slate-900 text-xs block">{langKey}</span>
                <span className="text-[10px] text-slate-400 font-mono">{LANGUAGES[langKey].code}</span>
              </div>
              <button
                onClick={() => handleTestVoice(langKey)}
                className={`p-2 rounded-xl cursor-pointer ${
                  isPlaying ? "bg-emerald-600 text-white animate-pulse" : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                }`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ==========================================
// 11. MAIN APP CONTROLLER
// ==========================================

export default function App() {
  const [viewMode, setViewMode] = useState<"landing" | "app">(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("action") === "app" || window.location.hash === "#app") return "app";
    }
    return "landing";
  });

  const [loggedUsername, setLoggedUsername] = useState<string>(() => getActiveUsername());
  const [userData, setUserData] = useState<UserData>(() => getUserData(getActiveUsername()));
  const [activeTab, setActiveTab] = useState<"home" | "patients" | "medicines" | "history" | "sms" | "showcase">("home");
  const [themeMode, setThemeMode] = useState<"auto" | "day" | "night">("auto");
  const [activeAlarmId, setActiveAlarmId] = useState<string | null>(null);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isCopyrightModalOpen, setIsCopyrightModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  const [clockStyle, setClockStyle] = useState<"chronometer" | "digital_hud" | "minimal">("chronometer");
  const [activeSceneId, setActiveSceneId] = useState<string>("alpine_dawn");
  const [filmSettings, setFilmSettings] = useState<FilmSettingsState>({
    grainIntensity: "cinema35mm",
    colorGrade: "portra",
    anamorphicBars: false,
    mountainBreezeActive: false,
    breezeVolume: 0.15,
  });

  const { isBedsideActive: wakeLockActive, toggleBedside: handleToggleWakeLock } = useWakeLock();

  const commitUserData = useCallback((updated: UserData) => {
    setUserData(updated);
    saveUserData(updated);
  }, []);

  const getNowStrings = () => {
    const d = new Date();
    const timeStr = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const stamp = `${d.toLocaleDateString([], { day: "2-digit", month: "short" })} ${timeStr}`;
    return { timeStr, dateStr, stamp };
  };

  useEffect(() => {
    if (activeAlarmId) wakeLockManager.requestLock("alarm");
    else wakeLockManager.releaseLock("alarm");
  }, [activeAlarmId]);

  useEffect(() => {
    if (userData?.medicines) {
      serviceWorkerManager.syncAlarms(userData.medicines);
      nativeAlarmService.scheduleExactAlarms(userData.medicines);
    }
  }, [userData?.medicines]);

  useEffect(() => {
    serviceWorkerManager.requestNotificationPermission().catch(() => {});
    nativeAlarmService.requestPermissions().catch(() => {});
  }, []);

  const dispatchDualAlert = useCallback(
    async (toNumber: string, messageBody: string, channel: AlertChannel = "dual") => {
      const { stamp } = getNowStrings();
      const cleanPhone = normalizePhoneNumber(toNumber);
      const smsUrl = createSmsIntentUrl(cleanPhone, messageBody);
      const waUrl = createWhatsAppUrl(cleanPhone, messageBody);
      let status = "Delivered to SMS & WhatsApp";

      try {
        const res = await fetch("/api/send-dual-alert", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            to: cleanPhone,
            body: messageBody,
            apiKey: userData?.guardian_settings?.callMeBotApiKey || "",
          }),
        });
        if (res.ok) {
          const json = await res.json();
          if (json.summary) status = json.summary;
        }
      } catch {}

      setUserData((prev) => {
        const newOutbox: SmsLogItem[] = [
          ...prev.sms_outbox,
          {
            id: `alert-${Date.now()}`,
            time: stamp,
            to: cleanPhone || "(no guardian phone set)",
            body: messageBody,
            status,
            channel,
            smsUrl,
            whatsappUrl: waUrl,
          },
        ].slice(-100);
        const updated: UserData = { ...prev, sms_outbox: newOutbox };
        saveUserData(updated);
        return updated;
      });
      return { status, cleanPhone, smsUrl, waUrl };
    },
    [userData?.guardian_settings]
  );

  // Exact local clock watchdog timer (1 second interval)
  useEffect(() => {
    if (!userData || !userData.medicines) return;
    const interval = setInterval(() => {
      const now = new Date();
      const currentHHMM = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      const todayDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
      const fireKey = `${todayDate} ${currentHHMM}`;

      userData.medicines.forEach((med) => {
        let isDue = false;
        if (med.snooze_until) {
          if (new Date(med.snooze_until).getTime() <= now.getTime()) isDue = true;
        } else if (med.time === currentHHMM && med.last_fired !== fireKey) {
          isDue = true;
        }

        if (isDue && activeAlarmId !== med.id) {
          serviceWorkerManager.triggerSystemNotification(med);
          const updatedMeds = userData.medicines.map((m) =>
            m.id === med.id ? { ...m, last_fired: fireKey, snooze_until: null } : m
          );
          commitUserData({ ...userData, medicines: updatedMeds });
          setActiveAlarmId(med.id);
        }
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [userData, activeAlarmId, commitUserData]);

  const handleDoseTaken = useCallback(
    (medId: string) => {
      const med = userData.medicines.find((m) => m.id === medId);
      if (!med) {
        setActiveAlarmId(null);
        return;
      }
      const { timeStr, dateStr } = getNowStrings();
      const newStock = Math.max(0, med.stock - med.dose);
      const patient = userData.patients[med.patient];
      const guardian = patient?.guardian_phone || userData.guardian_phone || "";

      if (guardian) {
        dispatchDualAlert(guardian, `Confirmed: ${med.patient} has taken ${med.name} at ${timeStr}.`);
        if (newStock <= LOW_STOCK_LIMIT) {
          dispatchDualAlert(guardian, `ALERT: ${med.name} for ${med.patient} is low (${newStock} left). Please refill.`);
        }
      }

      const newHistoryItem: HistoryItem = {
        id: `dose-${Date.now()}`,
        time: timeStr,
        date: dateStr,
        patient: med.patient,
        med: med.name,
        status: `Taken (stock: ${newStock})`,
      };

      const updatedMeds = userData.medicines.map((m) =>
        m.id === medId ? { ...m, stock: newStock, snooze_until: null } : m
      );

      const updated: UserData = {
        ...userData,
        medicines: updatedMeds,
        history: [...userData.history, newHistoryItem],
      };
      commitUserData(updated);
      setActiveAlarmId(null);
      offlineSyncManager.recordHistoryItem(newHistoryItem, userData.username).catch(() => {});
    },
    [userData, commitUserData, dispatchDualAlert]
  );

  const handleDoseSnooze = useCallback(
    (medId: string) => {
      const med = userData.medicines.find((m) => m.id === medId);
      if (!med) {
        setActiveAlarmId(null);
        return;
      }
      const { timeStr, dateStr } = getNowStrings();
      const snoozeTarget = new Date(Date.now() + SNOOZE_MINUTES * 60 * 1000).toISOString();
      const patient = userData.patients[med.patient];
      const guardian = patient?.guardian_phone || userData.guardian_phone || "";

      if (guardian) {
        dispatchDualAlert(guardian, `Alert: ${med.patient} snoozed ${med.name}. Reminding again in 5 minutes.`);
      }

      const newHistoryItem: HistoryItem = {
        id: `snooze-${Date.now()}`,
        time: timeStr,
        date: dateStr,
        patient: med.patient,
        med: med.name,
        status: `Snoozed 5 min`,
      };

      const updatedMeds = userData.medicines.map((m) =>
        m.id === medId ? { ...m, snooze_until: snoozeTarget } : m
      );

      commitUserData({
        ...userData,
        medicines: updatedMeds,
        history: [...userData.history, newHistoryItem],
      });
      setActiveAlarmId(null);
    },
    [userData, commitUserData, dispatchDualAlert]
  );

  const handleDoseMissed = useCallback(
    (medId: string) => {
      const med = userData.medicines.find((m) => m.id === medId);
      if (!med) {
        setActiveAlarmId(null);
        return;
      }
      const { timeStr, dateStr } = getNowStrings();
      const patient = userData.patients[med.patient];
      const guardian = patient?.guardian_phone || userData.guardian_phone || "";

      if (guardian) {
        dispatchDualAlert(guardian, `EMERGENCY ALERT: ${med.patient} missed ${med.time} dose of ${med.name}. Please check immediately!`);
      }

      const newHistoryItem: HistoryItem = {
        id: `missed-${Date.now()}`,
        time: timeStr,
        date: dateStr,
        patient: med.patient,
        med: med.name,
        status: "Missed (Guardian alerted)",
      };

      commitUserData({
        ...userData,
        history: [...userData.history, newHistoryItem],
      });
      setActiveAlarmId(null);
    },
    [userData, commitUserData, dispatchDualAlert]
  );

  const activeMed = useMemo(() => {
    if (!activeAlarmId) return null;
    return userData.medicines.find((m) => m.id === activeAlarmId) || null;
  }, [activeAlarmId, userData]);

  const activePatient = useMemo(() => {
    if (!activeMed) return null;
    return userData.patients[activeMed.patient] || { name: activeMed.patient, lang: "English" };
  }, [activeMed, userData]);

  if (viewMode === "landing") {
    return (
      <>
        <PublicLandingPage
          onLaunchApp={() => setViewMode("app")}
          onOpenInstallModal={() => setIsApkModalOpen(true)}
          isLoggedIn={!!loggedUsername}
          username={loggedUsername}
        />
        <ApkInstallModal isOpen={isApkModalOpen} onClose={() => setIsApkModalOpen(false)} />
        <FloatingInstallButton onOpenManualModal={() => setIsApkModalOpen(true)} />
      </>
    );
  }

  if (!loggedUsername) {
    return (
      <AuthScreen
        onLoginSuccess={(uname) => {
          setLoggedUsername(uname);
          setUserData(getUserData(uname));
          setViewMode("app");
        }}
        onBackToLanding={() => setViewMode("landing")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-2xs">
        <Header
          username={userData.username}
          themeMode={themeMode}
          onToggleTheme={() => setThemeMode(themeMode === "day" ? "night" : "day")}
          onLogout={() => {
            setActiveUsername(null);
            setLoggedUsername("");
            setUserData(getUserData(""));
            setViewMode("landing");
          }}
          isAlarmActive={!!activeAlarmId}
          onOpenApkModal={() => setIsApkModalOpen(true)}
          onOpenCopyrightModal={() => setIsCopyrightModalOpen(true)}
          onOpenAppDetailsModal={() => setIsDetailsModalOpen(true)}
          onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
          onNotificationClick={() => setActiveTab("sms")}
          wakeLockActive={wakeLockActive}
          onToggleWakeLock={handleToggleWakeLock}
          onNavigateToLanding={() => setViewMode("landing")}
        />

        <div className="bg-white border-t border-slate-100">
          <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
            <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 no-scrollbar">
              {[
                { id: "home", label: "🏠 Home", icon: Home },
                { id: "patients", label: `👥 Patients (${Object.keys(userData.patients).length})`, icon: Users },
                { id: "medicines", label: `💊 Meds (${userData.medicines.length})`, icon: Pill },
                { id: "history", label: "📜 History", icon: History },
                { id: "sms", label: `💬 Alerts (${userData.sms_outbox.length})`, icon: MessageSquare },
                { id: "showcase", label: "✨ Showcase", icon: Sparkles },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id ? "bg-emerald-600 text-white shadow-2xs" : "text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  <span>{tab.label}</span>
                </button>
              ))}

              <div className="ml-auto flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setIsSettingsModalOpen(true)}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-300"
                >
                  <Settings className="w-3.5 h-3.5 inline mr-1" />
                  Settings
                </button>
                <button
                  onClick={() => {
                    if (userData.medicines.length > 0) setActiveAlarmId(userData.medicines[0].id);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs"
                >
                  Test Alarm
                </button>
              </div>
            </nav>
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-0">
        {activeTab === "home" && (
          <HomeTab
            username={userData.username}
            themeMode={themeMode}
            medicines={userData.medicines}
            patients={userData.patients}
            onTriggerTestAlarm={(id) => setActiveAlarmId(id || (userData.medicines[0]?.id ?? null))}
            onNavigateToTab={(t) => setActiveTab(t as any)}
            onUpdateStock={(id, stock) => {
              const updatedMeds = userData.medicines.map((m) => (m.id === id ? { ...m, stock } : m));
              commitUserData({ ...userData, medicines: updatedMeds });
            }}
            onUpdateTime={(id, newTime) => {
              const updatedMeds = userData.medicines.map((m) => (m.id === id ? { ...m, time: newTime } : m));
              commitUserData({ ...userData, medicines: updatedMeds });
            }}
            onOpenApkModal={() => setIsApkModalOpen(true)}
            onOpenCopyrightModal={() => setIsCopyrightModalOpen(true)}
            onOpenAppDetailsModal={() => setIsDetailsModalOpen(true)}
            onOpenSettings={() => setIsSettingsModalOpen(true)}
            userGuardianPhone={userData.guardian_phone || ""}
            clockStyle={clockStyle}
            onChangeClockStyle={setClockStyle}
            activeSceneId={activeSceneId}
            onSelectScene={setActiveSceneId}
            filmSettings={filmSettings}
            onUpdateFilmSettings={(up) => setFilmSettings((p) => ({ ...p, ...up }))}
          />
        )}

        {activeTab === "patients" && (
          <PatientsTab
            patients={userData.patients}
            medicines={userData.medicines}
            onAddPatient={(p) => commitUserData({ ...userData, patients: { ...userData.patients, [p.name]: p } })}
            onUpdatePatient={(p) => commitUserData({ ...userData, patients: { ...userData.patients, [p.name]: p } })}
            onUpdatePatientAvatar={(name, avatar) => {
              const pat = userData.patients[name];
              if (pat) commitUserData({ ...userData, patients: { ...userData.patients, [name]: { ...pat, avatar } } });
            }}
            onDeletePatient={(name) => {
              const newP = { ...userData.patients };
              delete newP[name];
              commitUserData({
                ...userData,
                patients: newP,
                medicines: userData.medicines.filter((m) => m.patient !== name),
              });
            }}
          />
        )}

        {activeTab === "medicines" && (
          <MedicinesTab
            medicines={userData.medicines}
            patients={userData.patients}
            onAddMedicine={(m) => {
              const newMed = { ...m, id: `med-${Date.now()}` };
              commitUserData({ ...userData, medicines: [...userData.medicines, newMed] });
            }}
            onDeleteMedicine={(id) => {
              commitUserData({ ...userData, medicines: userData.medicines.filter((m) => m.id !== id) });
            }}
            onUpdateStock={(id, stock) => {
              commitUserData({
                ...userData,
                medicines: userData.medicines.map((m) => (m.id === id ? { ...m, stock } : m)),
              });
            }}
            onUpdateTime={(id, newTime) => {
              commitUserData({
                ...userData,
                medicines: userData.medicines.map((m) => (m.id === id ? { ...m, time: newTime } : m)),
              });
            }}
            onTriggerAlarm={(id) => setActiveAlarmId(id || (userData.medicines[0]?.id ?? null))}
          />
        )}

        {activeTab === "history" && (
          <HistoryTab
            username={userData.username}
            history={userData.history}
            patients={userData.patients}
            medicines={userData.medicines}
            guardianPhone={userData.guardian_phone || ""}
            onClearHistory={() => commitUserData({ ...userData, history: [] })}
            onRecordTestDose={(item) => commitUserData({ ...userData, history: [...userData.history, item] })}
          />
        )}

        {activeTab === "sms" && (
          <SmsTab
            smsOutbox={userData.sms_outbox}
            guardianSettings={userData.guardian_settings}
            onUpdateGuardianSettings={(g) => commitUserData({ ...userData, guardian_settings: g })}
            onSendDualAlert={dispatchDualAlert}
            onClearSmsLog={() => commitUserData({ ...userData, sms_outbox: [] })}
          />
        )}

        {activeTab === "showcase" && (
          <ShowcaseTab
            onNavigateToTab={(t) => setActiveTab(t as any)}
            developerEmail="tanmayghost29@gmail.com"
            developerPhone="+91 8088901642"
          />
        )}
      </main>

      {activeMed && activePatient && (
        <AlarmModal
          medicine={activeMed}
          patient={activePatient}
          fallbackGuardianPhone={userData.guardian_phone || ""}
          onTaken={handleDoseTaken}
          onSnooze={handleDoseSnooze}
          onMissed={handleDoseMissed}
        />
      )}

      <ApkInstallModal isOpen={isApkModalOpen} onClose={() => setIsApkModalOpen(false)} />
      <CopyrightModal isOpen={isCopyrightModalOpen} onClose={() => setIsCopyrightModalOpen(false)} />
      <AppDetailsModal
        isOpen={isDetailsModalOpen}
        onClose={() => setIsDetailsModalOpen(false)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onOpenCopyrightModal={() => setIsCopyrightModalOpen(true)}
      />
      <AppSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        wakeLockActive={wakeLockActive}
        onToggleWakeLock={handleToggleWakeLock}
        themeMode={themeMode}
        onSetThemeMode={setThemeMode}
        clockStyle={clockStyle}
        onChangeClockStyle={setClockStyle}
        activeSceneId={activeSceneId}
        onSelectScene={setActiveSceneId}
        filmSettings={filmSettings}
        onUpdateFilmSettings={(up) => setFilmSettings((p) => ({ ...p, ...up }))}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onOpenCopyrightModal={() => setIsCopyrightModalOpen(true)}
        guardianPhone={userData.guardian_phone || ""}
        onUpdateGuardianPhone={(phone) => commitUserData({ ...userData, guardian_phone: phone })}
        onSendDualAlert={dispatchDualAlert}
      />

      <FloatingInstallButton onOpenManualModal={() => setIsApkModalOpen(true)} />

      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">medtake™</span>
            <span>•</span>
            <span>Proprietary Multilingual Caregiver Platform</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-800 font-bold">
              © 2026 Tammy TM (Tanmay TM). All Rights Reserved.
            </span>
            <button
              onClick={() => setIsCopyrightModalOpen(true)}
              className="text-[11px] font-bold text-amber-700 hover:text-amber-900 underline flex items-center gap-1 cursor-pointer"
            >
              <Award className="w-3.5 h-3.5 text-amber-600" />
              <span>View Certificate</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
