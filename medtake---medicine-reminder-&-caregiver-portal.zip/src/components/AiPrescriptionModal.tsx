import React, { useState, useRef } from "react";
import { Sparkles, Upload, Loader2, Check, AlertCircle, X, Camera, Pill, FileText } from "lucide-react";

interface AiPrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyMedicine: (extracted: {
    name: string;
    dose: number;
    time: string;
    mealTiming: "Before food" | "After food" | "With food" | "Empty stomach" | "Anytime";
    stock: number;
  }) => void;
}

export const AiPrescriptionModal: React.FC<AiPrescriptionModalProps> = ({
  isOpen,
  onClose,
  onApplyMedicine,
}) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [base64Data, setBase64Data] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>("image/jpeg");
  const [notes, setNotes] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setMimeType(file.type || "image/jpeg");
    const reader = new FileReader();
    reader.onload = () => {
      const resultStr = reader.result as string;
      setImagePreview(resultStr);
      const pureBase64 = resultStr.split(",")[1];
      setBase64Data(pureBase64);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!base64Data && !notes.trim()) {
      setError("Please upload an image or type medicine notes.");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/analyze-prescription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          notes: notes.trim(),
          image: base64Data ? { data: base64Data, mimeType } : undefined,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to analyze. Please check your network or try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    if (!result) return;
    onApplyMedicine({
      name: result.medicineName || "Prescribed Medicine",
      dose: result.dosageTablets || 1,
      time: result.recommendedTime || "08:00",
      mealTiming: result.mealTiming || "After food",
      stock: 30,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50 to-teal-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">
                AI Prescription & Pill Assistant
              </h3>
              <p className="text-xs text-slate-500">
                Powered by Gemini 3.8 Flash • Auto-fills dose and timing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Upload & Camera Box */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Prescription Slip, Blister Pack, or Bottle Photo
            </label>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4 text-emerald-700" />
                <span>Upload Photo / File</span>
              </button>

              <label className="flex-1 py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs">
                <Camera className="w-4 h-4" />
                <span>Snap Camera Photo</span>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
            </div>

            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-200 hover:border-emerald-500 rounded-2xl p-4 text-center cursor-pointer transition-colors bg-slate-50/70 hover:bg-emerald-50/20 flex flex-col items-center justify-center min-h-[120px]"
            >
              {imagePreview ? (
                <div className="relative group">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="max-h-36 rounded-xl object-contain mx-auto shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                  <div className="text-xs font-semibold text-emerald-700 mt-2">
                    Click to change photo
                  </div>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center">
                    <Camera className="w-4 h-4" />
                  </div>
                  <p className="text-xs font-bold text-slate-700">
                    Drop prescription image here or snap a pill strip
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Supports JPG, PNG photos of blister packs, pharmacy receipts, or doctor slips
                  </p>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {/* Quick Presets for Rapid Testing */}
            <div className="flex items-center gap-1.5 pt-1 flex-wrap">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Quick Test Samples:</span>
              <button
                type="button"
                onClick={() => setNotes("Rx: Dolo 650mg Paracetamol, 1 tab twice daily after food for fever and body ache.")}
                className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
              >
                Sample 1 (Dolo 650)
              </button>
              <button
                type="button"
                onClick={() => setNotes("Rx: Metformin 500mg SR, 1 tablet once daily morning with breakfast for Type 2 Diabetes.")}
                className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
              >
                Sample 2 (Metformin 500mg)
              </button>
              <button
                type="button"
                onClick={() => setNotes("Rx: Atorvastatin 20mg, 1 tablet at night before bed for lipid cholesterol control.")}
                className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
              >
                Sample 3 (Atorvastatin 20mg)
              </button>
            </div>
          </div>

          {/* Optional Text Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              Or Type Doctor Notes / Prescription Text
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Metformin 500mg 1 tab twice daily after food for blood sugar..."
              rows={2}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>

          {/* Analysis Action */}
          <button
            onClick={handleAnalyze}
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold text-sm shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Analyzing with Gemini...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Extract Medicine Details</span>
              </>
            )}
          </button>

          {/* Results Box */}
          {result && (
            <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-emerald-900 uppercase tracking-wider flex items-center gap-1">
                  <Check className="w-3.5 h-3.5 text-emerald-600" /> Detected Details
                </span>
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Verified
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-white p-2.5 rounded-lg border border-emerald-100">
                  <span className="text-[10px] text-slate-400 font-bold block">Medicine</span>
                  <span className="font-extrabold text-slate-900">{result.medicineName}</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-emerald-100">
                  <span className="text-[10px] text-slate-400 font-bold block">Dose & Timing</span>
                  <span className="font-bold text-slate-900">
                    {result.dosageTablets} tab @ {result.recommendedTime} ({result.mealTiming})
                  </span>
                </div>
              </div>

              {result.conditions && (
                <div className="text-xs text-slate-700">
                  <strong className="text-slate-900">Condition:</strong> {result.conditions}
                </div>
              )}

              {result.precautions && (
                <div className="text-xs text-amber-800 bg-amber-50 p-2.5 rounded-lg border border-amber-200">
                  <strong>Safety Note:</strong> {result.precautions}
                </div>
              )}

              <button
                onClick={handleApply}
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Pill className="w-3.5 h-3.5" />
                <span>Apply to Medicine Form</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
