import React, { useEffect, useState } from "react";
import { Medicine, Patient } from "../types";
import { formatVoiceMessage } from "../constants/languages";
import { soundEngine } from "../utils/audio";
import { wakeLockManager } from "../utils/wakeLock";
import { PatientAvatar } from "./PatientAvatar";
import {
  createSmsIntentUrl,
  createWhatsAppUrl,
  createPhoneCallUrl,
  normalizePhoneNumber,
} from "../utils/storage";
import {
  Volume2,
  MessageSquare,
  CheckCircle2,
  Clock,
  PhoneCall,
  Smartphone,
  ShieldAlert,
  Zap,
  Eye,
} from "lucide-react";

interface AlarmModalProps {
  medicine: Medicine;
  patient: Patient;
  fallbackGuardianPhone?: string;
  onTaken: (medId: string) => void;
  onSnooze: (medId: string) => void;
  onMissed?: (medId: string) => void;
}

export const AlarmModal: React.FC<AlarmModalProps> = ({
  medicine,
  patient,
  fallbackGuardianPhone,
  onTaken,
  onSnooze,
  onMissed,
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  // 120 seconds countdown until automated Missed Dose alert is dispatched to guardian
  const [secondsRemaining, setSecondsRemaining] = useState(120);

  // Live ticking clock for alarm display
  useEffect(() => {
    const t = setInterval(() => {
      setCurrentTime(new Date());
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(t);
          if (onMissed) {
            onMissed(medicine.id);
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [medicine.id, onMissed]);

  const voiceData = formatVoiceMessage(
    patient?.lang || "English",
    medicine.patient,
    medicine.name,
    medicine.dose
  );

  useEffect(() => {
    // Acquire Screen Wake Lock to keep display lit and device awake while ringing
    wakeLockManager.requestLock("alarm");

    // Vibrate device if supported
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate([500, 250, 500, 250, 1000]);
      } catch (e) {
        // silent catch
      }
    }

    const vibInterval = setInterval(() => {
      if (typeof navigator !== "undefined" && "vibrate" in navigator) {
        try {
          navigator.vibrate([400, 200, 400]);
        } catch (e) {}
      }
    }, 4000);

    // Start gentle chime + loud voice loop
    soundEngine.startAlarmLoop(
      medicine.ringtone || "Gentle Hospital Chime",
      voiceData.text,
      voiceData.code
    );

    return () => {
      clearInterval(vibInterval);
      soundEngine.stopAlarmLoop();
      wakeLockManager.releaseLock("alarm");
    };
  }, [medicine, patient, voiceData.text, voiceData.code]);

  const handleReplayVoice = () => {
    soundEngine.unlockContext();
    soundEngine.speak(voiceData.text, voiceData.code);
  };

  const guardianPhone = normalizePhoneNumber(
    patient?.guardian_phone || fallbackGuardianPhone || ""
  );
  const timeFormatted = currentTime.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
  const smsBodyTaken = `Confirmed: ${medicine.patient} has taken ${medicine.name} at ${timeFormatted}.`;
  const smsUrl = createSmsIntentUrl(guardianPhone, smsBodyTaken);
  const waUrl = createWhatsAppUrl(guardianPhone, smsBodyTaken);
  const callUrl = createPhoneCallUrl(guardianPhone);

  const formattedHours = String(currentTime.getHours()).padStart(2, "0");
  const formattedMinutes = String(currentTime.getMinutes()).padStart(2, "0");

  const formatTimeout = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#070B09]/95 backdrop-blur-md text-white p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
      <div className="max-w-md w-full my-auto flex flex-col items-center space-y-4 py-2">
        {/* Top Indicator Bar */}
        <div className="flex items-center justify-between w-full px-1">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/90 border border-red-700 text-red-300 text-[11px] font-extrabold uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span>Medicine Alarm Active</span>
          </div>

          <button
            onClick={handleReplayVoice}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-600 text-emerald-300 text-xs font-bold hover:bg-emerald-900 active:scale-95 transition-all cursor-pointer"
            title="Play loud voice reminder in patient's language"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>🔊 Hear Voice (Loud)</span>
          </button>
        </div>

        {/* Wake Lock Active Indicator */}
        <div className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 text-[10px] font-semibold">
          <Eye className="w-3 h-3 text-emerald-400" />
          <span>Screen Wake Lock: Active (Screen stays on while ringing)</span>
        </div>

        {/* Big Time Display */}
        <div className="text-center space-y-0.5">
          <div className="text-6xl sm:text-7xl font-black font-mono tracking-tight text-white leading-none">
            {formattedHours}:{formattedMinutes}
          </div>
          <div className="text-xs uppercase tracking-widest text-emerald-400 font-bold">
            Scheduled Dose: {medicine.time}
          </div>
        </div>

        {/* Medicine Details Card */}
        <div className="w-full bg-[#111814] border border-[#1E2E25] rounded-3xl p-4 sm:p-5 shadow-2xl space-y-3.5 text-center">
          {/* Patient Header */}
          <div className="flex items-center justify-center gap-2.5">
            <PatientAvatar
              name={medicine.patient}
              avatarUrl={patient?.avatar}
              size="sm"
            />
            <span className="text-sm sm:text-base font-bold text-slate-100">
              {medicine.patient}
            </span>
          </div>

          {/* Medicine Title */}
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-emerald-400 tracking-tight leading-tight">
              {medicine.name}
            </h2>
            {/* Centered Dose, Timing, and Stock Badges */}
            <div className="flex items-center justify-center gap-2 text-xs text-slate-300 mt-1.5 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 font-bold border border-emerald-800">
                {medicine.dose} tablet{medicine.dose > 1 ? "s" : ""}
              </span>
              <span>•</span>
              <span className="font-semibold text-slate-300">
                {medicine.meal_timing}
              </span>
              <span>•</span>
              <span className="text-amber-400 font-bold">
                {medicine.stock} tablet{medicine.stock !== 1 ? "s" : ""} left
              </span>
            </div>
          </div>

          {/* Tablet Photo ONLY IF PRESENT */}
          {Boolean(medicine.photo) && (
            <div className="flex items-center justify-center py-1">
              <img
                src={medicine.photo!}
                alt={medicine.name}
                className="max-h-24 rounded-xl object-contain shadow-xs border border-slate-700"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          {/* Spoken Native Voice Box */}
          <div className="p-3 rounded-2xl bg-[#09110D] border border-emerald-900/80 text-emerald-200 text-xs sm:text-sm font-medium leading-relaxed">
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-emerald-400 font-bold mb-1">
              <Volume2 className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
              <span>Voice in {patient?.lang || "English"} (High Volume)</span>
            </div>
            <p className="italic font-semibold text-emerald-100">
              🗣️ "{voiceData.text}"
            </p>
          </div>

          {/* Dual Automated Dispatch Notice - No Asking! */}
          <div className="p-2.5 rounded-2xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 text-xs text-left space-y-1">
            <div className="flex items-center justify-between font-bold">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <Zap className="w-3.5 h-3.5 fill-emerald-400 text-emerald-400" />
                <span>Automatic Dual-Dispatch Enabled</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-900 text-emerald-200 border border-emerald-700">
                No Prompt Needed
              </span>
            </div>
            <p className="text-[11px] text-emerald-200/90 leading-tight">
              Action automatically alerts guardian at <strong>{guardianPhone}</strong> on both <strong>Normal SMS</strong> & <strong>WhatsApp</strong>.
            </p>
          </div>

          {/* Guardian Quick Contact Bar */}
          {guardianPhone && (
            <div className="pt-1 flex flex-wrap items-center justify-center gap-2 text-xs">
              <a
                href={callUrl}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 transition-colors"
                title="Call guardian phone directly"
              >
                <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                <span>Call Guardian</span>
              </a>

              <a
                href={smsUrl}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors"
                title="View in native Messages app"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>SMS App</span>
              </a>

              <a
                href={waUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 transition-colors"
                title="View in WhatsApp"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                <span>WhatsApp</span>
              </a>
            </div>
          )}

          {/* Missed dose safety timer countdown */}
          {secondsRemaining > 0 && (
            <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
              <Clock className="w-3 h-3 text-amber-400" />
              <span>
                Auto-escalates to guardian if unanswered in{" "}
                <strong className="text-amber-300 font-mono">
                  {formatTimeout(secondsRemaining)}
                </strong>
              </span>
            </div>
          )}
        </div>

        {/* Primary Action Buttons: Snooze & Taken - Cleanly visible on screen */}
        <div className="w-full grid grid-cols-2 gap-3 pt-1">
          <button
            type="button"
            onClick={() => {
              soundEngine.stopAlarmLoop();
              onSnooze(medicine.id);
            }}
            className="w-full py-3.5 sm:py-4 px-4 rounded-2xl bg-[#142923] hover:bg-[#1A3830] active:scale-95 text-teal-200 font-black text-base sm:text-lg border border-teal-700/60 shadow-lg shadow-teal-950/40 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Clock className="w-4 h-4 text-teal-400" />
            <span>Snooze (10m)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.stopAlarmLoop();
              onTaken(medicine.id);
            }}
            className="w-full py-3.5 sm:py-4 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-base sm:text-lg border border-emerald-400/50 shadow-xl shadow-emerald-950/50 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5 text-white" />
            <span>I Have Taken It</span>
          </button>
        </div>
      </div>
    </div>
  );
};
