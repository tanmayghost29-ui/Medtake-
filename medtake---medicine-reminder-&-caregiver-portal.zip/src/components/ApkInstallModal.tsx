import React, { useState } from "react";
import { usePWAInstall } from "../utils/usePWAInstall";
import {
  Download,
  Smartphone,
  CheckCircle2,
  X,
  ExternalLink,
  ShieldCheck,
  Share2,
  AlertTriangle,
  HelpCircle,
  Sparkles,
  Zap,
} from "lucide-react";

interface ApkInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// The permanent public URL that runs 24/7 and never goes to sleep overnight
export const PERMANENT_SHARED_URL =
  "https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app";

export const ApkInstallModal: React.FC<ApkInstallModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<"instant" | "standalone">("instant");
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [showTroubleshoot, setShowTroubleshoot] = useState(true);

  if (!isOpen) return null;

  // Always use the permanent production URL so the converted APK never dies overnight
  const effectiveAppUrl =
    typeof window !== "undefined" &&
    !window.location.origin.includes("-dev-") &&
    window.location.origin.startsWith("http")
      ? window.location.origin
      : PERMANENT_SHARED_URL;

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(effectiveAppUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    }
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    }
  };

  // QR Code pointing strictly to the permanent shared URL
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(
    effectiveAppUrl
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-emerald-600 via-emerald-700 to-teal-800 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-xs">
              <Smartphone className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-200 block">
                Android Package & Installation Guide
              </span>
              <h2 className="text-lg sm:text-2xl font-black tracking-tight text-white">
                Convert Medtake to Android APK
              </h2>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-emerald-100 max-w-lg">
            Install natively on your Motorola or Android phone with fullscreen alarms, offline support, and home screen launch icon.
          </p>
        </div>

        {/* Why did yesterday's APK stop working explanation banner */}
        {showTroubleshoot && (
          <div className="bg-amber-50 border-b border-amber-200 px-5 py-3 text-xs text-amber-950">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold text-amber-900 block text-[13px]">
                    Why did yesterday's APK stop opening this morning?
                  </strong>
                  <p className="text-amber-800 mt-0.5 leading-relaxed">
                    Yesterday you converted the <strong>temporary development URL</strong> (<code>-dev-</code>). That development sandbox went to sleep overnight, causing Android to show an error and return to the Moto App Launcher.
                  </p>
                  <p className="text-emerald-800 font-bold mt-1">
                    ✅ Fix: Use the <strong>Permanent 24/7 Shared URL</strong> below or tap <strong>1-Tap Install</strong> in Chrome. It stays online forever and caches offline!
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowTroubleshoot(false)}
                className="text-amber-600 hover:text-amber-900 text-xs font-bold shrink-0 underline"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Tab switch */}
        <div className="flex border-b border-slate-200 px-5 pt-3 bg-slate-50/70">
          <button
            onClick={() => setActiveTab("instant")}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === "instant"
                ? "border-emerald-600 text-emerald-700"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            📱 Recommended: 1-Tap WebAPK (Never Expires)
          </button>
          <button
            onClick={() => setActiveTab("standalone")}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === "standalone"
                ? "border-emerald-600 text-emerald-700"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            📦 Standalone .APK File (Permanent URL)
          </button>
        </div>

        {/* Tab content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          {activeTab === "instant" ? (
            <div className="space-y-5">
              {/* Permanent URL Pill */}
              <div className="bg-slate-900 text-white p-4 rounded-2xl space-y-2 border border-slate-800 shadow-inner">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Permanent 24/7 App URL (Never Sleeps)
                  </span>
                  <span className="text-emerald-400 text-[11px] font-semibold">Active & Online</span>
                </div>
                <div className="flex items-center justify-between gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <code className="text-xs font-mono text-emerald-300 truncate select-all">
                    {effectiveAppUrl}
                  </code>
                  <button
                    onClick={handleCopyLink}
                    className="shrink-0 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs flex items-center gap-1 transition-all"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>{copiedUrl ? "Copied!" : "Copy"}</span>
                  </button>
                </div>
              </div>

              {/* Direct WebAPK Install card */}
              <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-600 fill-emerald-600" />
                    <span className="text-xs font-black text-emerald-900 uppercase tracking-wider">
                      Best & Most Reliable Method
                    </span>
                  </div>
                  <h4 className="font-black text-slate-900 text-sm sm:text-base">
                    {isInstalled
                      ? "Medtake is already installed on this phone!"
                      : "Direct 1-Tap Installation to Moto Home Screen"}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Android builds a native signed WebAPK automatically. It caches all offline files, never expires overnight, and plays medicine voice reminders on schedule.
                  </p>
                </div>

                {isInstalled ? (
                  <div className="shrink-0 px-4 py-2.5 bg-emerald-200 text-emerald-900 font-bold text-xs rounded-xl flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-800" />
                    <span>Installed on Device</span>
                  </div>
                ) : isInstallable ? (
                  <button
                    onClick={handleInstallClick}
                    className="shrink-0 px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all cursor-pointer active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>Install Android App</span>
                  </button>
                ) : (
                  <div className="shrink-0 text-center text-xs text-emerald-800 font-semibold bg-emerald-100/80 px-4 py-2.5 rounded-xl border border-emerald-300">
                    Open in Mobile Chrome or scan QR below
                  </div>
                )}
              </div>

              {/* QR Code Scan to Open on Android */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-center bg-slate-50 p-5 rounded-2xl border border-slate-200">
                <div className="flex flex-col items-center sm:items-start text-center sm:text-left space-y-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    Step 1: Open on your Motorola Phone
                  </span>
                  <h4 className="font-black text-slate-900 text-base">
                    Scan with Phone Camera
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Point your camera at the QR code to open the permanent link in Google Chrome, then follow the 3 simple steps below.
                  </p>
                  <button
                    onClick={handleCopyLink}
                    className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 hover:border-emerald-500 text-xs font-bold text-slate-700 hover:text-emerald-700 bg-white transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>{copiedUrl ? "Link Copied!" : "Copy Permanent URL"}</span>
                  </button>
                </div>

                <div className="flex justify-center">
                  <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-200 flex flex-col items-center gap-1.5">
                    <img
                      src={qrCodeUrl}
                      alt="Permanent App QR Code"
                      className="w-36 h-36 rounded-xl"
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-[10px] font-bold text-slate-400">
                      Permanent 24/7 Link
                    </span>
                  </div>
                </div>
              </div>

              {/* Mobile steps */}
              <div className="space-y-3">
                <h5 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                  3 Simple Steps on your Android Phone:
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-black text-xs flex items-center justify-center">
                      1
                    </span>
                    <strong className="block font-bold text-slate-800">Open in Chrome</strong>
                    <span className="text-slate-500">
                      Open the permanent shared link in Chrome on your phone.
                    </span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-black text-xs flex items-center justify-center">
                      2
                    </span>
                    <strong className="block font-bold text-slate-800">Tap Menu (⋮)</strong>
                    <span className="text-slate-500">
                      Tap the 3 dots in the top right corner of Chrome.
                    </span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-black text-xs flex items-center justify-center">
                      3
                    </span>
                    <strong className="block font-bold text-slate-800">Tap "Install App"</strong>
                    <span className="text-slate-500">
                      Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Standalone .apk building guide */
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-1">
                <strong className="font-bold block text-sm text-amber-900">
                  Important: Always use the Permanent URL for APK Converters!
                </strong>
                <p className="text-amber-800">
                  If you use an online tool like PWABuilder, Web2APK, or AppsGeyser, make sure you paste the <strong>Permanent URL</strong> below. Never paste a temporary <code>-dev-</code> URL, or the APK will stop working overnight.
                </p>
                <div className="mt-2 bg-white/80 p-2 rounded-lg border border-amber-300 font-mono text-[11px] text-amber-900 flex items-center justify-between">
                  <span className="truncate">{effectiveAppUrl}</span>
                  <button
                    onClick={handleCopyLink}
                    className="ml-2 font-sans font-bold text-emerald-700 hover:text-emerald-900 text-xs shrink-0"
                  >
                    {copiedUrl ? "Copied!" : "Copy"}
                  </button>
                </div>
              </div>

              {/* Method A: PWABuilder */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">
                    Option 1: Free Online APK Builder (PWABuilder)
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    Recommended APK Tool
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Microsoft's PWABuilder packages our PWA manifest into a signed Android APK package directly from your browser with full offline support.
                </p>
                <div className="pt-1 flex flex-wrap gap-2">
                  <a
                    href={`https://www.pwabuilder.com/?url=${encodeURIComponent(effectiveAppUrl)}`}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-xs transition-colors"
                  >
                    <span>Build Permanent APK on PWABuilder</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold hover:bg-slate-50 text-slate-700"
                  >
                    Copy Permanent URL
                  </button>
                </div>
              </div>

              {/* Method B: Bubblewrap CLI */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                    Option 2: Google Bubblewrap CLI (Official Google TWA tool)
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                    Developer CLI
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  To compile an APK on your computer using Google's official Bubblewrap tool:
                </p>
                <div className="bg-slate-900 text-emerald-400 p-3 rounded-xl font-mono text-[11px] space-y-1 overflow-x-auto">
                  <p className="text-slate-400"># 1. Initialize Android project using permanent manifest</p>
                  <p className="text-white">npx @bubblewrap/cli init --manifest="{effectiveAppUrl}/manifest.webmanifest"</p>
                  <p className="pt-2 text-slate-400"># 2. Build signed production APK</p>
                  <p className="text-white">npx @bubblewrap/cli build</p>
                </div>
                <p className="text-[11px] text-slate-500">
                  Produces <code>app-release-signed.apk</code> which can be sideloaded onto any Android phone.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">
            Package: <code className="bg-slate-200/60 px-1.5 py-0.5 rounded font-mono text-slate-700">com.medtake.app</code>
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
