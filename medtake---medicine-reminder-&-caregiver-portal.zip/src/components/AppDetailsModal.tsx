import React, { useState } from "react";
import {
  X,
  Mail,
  Copy,
  Check,
  ShieldCheck,
  Smartphone,
  Cpu,
  Wifi,
  Eye,
  Award,
  Sparkles,
  Mountain,
  Volume2,
  Clock,
  Radio,
  ExternalLink,
  Info,
  CheckCircle2,
  Phone,
  PhoneCall,
  MessageCircle,
} from "lucide-react";

interface AppDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenApkModal?: () => void;
  onOpenCopyrightModal?: () => void;
}

export const AppDetailsModal: React.FC<AppDetailsModalProps> = ({
  isOpen,
  onClose,
  onOpenApkModal,
  onOpenCopyrightModal,
}) => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [subject, setSubject] = useState("MedTake Helpline Support Inquiry");
  const [message, setMessage] = useState("");

  const helplineEmail = "tanmayghost29@gmail.com";
  const helplinePhone = "+91 8088901642";
  const helplinePhoneClean = "+918088901642";

  if (!isOpen) return null;

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(helplineEmail).catch(() => {});
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(helplinePhoneClean).catch(() => {});
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2500);
  };

  const mailtoLink = `mailto:${helplineEmail}?subject=${encodeURIComponent(
    subject
  )}&body=${encodeURIComponent(
    message || "Hello Tanmay,\n\nI need assistance with MedTake medicine reminders and caregiver alert configurations."
  )}`;

  const developerWhatsAppUrl = `https://wa.me/918088901642?text=${encodeURIComponent(
    "Hello Tanmay, I am using the MedTake app and have a question for the Developer Helpline."
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 relative flex flex-col no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Mountain & Film Accent Banner */}
        <div className="relative bg-gradient-to-r from-emerald-800 via-teal-900 to-slate-950 text-white p-6 sm:p-7 rounded-t-3xl overflow-hidden shrink-0">
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute bottom-0 right-0 opacity-15 pointer-events-none">
            <Mountain className="w-36 h-36" />
          </div>

          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-amber-400 shadow-inner">
                <Info className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                    App Details & Helpline
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-slate-950 tracking-wider">
                    v2.4 CINEMATIC
                  </span>
                </div>
                <p className="text-xs text-emerald-200/90 mt-0.5 font-medium">
                  MedTake Caregiver Telehealth & Alpine Mountain Edition
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-7 space-y-6 flex-1">
          {/* PRIMARY: Official Developer Helpline Contact (8088901642) */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white border-2 border-emerald-400/40 shadow-md relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-amber-400 text-slate-950 font-black shadow-xs">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-300">
                      Developer Helpline Contact
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-emerald-400/20 text-emerald-300 border border-emerald-400/30">
                      Direct Support
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-wide mt-0.5 font-mono">
                    {helplinePhone}
                  </h3>
                </div>
              </div>
              <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                Architect Hotline
              </span>
            </div>

            <p className="text-xs text-emerald-100/90 leading-relaxed mb-4">
              Direct assistance hotline with the app developer <strong>Tanmay TM</strong>. Call or chat anytime for technical inquiries, Android APK support, or custom integrations.
            </p>

            {/* Quick Actions for Developer Phone */}
            <div className="flex items-center flex-wrap gap-2.5">
              <a
                href={`tel:${helplinePhoneClean}`}
                className="flex-1 min-w-[140px] py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Call {helplinePhone}</span>
              </a>

              <a
                href={developerWhatsAppUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="flex-1 min-w-[140px] py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Helpline</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </a>

              <button
                type="button"
                onClick={handleCopyPhone}
                className="py-2.5 px-3.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedPhone ? (
                  <>
                    <Check className="w-4 h-4 text-amber-300" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-emerald-200" />
                    <span>Copy Number</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* SECONDARY: Helpline Gmail Contact Card */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-50 via-emerald-50 to-teal-50 border-2 border-emerald-300 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-600 text-white shadow-xs">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-800">
                    Official Support & Helpline Email
                  </span>
                  <h3 className="text-lg font-black text-slate-900 leading-tight">
                    {helplineEmail}
                  </h3>
                </div>
              </div>
              <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-200 text-emerald-900">
                <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                Verified
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Have questions regarding medicine alarms, offline synchronization, or guardian alerts? Reach directly to the system architect at <strong>{helplineEmail}</strong>.
            </p>

            {/* Quick Actions for Helpline Gmail */}
            <div className="flex items-center flex-wrap gap-2.5">
              <a
                href={mailtoLink}
                className="flex-1 min-w-[180px] py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <Mail className="w-4 h-4" />
                <span>Send Email to Helpline</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </a>

              <button
                type="button"
                onClick={handleCopyEmail}
                className="py-2.5 px-4 rounded-xl bg-white hover:bg-slate-50 border border-emerald-200 text-emerald-900 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
              >
                {copiedEmail ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-500" />
                    <span>Copy Gmail</span>
                  </>
                )}
              </button>
            </div>

            {/* In-app Message Quick Composer */}
            <div className="mt-4 pt-4 border-t border-emerald-200/60">
              <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                Quick Helpline Message:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your question or feedback..."
                  className="flex-1 px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
                <a
                  href={mailtoLink}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center gap-1"
                >
                  <span>Compose</span>
                </a>
              </div>
            </div>
          </div>

          {/* System Details & Architecture Grid */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-emerald-600" />
              <span>System Specifications & Diagnostics</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                    Offline Resilience
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-extrabold">
                    IndexedDB v1
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Dose history logs safely queue in IndexedDB while offline and auto-sync when online.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <Eye className="w-3.5 h-3.5 text-amber-600" />
                    Screen Wake Lock
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-extrabold">
                    W3C Standard
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Bedside Clock Mode keeps screen awake on nightstands so alarm rings without timeout.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <Radio className="w-3.5 h-3.5 text-sky-600" />
                    Background Alarms
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 font-extrabold">
                    Service Worker
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Active alarm watcher registers background catch-up on wake, lock-screen, or app minimization.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <Volume2 className="w-3.5 h-3.5 text-violet-600" />
                    Speech & Ambient Audio
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-violet-100 text-violet-800 font-extrabold">
                    22 Languages
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  High-volume synthesized voice in 22 Indian regional languages + ambient mountain breeze generator.
                </p>
              </div>
            </div>
          </div>

          {/* Alpine Mountain & Film Settings Info */}
          <div className="p-4 rounded-2xl bg-slate-900 text-slate-100 space-y-2 border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                <Mountain className="w-4 h-4" />
                <span>Cinematic Nature & Mountain Views</span>
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/10 text-slate-300">
                60 - 80 MB Media Buffer Ready
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Equipped with real-time Swiss Alpine dawn, Himalayan sunset, misty pine valleys, 35mm film grain overlays, and authentic analog chronometer movements.
            </p>
          </div>

          {/* Copyright & Certificate Links */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-600" />
              <span className="font-bold text-slate-800">
                Copyright © 2026 Tammy TM (Tanmay TM)
              </span>
            </div>

            <div className="flex items-center gap-2">
              {onOpenCopyrightModal && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenCopyrightModal();
                  }}
                  className="font-bold text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
                >
                  Certificate
                </button>
              )}
              {onOpenApkModal && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenApkModal();
                  }}
                  className="font-bold text-sky-700 hover:text-sky-900 underline cursor-pointer"
                >
                  Install APK
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 rounded-b-3xl flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
