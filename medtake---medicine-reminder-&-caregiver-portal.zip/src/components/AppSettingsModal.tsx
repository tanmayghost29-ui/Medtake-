import React, { useState, useEffect, useRef } from "react";
import {
  X,
  Settings,
  Clock,
  Eye,
  EyeOff,
  Smartphone,
  Award,
  Sun,
  Moon,
  Sparkles,
  Wind,
  Volume2,
  VolumeX,
  Watch,
  Cpu,
  Compass,
  Film,
  Mountain,
  Check,
  Camera,
  ShieldCheck,
  Mail,
  Zap,
  PhoneCall,
  MessageSquare,
  Send,
  CheckCircle2,
  Download,
  Upload,
  FileText,
  FileCheck,
} from "lucide-react";
import { FilmSettingsState, MOUNTAIN_SCENES } from "./NatureMountainView";
import { soundEngine } from "../utils/audio";
import { LANGUAGES, formatVoiceMessage } from "../constants/languages";
import {
  normalizePhoneNumber,
  createPhoneCallUrl,
  createWhatsAppUrl,
  createSmsIntentUrl,
  getUserData,
  getActiveUsername,
  saveUserData,
} from "../utils/storage";

interface AppSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  // Bedside WakeLock
  wakeLockActive: boolean;
  onToggleWakeLock: () => void;
  // Theme
  themeMode: "auto" | "day" | "night";
  onToggleTheme: () => void;
  onSetThemeMode: (mode: "auto" | "day" | "night") => void;
  // Clock Style
  clockStyle: "chronometer" | "digital_hud" | "minimal";
  onChangeClockStyle: (style: "chronometer" | "digital_hud" | "minimal") => void;
  // Mountain & Film Settings
  activeSceneId: string;
  onSelectScene: (id: string) => void;
  filmSettings: FilmSettingsState;
  onUpdateFilmSettings: (settings: Partial<FilmSettingsState>) => void;
  // APK & Copyright Modals
  onOpenApkModal: () => void;
  onOpenCopyrightModal: () => void;
  // Guardian & Automated Alerts
  guardianPhone?: string;
  onUpdateGuardianPhone?: (phone: string) => void;
  onSendDualAlert?: (to: string, message: string) => Promise<any>;
}

export const AppSettingsModal: React.FC<AppSettingsModalProps> = ({
  isOpen,
  onClose,
  wakeLockActive,
  onToggleWakeLock,
  themeMode,
  onSetThemeMode,
  clockStyle,
  onChangeClockStyle,
  activeSceneId,
  onSelectScene,
  filmSettings,
  onUpdateFilmSettings,
  onOpenApkModal,
  onOpenCopyrightModal,
  guardianPhone = "",
  onUpdateGuardianPhone,
  onSendDualAlert,
}) => {
  const [testLang, setTestLang] = useState("Kannada (ಕನ್ನಡ)");
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [guardianFeedback, setGuardianFeedback] = useState<string | null>(null);
  const [isDispatchingTest, setIsDispatchingTest] = useState(false);
  const [phoneInput, setPhoneInput] = useState(guardianPhone || "");
  const [phoneSavedFeedback, setPhoneSavedFeedback] = useState(false);

  // Sync phoneInput when guardianPhone prop updates
  useEffect(() => {
    if (guardianPhone) {
      setPhoneInput(guardianPhone);
    }
  }, [guardianPhone]);

  const cleanGuardian = normalizePhoneNumber(phoneInput || guardianPhone || "");
  const callGuardianUrl = createPhoneCallUrl(cleanGuardian);
  const directWaUrl = createWhatsAppUrl(
    cleanGuardian,
    `medtake check: Automated guardian alerts active for ${cleanGuardian || "guardian"}.`
  );
  const directSmsUrl = createSmsIntentUrl(
    cleanGuardian,
    `medtake check: Automated guardian alerts active for ${cleanGuardian || "guardian"}.`
  );

  const handleSaveGuardianPhone = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = normalizePhoneNumber(phoneInput);
    if (onUpdateGuardianPhone) {
      onUpdateGuardianPhone(clean);
    }
    setPhoneSavedFeedback(true);
    setTimeout(() => setPhoneSavedFeedback(false), 2500);
  };

  const handleTestVoiceSpeech = () => {
    setIsTestingVoice(true);
    soundEngine.unlockContext();
    const voiceData = formatVoiceMessage(
      testLang,
      "Kamala Devi",
      "Dolo 650",
      1
    );
    soundEngine.speak(voiceData.text, voiceData.code, () => {
      setIsTestingVoice(false);
    });
  };

  const [backupFeedback, setBackupFeedback] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDownloadBackup = () => {
    const currentUsername = getActiveUsername();
    const fullData = getUserData(currentUsername);

    const backupObject = {
      appName: "medtake",
      version: "2.4.0",
      exportTimestamp: new Date().toISOString(),
      exportDateFormatted: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
      user: {
        username: fullData.username,
        email: fullData.email,
        guardian_phone: cleanGuardian,
      },
      patients: fullData.patients,
      medicines: fullData.medicines,
      history: fullData.history,
      sms_outbox: fullData.sms_outbox,
      guardian_settings: fullData.guardian_settings,
    };

    const blob = new Blob([JSON.stringify(backupObject, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const dateStr = new Date().toISOString().split("T")[0];
    a.href = url;
    a.download = `medtake-profile-backup-${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setBackupFeedback(`✓ Safe-keeping backup exported as medtake-profile-backup-${dateStr}.json`);
    setTimeout(() => setBackupFeedback(null), 5000);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (parsed && (parsed.patients || parsed.medicines)) {
          const currentUsername = getActiveUsername();
          const current = getUserData(currentUsername);
          const merged = {
            ...current,
            patients: parsed.patients || current.patients,
            medicines: parsed.medicines || current.medicines,
            history: parsed.history || current.history,
            sms_outbox: parsed.sms_outbox || current.sms_outbox,
            guardian_settings: parsed.guardian_settings || current.guardian_settings,
          };
          saveUserData(merged);
          setBackupFeedback("✓ Successfully restored profile backup! Reloading...");
          setTimeout(() => window.location.reload(), 1200);
        } else {
          alert("The selected file does not appear to be a valid medtake backup JSON.");
        }
      } catch (err: any) {
        alert("Error parsing backup JSON file: " + err.message);
      }
    };
    reader.readAsText(file);
  };

  const handleTestGuardianDispatch = async () => {
    if (!cleanGuardian) {
      setGuardianFeedback("Please enter and save a guardian phone number first.");
      return;
    }
    if (!onSendDualAlert) return;
    setIsDispatchingTest(true);
    setGuardianFeedback(null);
    try {
      await onSendDualAlert(
        cleanGuardian,
        `medtake Guardian Test: Automated SMS & WhatsApp alerts configured for ${cleanGuardian}.`
      );
      setGuardianFeedback(`✓ Dispatched to ${cleanGuardian} via SMS & WhatsApp!`);
    } catch (e: any) {
      setGuardianFeedback("Failed: " + e.message);
    } finally {
      setIsDispatchingTest(false);
    }
  };
  if (!isOpen) return null;

  // Toggle synthesized mountain wind breeze sound
  const handleToggleBreeze = () => {
    soundEngine.unlockContext();
    const isNowActive = soundEngine.toggleMountainBreeze(
      filmSettings.breezeVolume
    );
    onUpdateFilmSettings({ mountainBreezeActive: isNowActive });
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    soundEngine.setMountainBreezeVolume(val);
    onUpdateFilmSettings({ breezeVolume: val });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 relative flex flex-col no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800 shadow-xs">
              <Settings className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                App Settings & Ambient Controls
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Bedside clock, themes, clock dial, mountain ambience, APK & certificate
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-6">
          {/* 1. BEDSIDE MEDICINE CLOCK (SCREEN WAKE LOCK) */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Clock className="w-5 h-5 text-amber-600" />
                <div>
                  <h4 className="text-sm font-black text-amber-950">
                    Bedside Medicine Clock (Keep Screen Awake)
                  </h4>
                  <p className="text-xs text-amber-800/80">
                    Prevents display timeout so your phone stays on as an active nightstand clock
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onToggleWakeLock}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-xs ${
                  wakeLockActive
                    ? "bg-amber-500 text-slate-950 ring-2 ring-amber-400"
                    : "bg-white text-slate-700 border border-slate-300 hover:bg-slate-50"
                }`}
              >
                {wakeLockActive ? (
                  <>
                    <Eye className="w-4 h-4 text-slate-950" />
                    <span>Bedside: ON</span>
                  </>
                ) : (
                  <>
                    <EyeOff className="w-4 h-4 text-slate-400" />
                    <span>Turn ON</span>
                  </>
                )}
              </button>
            </div>
            {wakeLockActive && (
              <div className="flex items-center gap-2 text-[11px] text-emerald-800 font-semibold bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Screen Wake Lock is active. Alarms will ring prominently without device lock.</span>
              </div>
            )}
          </div>

          {/* 2. CLOCK FACE DIAL STYLE */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Watch className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-black text-slate-900">
                Clock Dial Style
              </h4>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {[
                {
                  id: "chronometer" as const,
                  label: "Alpine Dial",
                  desc: "Swiss luxury mechanical dial with smooth second sweep",
                  icon: Watch,
                },
                {
                  id: "digital_hud" as const,
                  label: "Cinema HUD",
                  desc: "35mm digital film cybernetic HUD display",
                  icon: Cpu,
                },
                {
                  id: "minimal" as const,
                  label: "Minimal",
                  desc: "Modern typography and crisp analog motion",
                  icon: Compass,
                },
              ].map((style) => {
                const Icon = style.icon;
                const isSelected = clockStyle === style.id;
                return (
                  <button
                    key={style.id}
                    type="button"
                    onClick={() => onChangeClockStyle(style.id)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer relative ${
                      isSelected
                        ? "border-emerald-500 bg-emerald-50/70 shadow-xs ring-1 ring-emerald-400"
                        : "border-slate-200 bg-white hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900">
                        <Icon className={`w-3.5 h-3.5 ${isSelected ? "text-emerald-600" : "text-slate-400"}`} />
                        <span>{style.label}</span>
                      </div>
                      {isSelected && (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 leading-snug">
                      {style.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. NATURE MOUNTAIN BREEZE SOUND */}
          <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200/70 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Wind className="w-5 h-5 text-emerald-700" />
                <div>
                  <h4 className="text-sm font-black text-slate-900">
                    Mountain Breeze Ambient Sound
                  </h4>
                  <p className="text-xs text-slate-600">
                    Real-time synthesized alpine wind breeze sound synthesized via Web Audio
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleToggleBreeze}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-xs ${
                  filmSettings.mountainBreezeActive
                    ? "bg-emerald-600 text-white ring-2 ring-emerald-400"
                    : "bg-white text-slate-700 border border-slate-300 hover:bg-slate-50"
                }`}
              >
                {filmSettings.mountainBreezeActive ? (
                  <>
                    <Volume2 className="w-4 h-4 text-white" />
                    <span>Breeze: ON</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-4 h-4 text-slate-400" />
                    <span>Turn ON</span>
                  </>
                )}
              </button>
            </div>

            {/* Breeze Volume */}
            <div className="flex items-center gap-3 pt-2 border-t border-emerald-100">
              <span className="text-xs font-bold text-slate-700 shrink-0">
                Wind Volume:
              </span>
              <input
                type="range"
                min="0.05"
                max="0.4"
                step="0.05"
                value={filmSettings.breezeVolume}
                onChange={handleVolumeChange}
                className="w-full accent-emerald-600 cursor-pointer"
              />
              <span className="text-xs font-mono font-bold text-slate-600 shrink-0">
                {Math.round(filmSettings.breezeVolume * 100)}%
              </span>
            </div>
          </div>

          {/* 4. THEME MODE */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Sun className="w-4 h-4 text-amber-500" />
              <h4 className="text-sm font-black text-slate-900">
                Theme & Sky Mode
              </h4>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: "auto" as const, label: "Auto Sky", icon: Sparkles, desc: "Syncs with sun" },
                { id: "day" as const, label: "Daylight", icon: Sun, desc: "Light theme" },
                { id: "night" as const, label: "Bedside Night", icon: Moon, desc: "Dark theme" },
              ].map((m) => {
                const Icon = m.icon;
                const isSelected = themeMode === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onSetThemeMode(m.id)}
                    className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
                      isSelected
                        ? "border-emerald-500 bg-emerald-50/70 shadow-xs ring-1 ring-emerald-400 text-emerald-950"
                        : "border-slate-200 bg-white hover:bg-slate-50 text-slate-700"
                    }`}
                  >
                    <Icon className={`w-4 h-4 mx-auto mb-1 ${isSelected ? "text-emerald-600" : "text-slate-400"}`} />
                    <div className="text-xs font-bold">{m.label}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{m.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5. MOUNTAIN SCENIC VISTAS */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Mountain className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-black text-slate-900">
                Mountain Scenic Background
              </h4>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {MOUNTAIN_SCENES.map((scene) => (
                <button
                  key={scene.id}
                  type="button"
                  onClick={() => onSelectScene(scene.id)}
                  className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer relative overflow-hidden ${
                    activeSceneId === scene.id
                      ? "border-emerald-500 bg-emerald-50 ring-2 ring-emerald-400/50 shadow-xs"
                      : "border-slate-200 bg-white hover:bg-slate-50"
                  }`}
                >
                  <div className="text-xs font-black text-slate-900 truncate">
                    {scene.name}
                  </div>
                  <div className="text-[10px] text-slate-500 capitalize mt-0.5">
                    {scene.theme}
                  </div>
                  {activeSceneId === scene.id && (
                    <div className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* 6. 35MM FILM GRAIN & COLOR GRADING */}
          <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-4 shadow-md">
            <div className="flex items-center gap-2">
              <Film className="w-4 h-4 text-amber-400" />
              <h4 className="text-sm font-black text-white">
                35mm Cinematic Film Grade & Grain
              </h4>
            </div>

            {/* Grain */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-white/70 uppercase tracking-wider block">
                Film Grain Stock:
              </label>
              <div className="flex items-center gap-1.5 flex-wrap">
                {(
                  [
                    { id: "none", label: "Clean Digital" },
                    { id: "subtle", label: "Fine Grain (16mm)" },
                    { id: "cinema35mm", label: "Cinema 35mm" },
                    { id: "heavy", label: "Heavy Vintage" },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => onUpdateFilmSettings({ grainIntensity: opt.id })}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      filmSettings.grainIntensity === opt.id
                        ? "bg-amber-400 text-slate-950 border-amber-300"
                        : "bg-white/10 border-white/15 text-white/80 hover:bg-white/20"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Look */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-white/70 uppercase tracking-wider block">
                Color Grade:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                {(
                  [
                    { id: "natural", label: "Pure Alpine Air" },
                    { id: "portra", label: "Kodak Portra 400" },
                    { id: "velvia", label: "Fujifilm Velvia" },
                    { id: "teal_orange", label: "Teal & Orange" },
                    { id: "noir", label: "35mm Silver Noir" },
                  ] as const
                ).map((grade) => (
                  <button
                    key={grade.id}
                    type="button"
                    onClick={() => onUpdateFilmSettings({ colorGrade: grade.id })}
                    className={`px-2 py-1.5 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                      filmSettings.colorGrade === grade.id
                        ? "bg-emerald-500 text-white border-emerald-400"
                        : "bg-white/10 border-white/15 text-white/80 hover:bg-white/20"
                    }`}
                  >
                    {grade.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Letterbox toggle */}
            <label className="flex items-center gap-2.5 cursor-pointer pt-1 border-t border-white/10">
              <input
                type="checkbox"
                checked={filmSettings.anamorphicBars}
                onChange={(e) =>
                  onUpdateFilmSettings({ anamorphicBars: e.target.checked })
                }
                className="w-4 h-4 rounded-md accent-emerald-500"
              />
              <span className="text-xs font-bold text-white">
                2.39:1 Anamorphic Cinema Letterbox
              </span>
            </label>
          </div>

          {/* 7. DYNAMIC GUARDIAN DISPATCH (PROFILE SETTINGS) */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-900 to-teal-900 text-white shadow-lg space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/30 text-emerald-300 border border-emerald-400/30">
                  <Zap className="w-5 h-5 fill-emerald-400 text-emerald-400" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <span>Guardian Profile Settings</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/30">
                      Dynamic Recipient
                    </span>
                  </h4>
                  <p className="text-xs text-emerald-200/80">
                    Dual Cellular SMS + WhatsApp Automated Alert Destination
                  </p>
                </div>
              </div>

              {cleanGuardian ? (
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-400/40 text-emerald-300 font-mono text-xs font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>{cleanGuardian}</span>
                </div>
              ) : (
                <span className="text-xs text-amber-300 font-bold bg-amber-950/60 px-2.5 py-0.5 rounded-full border border-amber-500/40">
                  Not Set
                </span>
              )}
            </div>

            {/* Editable Guardian Phone Input Form */}
            <form onSubmit={handleSaveGuardianPhone} className="p-3.5 rounded-xl bg-slate-950/40 border border-emerald-400/30 space-y-2.5">
              <label className="block text-xs font-bold text-emerald-200">
                Guardian Recipient Phone Number (Primary):
              </label>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="tel"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  placeholder="e.g. +91 9876543210 or your guardian's number"
                  className="flex-1 px-3 py-2 rounded-xl bg-white/10 border border-emerald-400/40 text-white placeholder-emerald-200/50 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-emerald-400 font-medium"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{phoneSavedFeedback ? "Saved!" : "Save Number"}</span>
                </button>
              </div>
              <p className="text-[11px] text-emerald-300/80">
                All medicine dose confirmations, snoozes, missed dose warnings, and refill stock notices dynamically route to this number (unless overridden on an individual patient profile).
              </p>
            </form>

            {phoneSavedFeedback && (
              <div className="p-2.5 rounded-xl bg-emerald-500/30 border border-emerald-400 text-xs text-emerald-100 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>Guardian phone number updated in profile settings!</span>
              </div>
            )}

            {guardianFeedback && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400 text-xs text-emerald-100 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>{guardianFeedback}</span>
              </div>
            )}

            {/* Quick Actions for dynamically configured Guardian */}
            {cleanGuardian && (
              <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                <a
                  href={callGuardianUrl}
                  className="px-3 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold flex items-center gap-1.5 transition-all shadow-xs"
                  title={`Call ${cleanGuardian} directly`}
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call Guardian</span>
                </a>

                <a
                  href={directSmsUrl}
                  className="px-3 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold flex items-center gap-1.5 transition-all border border-white/20"
                  title="Send direct SMS"
                >
                  <Smartphone className="w-3.5 h-3.5 text-emerald-300" />
                  <span>SMS App</span>
                </a>

                <a
                  href={directWaUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 transition-all shadow-xs"
                  title="Open WhatsApp chat"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>

                {onSendDualAlert && (
                  <button
                    type="button"
                    onClick={handleTestGuardianDispatch}
                    disabled={isDispatchingTest}
                    className="px-3 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black flex items-center gap-1.5 transition-all shadow-xs cursor-pointer disabled:opacity-60 ml-auto"
                  >
                    <Send className="w-3 h-3" />
                    <span>{isDispatchingTest ? "Sending..." : "⚡ Test Auto-Alert"}</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* 8. 22 INDIAN LANGUAGES LOUD VOICE TESTER */}
          <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                  <Volume2 className="w-4 h-4 text-emerald-700" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">
                    Loud Spoken Voice Tester (22 Indian Languages)
                  </h4>
                  <p className="text-xs text-slate-500">
                    Test speech clarity and pronunciation for multilingual voice alarms
                  </p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-bold">
                Max Vol 1.0
              </span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={testLang}
                onChange={(e) => setTestLang(e.target.value)}
                className="flex-1 px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-emerald-500 bg-white"
              >
                {Object.keys(LANGUAGES).map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={handleTestVoiceSpeech}
                disabled={isTestingVoice}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-xs disabled:bg-slate-300 shrink-0"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>{isTestingVoice ? "Speaking..." : "🔊 Test Loud Voice"}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              Spoken alarms announce patient name, medicine dose, and instructions in regional speech.
            </p>
          </div>

          {/* 9. BACKUP DATA & SAFE-KEEPING (DOWNLOAD JSON) */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 text-white shadow-lg space-y-3.5 border border-slate-800">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <span>Backup Profile Data (Safe-Keeping JSON)</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/30">
                      Offline Backup
                    </span>
                  </h4>
                  <p className="text-xs text-slate-300">
                    Export entire patient profiles, medicine dosages, schedules & guardian contacts
                  </p>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Download your complete patient health records, prescribed doses, scheduled times, adherence streak, and guardian configurations as an offline <strong>JSON file</strong> for secure storage and safe-keeping.
            </p>

            {backupFeedback && (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-400 text-xs text-emerald-200 flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{backupFeedback}</span>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center gap-2"
                title="Download complete JSON backup file"
              >
                <Download className="w-4 h-4" />
                <span>📥 Download Backup (.json)</span>
              </button>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImportFile}
                accept=".json,application/json"
                className="hidden"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-slate-200 font-bold text-xs border border-white/20 transition-all cursor-pointer flex items-center gap-2"
                title="Restore profile from previously exported JSON file"
              >
                <Upload className="w-4 h-4 text-slate-300" />
                <span>Restore from JSON</span>
              </button>
            </div>
          </div>

          {/* 10. APP INSTALL & OFFICIAL CERTIFICATE */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenApkModal();
              }}
              className="p-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-between transition-all cursor-pointer shadow-xs active:scale-98"
            >
              <div className="flex items-center gap-2.5 text-left">
                <Smartphone className="w-5 h-5" />
                <div>
                  <div className="text-xs font-black">Install Android APK / App</div>
                  <div className="text-[10px] text-emerald-100">Native mobile installation file</div>
                </div>
              </div>
              <span className="text-xs font-bold bg-white/20 px-2 py-0.5 rounded-md">APK</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenCopyrightModal();
              }}
              className="p-3.5 rounded-2xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-950 flex items-center justify-between transition-all cursor-pointer shadow-xs active:scale-98"
            >
              <div className="flex items-center gap-2.5 text-left">
                <Award className="w-5 h-5 text-amber-700" />
                <div>
                  <div className="text-xs font-black">© Tammy TM Certificate</div>
                  <div className="text-[10px] text-amber-800">Official Ownership & Copyright</div>
                </div>
              </div>
              <span className="text-xs font-bold bg-amber-200/80 px-2 py-0.5 rounded-md">View</span>
            </button>
          </div>

          {/* Support Helpline Footer */}
          <div className="p-3 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-between text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-emerald-600" />
              <span>Helpline Support: <strong>tanmayghost29@gmail.com</strong></span>
            </div>
            <span className="text-[11px] font-bold text-emerald-700">MedTake v2.4</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end rounded-b-3xl">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
          >
            Done & Apply
          </button>
        </div>
      </div>
    </div>
  );
};
