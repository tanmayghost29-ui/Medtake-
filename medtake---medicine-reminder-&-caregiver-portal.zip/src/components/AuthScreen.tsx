import React, { useState } from "react";
import { authenticateUser, registerUser } from "../utils/storage";
import {
  ShieldCheck,
  Moon,
  Globe2,
  ArrowRight,
  Sparkles,
  AlertCircle,
  Eye,
  EyeOff,
  User,
  Mail,
  Lock,
  CheckCircle2,
} from "lucide-react";

interface AuthScreenProps {
  onLoginSuccess: (username: string) => void;
  onBackToLanding?: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  onLoginSuccess,
  onBackToLanding,
}) => {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Sign up fields
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupConfirmPassword, setSignupConfirmPassword] = useState("");
  const [showSignupPassword, setShowSignupPassword] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessNotice(null);

    const cleanIdentifier = identifier.trim();
    const cleanPassword = password.trim();

    if (!cleanIdentifier) {
      setError("Please enter your email address or username.");
      return;
    }
    if (!cleanPassword) {
      setError("Please enter your password.");
      return;
    }

    setIsSubmitting(true);
    try {
      const res = authenticateUser(cleanIdentifier, cleanPassword);
      if (res.success && res.username) {
        onLoginSuccess(res.username);
      } else {
        setError(res.message || "Invalid credentials. Please verify your details.");
      }
    } catch {
      setError("An unexpected error occurred during sign in. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessNotice(null);

    const cleanName = signupName.trim();
    const cleanEmail = signupEmail.trim();
    const cleanPass = signupPassword.trim();
    const cleanConfirm = signupConfirmPassword.trim();

    if (!cleanName) {
      setError("Please enter your full name or username.");
      return;
    }
    if (!cleanEmail) {
      setError("Please enter your email address.");
      return;
    }
    if (!cleanEmail.includes("@") || !cleanEmail.includes(".")) {
      setError("Please enter a valid email address.");
      return;
    }
    if (!cleanPass) {
      setError("Please create a password.");
      return;
    }
    if (cleanPass.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }
    if (cleanPass !== cleanConfirm) {
      setError("Passwords do not match. Please re-enter identical passwords.");
      return;
    }

    setIsSubmitting(true);
    try {
      const res = registerUser(cleanName, cleanEmail, cleanPass);
      if (res.success && res.username) {
        setSuccessNotice("Account created successfully! Logging you in...");
        setTimeout(() => {
          onLoginSuccess(res.username!);
        }, 300);
      } else {
        setError(res.message || "Failed to create account. Please try again.");
      }
    } catch {
      setError("An unexpected error occurred during account creation. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#060D0A] text-slate-100 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8">
      {/* Brand Header */}
      <div className="max-w-6xl mx-auto w-full mb-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <svg
            width="46"
            height="46"
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="drop-shadow-md"
          >
            <rect width="100" height="100" rx="24" fill="#059669" />
            <rect x="42" y="14" width="16" height="6" rx="3" fill="#FFFFFF" />
            <circle
              cx="50"
              cy="54"
              r="30"
              stroke="#FFFFFF"
              strokeWidth="7"
              fill="none"
            />
            <line
              x1="50"
              y1="54"
              x2="50"
              y2="34"
              stroke="#FBBF24"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <line
              x1="50"
              y1="54"
              x2="68"
              y2="65"
              stroke="#FBBF24"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <g transform="translate(62,60) rotate(35)">
              <rect
                x="0"
                y="0"
                width="18"
                height="30"
                rx="9"
                fill="#F59E0B"
                stroke="#FFFFFF"
                strokeWidth="4"
              />
              <line
                x1="0"
                y1="15"
                x2="18"
                y2="15"
                stroke="#FFFFFF"
                strokeWidth="3"
              />
            </g>
          </svg>
          <span className="text-3xl font-black text-emerald-400 tracking-tight">
            med<span className="text-white">take</span>
          </span>
        </div>

        {onBackToLanding && (
          <button
            type="button"
            onClick={onBackToLanding}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-emerald-800/80 text-emerald-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <span>&larr; Public Website</span>
          </button>
        )}
      </div>

      <div className="max-w-6xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        {/* Left Column: Product Information & Patient Safety */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-600 text-emerald-300 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Smart Medication Alarm & Telehealth Portal</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight leading-[1.1]">
            Never miss<br />a dose again.
          </h1>

          <p className="text-slate-200 text-base sm:text-lg leading-relaxed max-w-xl font-normal">
            medtake turns your family's medicine schedule into fullscreen clock alarms with tablet photos, spoken voice alerts in{" "}
            <strong className="text-emerald-300 font-bold underline decoration-emerald-500">all 22 official Indian languages</strong>, and direct SMS alerts to guardians.
          </p>

          <div className="space-y-4 pt-2">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-900/80 border border-emerald-600 text-emerald-300 shrink-0 mt-0.5">
                <Globe2 className="w-4 h-4" />
              </div>
              <div>
                <strong className="text-sm text-white block font-bold">
                  🇮🇳 22 Indian Languages + English
                </strong>
                <span className="text-xs text-slate-300 leading-normal">
                  Spoken native voice alerts in Kannada, Hindi, Tamil, Telugu, Malayalam, Marathi, Bengali, Odia, Gujarati, Punjabi, and 12 more.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-amber-900/80 border border-amber-600 text-amber-300 shrink-0 mt-0.5">
                <Moon className="w-4 h-4" />
              </div>
              <div>
                <strong className="text-sm text-white block font-bold">
                  🌅 Synchronized Day / Night Bedside Clock
                </strong>
                <span className="text-xs text-slate-300 leading-normal">
                  Real-time clock synchronized directly to your phone's hardware clock with keep-awake bedside alarm mode.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-sky-900/80 border border-sky-600 text-sky-300 shrink-0 mt-0.5">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <strong className="text-sm text-white block font-bold">
                  📱 Real Guardian Phone Text Alerts
                </strong>
                <span className="text-xs text-slate-300 leading-normal">
                  Direct mobile text messages delivered to family guardians upon dose confirmation, snooze, or low inventory.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Clean, Production Auth Card */}
        <div className="lg:col-span-5">
          <div className="bg-[#0F1B15] rounded-3xl border border-emerald-900/70 shadow-2xl p-6 sm:p-8 space-y-6">
            {/* Mode switch (Sign In / Sign Up) */}
            <div className="flex p-1 rounded-2xl bg-[#08120D] border border-emerald-900/60">
              <button
                type="button"
                onClick={() => {
                  setMode("signin");
                  setError(null);
                  setSuccessNotice(null);
                }}
                className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  mode === "signin"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode("signup");
                  setError(null);
                  setSuccessNotice(null);
                }}
                className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  mode === "signup"
                    ? "bg-emerald-600 text-white shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Create Account (Sign Up)
              </button>
            </div>

            {/* Error Banner */}
            {error && (
              <div className="p-3 bg-red-950/90 border border-red-700 text-red-200 text-xs font-medium rounded-xl flex items-center gap-2 animate-shake">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span className="leading-snug">{error}</span>
              </div>
            )}

            {/* Success Banner */}
            {successNotice && (
              <div className="p-3 bg-emerald-950/90 border border-emerald-600 text-emerald-200 text-xs font-medium rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span className="leading-snug">{successNotice}</span>
              </div>
            )}

            {mode === "signin" ? (
              <form onSubmit={handleSignIn} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-200 mb-1.5 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Email or Username</span>
                  </label>
                  <input
                    type="text"
                    name="username"
                    autoComplete="username"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="Enter your email or username"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-[#08120D] border border-emerald-900/80 text-white placeholder:text-slate-500 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Accepts either your registered username or email address.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-200 mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Password</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-[11px] text-slate-400 hover:text-emerald-300 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      {showPassword ? (
                        <>
                          <EyeOff className="w-3.5 h-3.5" />
                          <span>Hide</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-3.5 h-3.5" />
                          <span>Show</span>
                        </>
                      )}
                    </button>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      name="password"
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      required
                      className="w-full px-4 py-3 rounded-xl bg-[#08120D] border border-emerald-900/80 text-white placeholder:text-slate-500 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Primary Sign In Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 disabled:opacity-60 text-white font-bold text-sm shadow-lg shadow-emerald-950/60 transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
                >
                  <span>{isSubmitting ? "Signing in..." : "Sign In"}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setMode("signup");
                      setError(null);
                    }}
                    className="text-xs text-slate-400 hover:text-emerald-300 transition-colors cursor-pointer"
                  >
                    Don't have an account yet? <span className="font-bold text-emerald-400 underline">Create one now</span>
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSignUp} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-200 mb-1.5 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Full Name or Username</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    autoComplete="name"
                    value={signupName}
                    onChange={(e) => setSignupName(e.target.value)}
                    placeholder="e.g. Sarah Jenkins"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-[#08120D] border border-emerald-900/80 text-white placeholder:text-slate-500 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-200 mb-1.5 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Email Address</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    autoComplete="email"
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                    placeholder="e.g. sarah.jenkins@example.com"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-[#08120D] border border-emerald-900/80 text-white placeholder:text-slate-500 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-200 mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Password (min 6 characters)</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowSignupPassword(!showSignupPassword)}
                      className="text-[11px] text-slate-400 hover:text-emerald-300 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      {showSignupPassword ? (
                        <>
                          <EyeOff className="w-3.5 h-3.5" />
                          <span>Hide</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-3.5 h-3.5" />
                          <span>Show</span>
                        </>
                      )}
                    </button>
                  </label>
                  <input
                    type={showSignupPassword ? "text" : "password"}
                    name="password"
                    autoComplete="new-password"
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                    placeholder="Create a secure password"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-[#08120D] border border-emerald-900/80 text-white placeholder:text-slate-500 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-200 mb-1.5 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Confirm Password</span>
                  </label>
                  <input
                    type={showSignupPassword ? "text" : "password"}
                    name="confirmPassword"
                    autoComplete="new-password"
                    value={signupConfirmPassword}
                    onChange={(e) => setSignupConfirmPassword(e.target.value)}
                    placeholder="Re-enter your password"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-[#08120D] border border-emerald-900/80 text-white placeholder:text-slate-500 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
                  />
                </div>

                {/* Create Account Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 disabled:opacity-60 text-white font-bold text-sm shadow-lg shadow-emerald-950/60 transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
                >
                  <span>{isSubmitting ? "Creating account..." : "Create Account & Sign In"}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setMode("signin");
                      setError(null);
                    }}
                    className="text-xs text-slate-400 hover:text-emerald-300 transition-colors cursor-pointer"
                  >
                    Already registered? <span className="font-bold text-emerald-400 underline">Sign In</span>
                  </button>
                </div>
              </form>
            )}

            {/* Privacy & Local Security Notice */}
            <div className="pt-4 border-t border-emerald-900/50 flex items-center justify-center gap-2 text-center text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Isolated local patient privacy • Credentials encrypted on this device</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
