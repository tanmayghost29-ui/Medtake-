import React, { useRef } from "react";
import { PRESET_AVATARS } from "../constants/avatars";
import { Upload, X, Check, Camera, Image } from "lucide-react";
import { PatientAvatar } from "./PatientAvatar";

interface AvatarPickerProps {
  patientName: string;
  selectedAvatar: string | null;
  onSelectAvatar: (avatarUrl: string | null) => void;
}

export const AvatarPicker: React.FC<AvatarPickerProps> = ({
  patientName,
  selectedAvatar,
  onSelectAvatar,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Convert uploaded image to base64 data URL
    const reader = new FileReader();
    reader.onload = () => {
      onSelectAvatar(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
          Patient Profile Photo / Avatar
        </label>
        {selectedAvatar && (
          <button
            type="button"
            onClick={() => onSelectAvatar(null)}
            className="text-xs text-slate-400 hover:text-red-600 flex items-center gap-1 cursor-pointer"
          >
            <X className="w-3 h-3" />
            <span>Reset to Initials</span>
          </button>
        )}
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200">
        {/* Current Avatar Live Preview */}
        <div className="flex items-center gap-3 shrink-0">
          <PatientAvatar
            name={patientName || "Patient"}
            avatarUrl={selectedAvatar}
            size="lg"
            showBorder={true}
          />
          <div>
            <span className="text-xs font-bold text-slate-800 block">
              {selectedAvatar ? "Selected Photo" : "Default Initials"}
            </span>
            <span className="text-[11px] text-slate-400">
              Displayed in Home & Alarms
            </span>
          </div>
        </div>

        {/* Divider */}
        <div className="hidden sm:block h-10 w-px bg-slate-200" />

        {/* Presets and Upload button */}
        <div className="flex-1 w-full space-y-2">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {/* Upload Custom Photo Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-slate-300 hover:border-emerald-500 bg-white text-xs font-bold text-slate-700 hover:text-emerald-700 hover:bg-emerald-50/30 shrink-0 transition-colors cursor-pointer"
              title="Upload your own photo from device"
            >
              <Upload className="w-3.5 h-3.5 text-slate-500" />
              <span>Upload Custom</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />

            {/* Presets Avatars carousel */}
            {PRESET_AVATARS.map((avatar) => {
              const isSelected = selectedAvatar === avatar.url;
              return (
                <button
                  key={avatar.id}
                  type="button"
                  onClick={() => onSelectAvatar(avatar.url)}
                  className={`relative p-0.5 rounded-2xl shrink-0 transition-all cursor-pointer ${
                    isSelected
                      ? "ring-2 ring-emerald-600 scale-105"
                      : "opacity-80 hover:opacity-100 hover:scale-102"
                  }`}
                  title={avatar.name}
                >
                  <img
                    src={avatar.url}
                    alt={avatar.name}
                    className="w-9 h-9 rounded-xl object-cover shadow-2xs border border-white"
                    referrerPolicy="no-referrer"
                  />
                  {isSelected && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
          <p className="text-[10px] text-slate-400">
            Choose from quick family avatars or upload a picture from your camera/files.
          </p>
        </div>
      </div>
    </div>
  );
};
