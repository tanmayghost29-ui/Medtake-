import React, { useState, useEffect } from "react";
import { Sparkles, Sun, Moon, Compass, Watch, Cpu } from "lucide-react";

interface CinematicClockProps {
  deviceTime: Date;
  isDay: boolean;
  onOpenEditTime?: () => void;
  styleMode?: "chronometer" | "digital_hud" | "minimal";
  onChangeStyle?: (mode: "chronometer" | "digital_hud" | "minimal") => void;
  showStylePicker?: boolean;
}

export const CinematicClock: React.FC<CinematicClockProps> = ({
  deviceTime,
  isDay,
  onOpenEditTime,
  styleMode = "chronometer",
  onChangeStyle,
  showStylePicker = false,
}) => {
  const [internalMode, setInternalMode] = useState<"chronometer" | "digital_hud" | "minimal">(styleMode);
  const activeMode = onChangeStyle ? styleMode : internalMode;

  const hours = deviceTime.getHours();
  const minutes = deviceTime.getMinutes();
  const seconds = deviceTime.getSeconds();
  const milliseconds = deviceTime.getMilliseconds();

  // Smooth continuous second hand movement (sub-second precision for high-end mechanical chronometer look)
  const continuousSeconds = seconds + milliseconds / 1000;
  const secondDeg = continuousSeconds * 6;
  const minuteDeg = minutes * 6 + continuousSeconds * 0.1;
  const hourDeg = (hours % 12) * 30 + minutes * 0.5;

  const currentMode = activeMode;
  const setMode = onChangeStyle || setInternalMode;

  return (
    <div className="flex flex-col items-center justify-center select-none py-2">
      {/* Clock Style Pill Switcher (accessible in Settings) */}
      {showStylePicker && (
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-black/30 backdrop-blur-md border border-white/15 mb-4 shadow-inner">
        <button
          type="button"
          onClick={() => setMode("chronometer")}
          className={`flex items-center gap-1 px-3 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
            currentMode === "chronometer"
              ? "bg-emerald-500 text-white shadow-xs"
              : "text-white/70 hover:text-white hover:bg-white/10"
          }`}
        >
          <Watch className="w-3 h-3" />
          <span>Alpine Dial</span>
        </button>
        <button
          type="button"
          onClick={() => setMode("digital_hud")}
          className={`flex items-center gap-1 px-3 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
            currentMode === "digital_hud"
              ? "bg-amber-500 text-slate-950 shadow-xs"
              : "text-white/70 hover:text-white hover:bg-white/10"
          }`}
        >
          <Cpu className="w-3 h-3" />
          <span>Cinema HUD</span>
        </button>
        <button
          type="button"
          onClick={() => setMode("minimal")}
          className={`flex items-center gap-1 px-3 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
            currentMode === "minimal"
              ? "bg-sky-500 text-white shadow-xs"
              : "text-white/70 hover:text-white hover:bg-white/10"
          }`}
        >
          <Compass className="w-3 h-3" />
          <span>Minimal</span>
        </button>
      </div>
      )}

      {/* CLOCK STYLE 1: Alpine Swiss Luxury Chronometer */}
      {currentMode === "chronometer" && (
        <div className="relative group">
          {/* Ambient Breathing Halo Ring */}
          <div
            className={`absolute -inset-4 rounded-full blur-xl opacity-60 animate-pulse transition-colors duration-1000 ${
              isDay ? "bg-emerald-400/30" : "bg-sky-500/25"
            }`}
          />

          {/* Outer Titanium Bezel */}
          <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full p-2 bg-gradient-to-tr from-slate-800 via-slate-600 to-slate-900 shadow-2xl border-2 border-white/20 flex items-center justify-center">
            {/* Inner Dial Face */}
            <div
              className={`w-full h-full rounded-full relative overflow-hidden flex items-center justify-center border transition-all duration-700 shadow-inner ${
                isDay
                  ? "bg-gradient-to-b from-[#0b3323] via-[#062417] to-[#02140c] border-emerald-400/40 text-emerald-100"
                  : "bg-gradient-to-b from-[#09111e] via-[#060b14] to-[#020509] border-sky-400/40 text-sky-100"
              }`}
            >
              {/* Subtle Concentric Guilloché Rings */}
              <div className="absolute inset-4 rounded-full border border-white/10 pointer-events-none" />
              <div className="absolute inset-8 rounded-full border border-white/5 pointer-events-none" />
              <div className="absolute inset-12 rounded-full border border-dashed border-emerald-500/15 pointer-events-none" />

              {/* 60 Minute & Second Ticks */}
              {[...Array(60)].map((_, i) => {
                const isMajor = i % 5 === 0;
                const isQuarter = i % 15 === 0;
                return (
                  <div
                    key={i}
                    className="absolute inset-0 pointer-events-none flex justify-center items-start pt-1.5"
                    style={{ transform: `rotate(${i * 6}deg)` }}
                  >
                    <div
                      className={`rounded-full ${
                        isQuarter
                          ? "w-1.5 h-3.5 bg-amber-400 shadow-[0_0_6px_#fbbf24]"
                          : isMajor
                          ? "w-1 h-2.5 bg-emerald-400 shadow-[0_0_4px_#34d399]"
                          : "w-0.5 h-1 bg-white/25"
                      }`}
                    />
                  </div>
                );
              })}

              {/* 12, 3, 6, 9 Numerals */}
              <div className="absolute top-5 text-[11px] font-black tracking-widest text-amber-300 font-mono">
                12
              </div>
              <div className="absolute right-5 text-[11px] font-black tracking-widest text-emerald-300 font-mono">
                3
              </div>
              <div className="absolute bottom-5 text-[11px] font-black tracking-widest text-emerald-300 font-mono">
                6
              </div>
              <div className="absolute left-5 text-[11px] font-black tracking-widest text-emerald-300 font-mono">
                9
              </div>

              {/* Brand & Alpine Elevation Sub-mark */}
              <div className="absolute top-12 flex flex-col items-center pointer-events-none">
                <span className="text-[9px] font-black tracking-widest text-white/90 uppercase">
                  MEDTAKE
                </span>
                <span className="text-[7px] font-bold text-emerald-400/90 tracking-wider">
                  ALPINE 3,200M
                </span>
              </div>

              {/* Date & Celestial Indicator Subdial */}
              <div className="absolute bottom-11 flex items-center gap-1 px-2 py-0.5 rounded-md bg-black/40 border border-white/10 text-[9px] font-mono text-amber-300 pointer-events-none">
                {isDay ? (
                  <Sun className="w-2.5 h-2.5 text-amber-400 animate-spin" style={{ animationDuration: "20s" }} />
                ) : (
                  <Moon className="w-2.5 h-2.5 text-sky-400" />
                )}
                <span>
                  {deviceTime.toLocaleDateString([], { month: "short", day: "2-digit" }).toUpperCase()}
                </span>
              </div>

              {/* Hour Hand (Luminous sword style) */}
              <div
                className="absolute bottom-1/2 left-1/2 -ml-[3px] w-[6px] h-14 sm:h-16 rounded-full origin-bottom pointer-events-none z-1 drop-shadow-md"
                style={{
                  transform: `rotate(${hourDeg}deg)`,
                  background: "linear-gradient(to top, #ffffff, #d1fae5)",
                }}
              >
                <div className="w-[2px] h-8 mx-auto mt-1 bg-emerald-700/60 rounded-full" />
              </div>

              {/* Minute Hand (Slender luminous blade) */}
              <div
                className="absolute bottom-1/2 left-1/2 -ml-[2px] w-[4px] h-18 sm:h-22 rounded-full origin-bottom pointer-events-none z-2 drop-shadow-md"
                style={{
                  transform: `rotate(${minuteDeg}deg)`,
                  background: "linear-gradient(to top, #fef08a, #ca8a04)",
                }}
              >
                <div className="w-[1.5px] h-12 mx-auto mt-1 bg-amber-950/70 rounded-full" />
              </div>

              {/* Sweeping Second Hand (Smooth continuous rotation with red counterbalance) */}
              <div
                className="absolute bottom-1/2 left-1/2 -ml-[1px] w-[2px] h-22 sm:h-26 origin-bottom pointer-events-none z-3 drop-shadow-[0_0_4px_rgba(239,68,68,0.7)]"
                style={{
                  transform: `rotate(${secondDeg}deg)`,
                  background: "#ef4444",
                }}
              >
                {/* Counterweight tail below center */}
                <div className="w-[3px] h-5 -ml-[0.5px] -mt-5 bg-red-600 rounded-full" />
              </div>

              {/* Center Ruby Jewel Pin */}
              <div className="w-4 h-4 rounded-full bg-gradient-to-tr from-red-600 via-amber-400 to-amber-200 border border-white shadow-md relative z-4" />
            </div>
          </div>
        </div>
      )}

      {/* CLOCK STYLE 2: Cinematic Digital Film HUD */}
      {currentMode === "digital_hud" && (
        <div className="relative p-6 sm:p-7 rounded-3xl bg-slate-950/85 backdrop-blur-xl border border-amber-400/30 text-amber-400 shadow-2xl flex flex-col items-center">
          {/* Circular Seconds Progress Ring */}
          <div className="relative w-44 h-44 sm:w-52 sm:h-52 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="44"
                stroke="rgba(255,255,255,0.08)"
                strokeWidth="4"
                fill="none"
              />
              <circle
                cx="50"
                cy="50"
                r="44"
                stroke="#fbbf24"
                strokeWidth="4"
                strokeDasharray="276.46"
                strokeDashoffset={276.46 - (276.46 * continuousSeconds) / 60}
                strokeLinecap="round"
                fill="none"
                className="transition-all duration-100"
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] font-extrabold tracking-widest text-amber-300/80 uppercase font-mono">
                CINEMATIC HUD
              </span>
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-white drop-shadow-[0_0_12px_rgba(251,191,36,0.5)]">
                {String(hours).padStart(2, "0")}:{String(minutes).padStart(2, "0")}
              </div>
              <div className="flex items-center gap-1.5 mt-1 font-mono text-xs font-bold text-amber-400">
                <span>SEC</span>
                <span className="text-base font-black px-1.5 py-0.5 rounded-md bg-amber-400/20 border border-amber-400/30">
                  {String(seconds).padStart(2, "0")}
                </span>
              </div>
              <span className="text-[10px] font-semibold text-emerald-400 mt-1">
                IST (UTC+5:30)
              </span>
            </div>
          </div>
        </div>
      )}

      {/* CLOCK STYLE 3: Minimal Mountain Watch */}
      {currentMode === "minimal" && (
        <div className="relative p-6 rounded-3xl bg-white/10 backdrop-blur-md border border-white/20 text-white shadow-xl flex flex-col items-center">
          <div className="text-4xl sm:text-5xl font-black tracking-tight font-mono text-white drop-shadow-md">
            {String(hours).padStart(2, "0")}:{String(minutes).padStart(2, "0")}
            <span className="text-xl sm:text-2xl text-emerald-400 ml-1">
              :{String(seconds).padStart(2, "0")}
            </span>
          </div>
          <div className="flex items-center gap-2 mt-2 text-xs font-semibold text-white/80">
            <span>{isDay ? "☀️ Daytime" : "🌙 Nighttime"}</span>
            <span>•</span>
            <span>Local Device Sync</span>
          </div>
        </div>
      )}
    </div>
  );
};
