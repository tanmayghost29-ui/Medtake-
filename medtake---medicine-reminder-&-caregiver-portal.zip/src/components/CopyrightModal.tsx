import React from "react";
import { ShieldCheck, Award, CheckCircle2, X, Download, Lock, FileText, Sparkles, Heart } from "lucide-react";

interface CopyrightModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CopyrightModal: React.FC<CopyrightModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl border border-slate-200 max-w-xl w-full p-6 sm:p-8 shadow-2xl relative my-auto space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Certificate Header Banner */}
        <div className="text-center space-y-2 border-b border-slate-100 pb-5">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 shadow-xs mb-1">
            <Award className="w-8 h-8 text-emerald-600" />
          </div>
          <span className="inline-block px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-extrabold uppercase tracking-widest">
            Official Ownership Record
          </span>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            Certificate of Copyright & Ownership
          </h2>
          <p className="text-xs text-slate-500">
            Authenticated software registration and intellectual property attribution.
          </p>
        </div>

        {/* Certificate Body (Guilloche / Parchment style border) */}
        <div className="p-5 rounded-2xl bg-gradient-to-b from-emerald-50/50 to-slate-50 border-2 border-emerald-200/80 space-y-4">
          <div className="text-center space-y-1">
            <p className="text-[11px] uppercase tracking-wider text-slate-500 font-bold">
              This certifies that the proprietary application
            </p>
            <h3 className="text-2xl font-black text-emerald-800 tracking-tight">
              medtake™
            </h3>
            <p className="text-xs text-slate-600 font-medium">
              Smart Multilingual Medicine Alarm Clock & Automated Dual Guardian Dispatch System
            </p>
          </div>

          <div className="my-3 border-t border-dashed border-emerald-300" />

          {/* Owner Box */}
          <div className="p-4 rounded-xl bg-white border border-emerald-200 shadow-xs space-y-2 text-center">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              Sole Creator & Intellectual Property Owner
            </span>
            <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center justify-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>Tammy TM</span>
              <span className="text-sm font-semibold text-slate-500">(Tanmay TM)</span>
            </div>
            <div className="text-xs text-emerald-700 font-mono font-bold">
              Owner Verified • tanmayghost29@gmail.com
            </div>
          </div>

          {/* Legal Claims & Details */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-lg bg-white border border-slate-200">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">
                Certificate Registration ID
              </span>
              <span className="font-mono font-bold text-slate-800">
                MEDTAKE-REG-2026-TTM-7259
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-slate-200">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">
                Jurisdiction & Copyright
              </span>
              <span className="font-bold text-slate-800">
                © 2026 Tammy TM. All Rights Reserved.
              </span>
            </div>
          </div>

          {/* Proprietary Protected Innovations */}
          <div className="space-y-1.5 pt-1 text-xs text-slate-700">
            <span className="text-[11px] font-bold text-slate-900 block">
              Registered Innovations & Software Rights:
            </span>
            <div className="space-y-1 text-[11px] text-slate-600">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Dual Automated Guardian Alerting (Simultaneous SMS + WhatsApp without prompt)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>22 Indian Language Synthesized Voice Reminders with High Audio Clarity</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Hardware-Synced Local Clock Bedside Mode with Screen Wake-Lock</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Offline WebAPK / PWA Service Worker Medicine Storage</span>
              </div>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-500 text-[11px] leading-relaxed">
          <Lock className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
          <span>
            Unauthorized duplication, re-branding, or distribution of this codebase without the explicit written authorization of <strong>Tammy TM</strong> is strictly prohibited under international copyright conventions and digital intellectual property treaties.
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-3 pt-1">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Print / Save Certificate</span>
          </button>

          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
