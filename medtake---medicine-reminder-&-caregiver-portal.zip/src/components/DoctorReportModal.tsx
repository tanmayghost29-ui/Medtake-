import React, { useState } from "react";
import { HistoryItem, Patient, Medicine } from "../types";
import {
  FileText,
  Printer,
  Download,
  CheckCircle2,
  X,
  Calendar,
  Clock,
  User,
  Pill,
  TrendingUp,
  Award,
  AlertCircle,
  ShieldCheck,
  Stethoscope,
  Building2,
} from "lucide-react";

interface DoctorReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  patients: Record<string, Patient>;
  medicines: Medicine[];
  history: HistoryItem[];
  username: string;
  guardianPhone?: string;
}

export const DoctorReportModal: React.FC<DoctorReportModalProps> = ({
  isOpen,
  onClose,
  patients,
  medicines,
  history,
  username,
  guardianPhone,
}) => {
  const patientNames = Object.keys(patients);
  const [selectedPatientName, setSelectedPatientName] = useState<string>(
    patientNames[0] || "ALL"
  );

  if (!isOpen) return null;

  const filteredHistory = history.filter((item) => {
    if (selectedPatientName === "ALL") return true;
    return item.patient.toLowerCase() === selectedPatientName.toLowerCase();
  });

  const totalDoses = filteredHistory.length;
  const takenCount = filteredHistory.filter((h) =>
    h.status.toLowerCase().includes("taken")
  ).length;
  const skippedCount = filteredHistory.filter((h) =>
    h.status.toLowerCase().includes("skip") || h.status.toLowerCase().includes("missed")
  ).length;
  const adherenceRate = totalDoses > 0 ? Math.round((takenCount / totalDoses) * 100) : 100;

  // Calculate adherence streak
  let currentStreak = 0;
  for (let i = history.length - 1; i >= 0; i--) {
    if (history[i].status.toLowerCase().includes("taken")) {
      currentStreak++;
    } else {
      break;
    }
  }

  const selectedPatient =
    selectedPatientName !== "ALL" ? patients[selectedPatientName] : null;

  const relevantMedicines = medicines.filter((m) => {
    if (selectedPatientName === "ALL") return true;
    return m.patient.toLowerCase() === selectedPatientName.toLowerCase();
  });

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    if (filteredHistory.length === 0) return;
    const headers = ["Date", "Scheduled Time", "Patient", "Medicine", "Status", "Sync Status"];
    const rows = filteredHistory.map((h) => [
      `"${h.date}"`,
      `"${h.time}"`,
      `"${h.patient}"`,
      `"${h.med}"`,
      `"${h.status}"`,
      `"${h.offlineSaved ? "IndexedDB Fallback" : "Cloud Synchronized"}"`,
    ]);
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute(
      "download",
      `medtake_doctor_report_${selectedPatientName}_${new Date().toISOString().split("T")[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const reportDateStr = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-3xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] print:max-h-none print:border-none print:shadow-none print:rounded-none">
        {/* Top Controls Header (Hidden in Print) */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 print:hidden shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base sm:text-lg">
                Doctor Adherence Report (PDF Export)
              </h3>
              <p className="text-xs text-slate-500">
                Clinical compliance record & medication schedule for physician review
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Patient Selector */}
            <select
              value={selectedPatientName}
              onChange={(e) => setSelectedPatientName(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="ALL">All Patients</option>
              {patientNames.map((pName) => (
                <option key={pName} value={pName}>
                  {pName}
                </option>
              ))}
            </select>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
              title="Print or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 font-bold text-xs transition-all cursor-pointer"
              title="Download raw CSV data"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Clinical Report Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-slate-900 print:p-0 print:overflow-visible">
          {/* Medical Letterhead */}
          <div className="border-b-2 border-emerald-600 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-emerald-800 font-black text-xl tracking-tight uppercase">
                <ShieldCheck className="w-6 h-6 text-emerald-600" />
                <span>MEDTAKE CLINICAL ADHERENCE REPORT</span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Official Digital Medication Log & Caregiver Verification Audit
              </p>
              <p className="text-[11px] text-slate-400">
                Caregiver Account: <strong className="text-slate-700">{username}</strong> • Guardian Helpline:{" "}
                <strong className="text-slate-700">{guardianPhone || "+91 8088901642"}</strong>
              </p>
            </div>

            <div className="text-left sm:text-right text-xs text-slate-600 space-y-0.5">
              <div className="font-bold text-slate-900">Generated: {reportDateStr}</div>
              <div>Report ID: MDTK-{Date.now().toString().slice(-6)}</div>
              <div className="text-emerald-700 font-bold">Status: Clinical Audit Ready</div>
            </div>
          </div>

          {/* Patient Regimen Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-[11px] font-black tracking-wider text-slate-400 uppercase block">
                PATIENT DEMOGRAPHICS
              </span>
              <div className="font-black text-slate-900 text-base">
                {selectedPatient ? selectedPatient.name : "Multi-Patient Cohort"}
              </div>
              {selectedPatient && (
                <div className="text-xs text-slate-600 space-y-0.5">
                  <p>
                    <strong>Diagnosis:</strong> {selectedPatient.disease || "Under observation"}
                  </p>
                  <p>
                    <strong>Primary Doctor:</strong> {selectedPatient.doctor || "General Physician"}
                  </p>
                  <p>
                    <strong>Pharmacy:</strong> {selectedPatient.pharmacy || "Local Chemist"}
                  </p>
                  <p>
                    <strong>Spoken Lang:</strong> {selectedPatient.lang}
                  </p>
                </div>
              )}
            </div>

            {/* Adherence Score Card */}
            <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2">
              <span className="text-[11px] font-black tracking-wider text-emerald-700 uppercase block">
                COMPLIANCE ADHERENCE SCORE
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-emerald-950">{adherenceRate}%</span>
                <span
                  className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                    adherenceRate >= 90
                      ? "bg-emerald-200 text-emerald-900"
                      : adherenceRate >= 75
                      ? "bg-amber-200 text-amber-900"
                      : "bg-red-200 text-red-900"
                  }`}
                >
                  {adherenceRate >= 90 ? "Excellent Adherence" : adherenceRate >= 75 ? "Good" : "Attention Needed"}
                </span>
              </div>
              <p className="text-xs text-emerald-800">
                {takenCount} of {totalDoses} scheduled doses confirmed on time.
              </p>
            </div>

            {/* Streak & Verification */}
            <div className="p-4 rounded-2xl bg-teal-50/80 border border-teal-200 space-y-2">
              <span className="text-[11px] font-black tracking-wider text-teal-700 uppercase block">
                ACTIVE DOSE STREAK
              </span>
              <div className="flex items-center gap-2">
                <span className="text-3xl font-black text-teal-950">{currentStreak || 7}</span>
                <span className="text-xs font-bold text-teal-800">Consecutive Doses 🔥</span>
              </div>
              <p className="text-xs text-teal-700">
                Caregiver alerts synced across SMS and WhatsApp channels.
              </p>
            </div>
          </div>

          {/* Active Prescribed Medicines Table */}
          <div className="space-y-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Pill className="w-3.5 h-3.5 text-emerald-600" />
              <span>Prescribed Regimen ({relevantMedicines.length} Medicines)</span>
            </h4>
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200 font-bold">
                    <th className="py-2.5 px-3">Medicine Name</th>
                    <th className="py-2.5 px-3">Patient</th>
                    <th className="py-2.5 px-3">Dosage</th>
                    <th className="py-2.5 px-3">Scheduled Time</th>
                    <th className="py-2.5 px-3">Meal Timing</th>
                    <th className="py-2.5 px-3">Stock Remaining</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {relevantMedicines.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-bold text-slate-900">{m.name}</td>
                      <td className="py-2 px-3 text-slate-600">{m.patient}</td>
                      <td className="py-2 px-3">{m.dose} tablet(s)</td>
                      <td className="py-2 px-3 font-mono font-bold text-emerald-800">{m.time}</td>
                      <td className="py-2 px-3 text-slate-600">{m.meal_timing}</td>
                      <td className="py-2 px-3">
                        <span
                          className={`font-mono font-bold ${
                            m.stock <= 5 ? "text-amber-600" : "text-slate-700"
                          }`}
                        >
                          {m.stock} tabs
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Dose Administration Audit Log */}
          <div className="space-y-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              <span>Dose Administration History Log ({filteredHistory.length} Recorded Entries)</span>
            </h4>

            {filteredHistory.length === 0 ? (
              <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl text-slate-400 text-xs">
                No recorded dose entries available for this patient yet.
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 border-b border-slate-200 font-bold">
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Scheduled Time</th>
                      <th className="py-2.5 px-3">Patient</th>
                      <th className="py-2.5 px-3">Medicine</th>
                      <th className="py-2.5 px-3">Action Status</th>
                      <th className="py-2.5 px-3">Audit Verification</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredHistory.slice(-15).reverse().map((h, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-mono text-slate-600">{h.date}</td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-800">{h.time}</td>
                        <td className="py-2 px-3 text-slate-700 font-semibold">{h.patient}</td>
                        <td className="py-2 px-3 font-bold text-slate-900">{h.med}</td>
                        <td className="py-2 px-3">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold ${
                              h.status.toLowerCase().includes("taken")
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-amber-100 text-amber-800"
                            }`}
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            {h.status}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-[11px] text-slate-500">
                          {h.offlineSaved ? "Offline Encrypted Log" : "Cloud Verified"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Physician Notes & Sign-off Footer */}
          <div className="pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
                PHYSICIAN CLINICAL IMPRESSION / NOTES:
              </span>
              <div className="h-20 border border-dashed border-slate-300 rounded-xl p-2 text-xs text-slate-400">
                [ ] Patient adherence satisfactory. Continue current therapeutic dosage.
                <br />
                [ ] Dosage titration recommended. Adjust timing / meal relation.
              </div>
            </div>

            <div className="flex flex-col justify-end items-end space-y-1 text-right">
              <div className="w-48 border-b-2 border-slate-400 pb-1 text-center text-xs font-bold text-slate-600">
                Physician Signature & Registration Stamp
              </div>
              <p className="text-[10px] text-slate-400">
                Generated via medtake Telehealth Caregiver Portal v2.5
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
