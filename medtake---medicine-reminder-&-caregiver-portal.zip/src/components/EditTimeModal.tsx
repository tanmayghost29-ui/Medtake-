import React, { useState, useEffect } from "react";
import { X, Clock, Check, Sparkles, Bell, ArrowRight, Calendar } from "lucide-react";
import { Medicine } from "../types";

interface EditTimeModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicine: Medicine | null;
  onUpdateTime: (medId: string, newTime: string) => void;
}

export const EditTimeModal: React.FC<EditTimeModalProps> = ({
  isOpen,
  onClose,
  medicine,
  onUpdateTime,
}) => {
  const [selectedTime, setSelectedTime] = useState("08:00");
  const [justSaved, setJustSaved] = useState(false);

  useEffect(() => {
    if (medicine?.time) {
      setSelectedTime(medicine.time);
    }
  }, [medicine]);

  if (!isOpen || !medicine) return null;

  // Calculate quick offset time relative to current device clock
  const setRelativeMinutes = (mins: number) => {
    const d = new Date();
    d.setMinutes(d.getMinutes() + mins);
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    setSelectedTime(`${hh}:${mm}`);
  };

  const setSpecificTime = (timeStr: string) => {
    setSelectedTime(timeStr);
  };

  const handleSave = () => {
    if (!selectedTime) return;
    onUpdateTime(medicine.id, selectedTime);
    setJustSaved(true);
    setTimeout(() => {
      setJustSaved(false);
      onClose();
    }, 600);
  };

  // Calculate preview diff from right now
  const getPreviewText = () => {
    if (!selectedTime) return "";
    const [h, m] = selectedTime.split(":").map(Number);
    const now = new Date();
    const target = new Date();
    target.setHours(h, m, 0, 0);
    if (target.getTime() <= now.getTime()) {
      target.setDate(target.getDate() + 1);
    }
    const diffMin = Math.round((target.getTime() - now.getTime()) / (60 * 1000));
    const hoursPart = Math.floor(diffMin / 60);
    const minsPart = diffMin % 60;
    if (hoursPart > 0) {
      return `triggers in ${hoursPart}h ${minsPart}m`;
    }
    return `triggers in ${minsPart} minute${minsPart === 1 ? "" : "s"}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden relative flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/10 backdrop-blur-sm">
              <Clock className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-base tracking-tight">
                Edit Scheduled Time
              </h3>
              <p className="text-xs text-emerald-100 font-medium">
                {medicine.name} • {medicine.patient}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-5">
          {/* Main Time Input Display */}
          <div className="text-center space-y-2 bg-emerald-50/70 p-5 rounded-2xl border border-emerald-200/80">
            <label className="text-xs font-extrabold text-emerald-900 uppercase tracking-wider block">
              Set Alarm Clock Time (24h)
            </label>
            <div className="inline-flex items-center justify-center bg-white px-5 py-2.5 rounded-2xl border-2 border-emerald-500 shadow-sm">
              <input
                type="time"
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
                className="text-3xl font-black font-mono text-slate-900 bg-transparent focus:outline-none cursor-pointer tracking-wider"
              />
            </div>
            <div className="text-xs font-semibold text-emerald-700 flex items-center justify-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-emerald-600" />
              <span>Alarm {getPreviewText()}</span>
            </div>
          </div>

          {/* Quick Offset Chips */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">
              Quick Timers:
            </label>
            <div className="grid grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setRelativeMinutes(1)}
                className="py-2 px-1 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 font-extrabold text-xs transition-colors cursor-pointer shadow-2xs"
                title="Trigger alarm 1 minute from now to test"
              >
                +1m (Test)
              </button>
              <button
                type="button"
                onClick={() => setRelativeMinutes(5)}
                className="py-2 px-1 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
              >
                +5m
              </button>
              <button
                type="button"
                onClick={() => setRelativeMinutes(15)}
                className="py-2 px-1 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
              >
                +15m
              </button>
              <button
                type="button"
                onClick={() => setRelativeMinutes(30)}
                className="py-2 px-1 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
              >
                +30m
              </button>
            </div>
          </div>

          {/* Standard Daily Timers */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">
              Standard Daily Schedules:
            </label>
            <div className="grid grid-cols-4 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setSpecificTime("08:00")}
                className={`py-2 px-2 rounded-xl border font-bold transition-all cursor-pointer ${
                  selectedTime === "08:00"
                    ? "bg-emerald-600 text-white border-emerald-600 shadow-xs"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                08:00 (Morn)
              </button>
              <button
                type="button"
                onClick={() => setSpecificTime("13:00")}
                className={`py-2 px-2 rounded-xl border font-bold transition-all cursor-pointer ${
                  selectedTime === "13:00"
                    ? "bg-emerald-600 text-white border-emerald-600 shadow-xs"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                13:00 (Noon)
              </button>
              <button
                type="button"
                onClick={() => setSpecificTime("20:00")}
                className={`py-2 px-2 rounded-xl border font-bold transition-all cursor-pointer ${
                  selectedTime === "20:00"
                    ? "bg-emerald-600 text-white border-emerald-600 shadow-xs"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                20:00 (Eve)
              </button>
              <button
                type="button"
                onClick={() => setSpecificTime("22:00")}
                className={`py-2 px-2 rounded-xl border font-bold transition-all cursor-pointer ${
                  selectedTime === "22:00"
                    ? "bg-emerald-600 text-white border-emerald-600 shadow-xs"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                22:00 (Night)
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold text-xs transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {justSaved ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Implemented!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Implement Time</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
