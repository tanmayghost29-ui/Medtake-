import React, { useState } from "react";
import { Download, Smartphone, X, Sparkles } from "lucide-react";
import { usePWAInstall } from "../utils/usePWAInstall";

interface FloatingInstallButtonProps {
  onOpenManualModal?: () => void;
}

export const FloatingInstallButton: React.FC<FloatingInstallButtonProps> = ({
  onOpenManualModal,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [isDismissed, setIsDismissed] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  // If already installed or dismissed, hide the install prompts
  if (isInstalled || isDismissed) {
    return null;
  }

  const handleInstallClick = async () => {
    setIsInstalling(true);
    try {
      if (isInstallable) {
        const success = await install();
        if (success) {
          setIsDismissed(true);
        }
      } else if (onOpenManualModal) {
        onOpenManualModal();
      }
    } finally {
      setIsInstalling(false);
    }
  };

  return (
    <>
      {/* Top Visible Install Banner across the top of screen */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-blue-700 via-indigo-600 to-emerald-600 text-white shadow-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 flex items-center justify-between gap-2 text-xs sm:text-sm font-semibold">
          <div className="flex items-center gap-2 truncate">
            <span className="p-1 rounded-md bg-white/20 shrink-0">
              <Smartphone className="w-4 h-4 text-white animate-pulse" />
            </span>
            <span className="truncate">
              Install <strong className="font-bold">MedTake App</strong> for instant voice alarms & offline guardian watchdog!
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleInstallClick}
              disabled={isInstalling}
              className="px-3 py-1 sm:px-4 sm:py-1.5 rounded-lg bg-white text-blue-700 hover:bg-blue-50 font-extrabold shadow-sm active:scale-95 transition-transform flex items-center gap-1.5 cursor-pointer text-xs sm:text-sm"
              title="Install MedTake App directly"
            >
              <Download className="w-3.5 h-3.5 text-blue-700" />
              <span>Install MedTake App</span>
              <Sparkles className="w-3 h-3 text-amber-500 hidden sm:inline" />
            </button>

            <button
              onClick={() => setIsDismissed(true)}
              className="p-1 rounded-md hover:bg-white/20 text-white/80 hover:text-white transition-colors cursor-pointer"
              title="Dismiss top banner"
              aria-label="Dismiss banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Floating Bottom Quick Action */}
      <div className="fixed bottom-5 right-4 sm:right-6 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300">
        <div className="flex items-center gap-1.5 p-1.5 pl-3 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 text-white shadow-2xl border border-white/20 backdrop-blur-md">
          <button
            onClick={handleInstallClick}
            disabled={isInstalling}
            className="flex items-center gap-2.5 text-xs sm:text-sm font-bold pr-2 cursor-pointer active:scale-95 transition-transform"
            title="Install MedTake Native App"
          >
            <div className="w-8 h-8 rounded-full bg-white text-blue-600 flex items-center justify-center shadow-xs">
              <Smartphone className="w-4 h-4 animate-pulse" />
            </div>
            <span className="flex items-center gap-1">
              <span>📲 Install MedTake App</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            </span>
          </button>

          <button
            onClick={() => setIsDismissed(true)}
            className="w-7 h-7 rounded-full bg-black/20 hover:bg-black/40 text-white/80 hover:text-white flex items-center justify-center text-xs transition-colors cursor-pointer"
            title="Dismiss"
            aria-label="Dismiss install button"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </>
  );
};
