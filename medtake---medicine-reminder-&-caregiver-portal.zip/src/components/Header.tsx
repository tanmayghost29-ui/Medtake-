import {
  LogOut,
  Sun,
  Moon,
  Sparkles,
  Clock,
  Smartphone,
  Award,
  Eye,
  EyeOff,
  Wifi,
  WifiOff,
  Database,
  MoreVertical,
  Settings,
  Bell,
} from "lucide-react";
import { useOfflineSync } from "../utils/offlineSync";

interface HeaderProps {
  username: string;
  themeMode: "auto" | "day" | "night";
  onToggleTheme: () => void;
  onLogout: () => void;
  isAlarmActive: boolean;
  onOpenApkModal?: () => void;
  onOpenCopyrightModal?: () => void;
  onOpenAppDetailsModal?: () => void;
  onOpenSettingsModal?: () => void;
  onNotificationClick?: () => void;
  wakeLockActive?: boolean;
  onToggleWakeLock?: () => void;
  onNavigateToLanding?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  username,
  themeMode,
  onToggleTheme,
  onLogout,
  onOpenApkModal,
  onOpenCopyrightModal,
  onOpenAppDetailsModal,
  onOpenSettingsModal,
  onNotificationClick,
  wakeLockActive = false,
  onToggleWakeLock,
  onNavigateToLanding,
}) => {
  const { isOnline, pendingCount } = useOfflineSync();

  return (
    <div className="bg-white border-b border-emerald-100/70 w-full">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <div className="relative flex items-center justify-center shrink-0">
            <svg
              width="42"
              height="42"
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="drop-shadow-xs shrink-0"
            >
              <rect width="100" height="100" rx="24" fill="#059669" />
              <rect x="42" y="14" width="16" height="6" rx="3" fill="#FFFFFF" />
              <circle
                cx="50"
                cy="54"
                r="30"
                stroke="#FFFFFF"
                strokeWidth="7"
                fill="none"
              />
              <line
                x1="50"
                y1="54"
                x2="50"
                y2="34"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinecap="round"
              />
              <line
                x1="50"
                y1="54"
                x2="66"
                y2="54"
                stroke="#FBBF24"
                strokeWidth="6"
                strokeLinecap="round"
              />
              <g transform="translate(62,60) rotate(35)">
                <rect
                  x="0"
                  y="0"
                  width="18"
                  height="30"
                  rx="9"
                  fill="#F59E0B"
                  stroke="#FFFFFF"
                  strokeWidth="4"
                />
                <line
                  x1="0"
                  y1="15"
                  x2="18"
                  y2="15"
                  stroke="#FFFFFF"
                  strokeWidth="3"
                />
              </g>
            </svg>
          </div>
          <div className="shrink-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="text-xl sm:text-2xl font-black text-emerald-700 tracking-tight leading-none whitespace-nowrap">
                med<span className="text-slate-900">take</span>
              </span>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 whitespace-nowrap">
                Caregiver Portal
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium hidden sm:block whitespace-nowrap">
              Multilingual Alarm & Guardian Telehealth
            </p>
          </div>
        </div>

        {/* User Info & Controls */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Offline / IndexedDB Fallback Indicator */}
          {!isOnline ? (
            <div
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-900 text-xs font-bold shadow-2xs"
              title="Device is Offline: Dose history safely stores in IndexedDB"
            >
              <WifiOff className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden md:inline">Offline (IndexedDB)</span>
              {pendingCount > 0 && (
                <span className="bg-amber-600 text-white rounded-full px-1.5 text-[10px] leading-tight font-extrabold">
                  {pendingCount}
                </span>
              )}
            </div>
          ) : pendingCount > 0 ? (
            <div
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-sky-50 border border-sky-300 text-sky-900 text-xs font-bold shadow-2xs"
              title="IndexedDB Fallback Queue: Logs awaiting auto-sync"
            >
              <Database className="w-3.5 h-3.5 text-sky-700 animate-pulse" />
              <span className="hidden md:inline">{pendingCount} in Queue</span>
            </div>
          ) : null}

          {/* Notification Button */}
          <button
            onClick={onNotificationClick}
            className="relative p-2 rounded-xl text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 transition-all cursor-pointer shadow-2xs active:scale-95 flex items-center justify-center shrink-0"
            title="Notifications & Guardian Outbox Alerts (SMS + WhatsApp)"
          >
            <Bell className="w-4 h-4 text-emerald-700" />
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
          </button>

          {/* Settings button placed right beside notification */}
          {onOpenSettingsModal && (
            <button
              onClick={onOpenSettingsModal}
              className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-slate-800 hover:text-slate-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-all cursor-pointer shadow-2xs active:scale-95 shrink-0"
              title="Settings: Mountain Scenes, 35mm Film Grain, Clock Dial, Guardian Settings, Voice Tester"
            >
              <Settings className="w-4 h-4 text-emerald-800" />
              <span className="hidden sm:inline text-xs font-black text-emerald-950">Settings</span>
            </button>
          )}

          {/* Public Landing Website shortcut */}
          {onNavigateToLanding && (
            <button
              onClick={onNavigateToLanding}
              className="flex items-center gap-1 px-2.5 py-2 rounded-xl text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 transition-all cursor-pointer shadow-2xs active:scale-95 shrink-0"
              title="View Public Product Landing Website & Features"
            >
              <span className="text-xs font-bold text-slate-800 hidden md:inline">🌐 Public Site</span>
            </button>
          )}

          {/* Time Zone info */}
          <div className="hidden lg:flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-100 text-slate-600 text-xs font-mono">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>IST (UTC+5:30)</span>
          </div>

          {/* User badge */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-sm shadow-xs uppercase">
              {username.charAt(0)}
            </div>
            <div className="hidden sm:block text-left">
              <div className="text-xs font-bold text-slate-800 truncate max-w-[120px]">
                {username}
              </div>
              <div className="text-[10px] text-emerald-600 font-semibold">
                Caregiver
              </div>
            </div>
          </div>

          {/* 3-Dot Menu Button: App Details & Developer Helpline (+91 8088901642) */}
          {onOpenAppDetailsModal && (
            <button
              onClick={onOpenAppDetailsModal}
              className="p-2 rounded-xl text-slate-700 hover:text-slate-900 hover:bg-slate-100 border border-slate-300/80 transition-all cursor-pointer shadow-2xs active:scale-95 flex items-center justify-center shrink-0"
              title="App Details & Developer Helpline Hotline (+91 8088901642)"
            >
              <MoreVertical className="w-4 h-4 text-slate-800" />
            </button>
          )}

          {/* Logout */}
          <button
            onClick={onLogout}
            className="p-2 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer shrink-0"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
