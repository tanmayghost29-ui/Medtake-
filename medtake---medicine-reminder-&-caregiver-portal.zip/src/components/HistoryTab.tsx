import React, { useState } from "react";
import { HistoryItem, Patient, Medicine } from "../types";
import {
  History,
  Trash2,
  Download,
  Search,
  CheckCircle2,
  Clock,
  Calendar,
  Check,
  RefreshCw,
  Wifi,
  WifiOff,
  Database,
  CloudCheck,
  AlertTriangle,
  Send,
  Stethoscope,
  FileText,
} from "lucide-react";
import { useOfflineSync, offlineSyncManager, PendingHistoryLog } from "../utils/offlineSync";
import { DoctorReportModal } from "./DoctorReportModal";

interface HistoryTabProps {
  username?: string;
  history: HistoryItem[];
  onClearHistory: () => void;
  onRecordTestDose?: (item: HistoryItem) => void;
  patients?: Record<string, Patient>;
  medicines?: Medicine[];
  guardianPhone?: string;
}

export const HistoryTab: React.FC<HistoryTabProps> = ({
  username = "Caregiver",
  history,
  onClearHistory,
  onRecordTestDose,
  patients = {},
  medicines = [],
  guardianPhone = "",
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [isDoctorReportOpen, setIsDoctorReportOpen] = useState(false);

  // Hook for real-time IndexedDB offline fallback queue and connection monitoring
  const { isOnline, pendingCount, lastSyncTime, isSyncing, syncNow } = useOfflineSync();

  const reversedHistory = [...history].reverse();

  const filteredHistory = reversedHistory.filter((item) => {
    const matchesSearch =
      item.patient.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.med.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.status.toLowerCase().includes(searchTerm.toLowerCase());

    if (statusFilter === "TAKEN") {
      return matchesSearch && item.status.toLowerCase().includes("taken");
    }
    if (statusFilter === "SKIPPED") {
      return matchesSearch && item.status.toLowerCase().includes("skip");
    }
    if (statusFilter === "OFFLINE") {
      return (
        matchesSearch &&
        (item.offlineSaved === true || item.syncStatus === "offline" || item.syncStatus === "pending")
      );
    }
    return matchesSearch;
  });

  const takenCount = history.filter((h) => h.status.toLowerCase().includes("taken")).length;
  const skippedCount = history.filter((h) => h.status.toLowerCase().includes("skip")).length;
  const offlineCount = history.filter((h) => h.offlineSaved || h.syncStatus === "offline").length;
  const adherenceRate = history.length > 0 ? Math.round((takenCount / history.length) * 100) : 100;

  const handleExportCsv = () => {
    if (history.length === 0) return;
    const headers = ["Date", "Time", "Patient", "Medicine", "Status", "Sync Status"];
    const rows = history.map((h) => [
      `"${h.date}"`,
      `"${h.time}"`,
      `"${h.patient}"`,
      `"${h.med}"`,
      `"${h.status}"`,
      `"${h.offlineSaved ? "IndexedDB Fallback" : "Cloud Synced"}"`,
    ]);
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute(
      "download",
      `medtake_dose_history_${new Date().toISOString().split("T")[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleManualSync = async () => {
    setSyncFeedback(null);
    try {
      const res = await syncNow(username);
      if (res.syncedCount > 0) {
        setSyncFeedback(`✓ Successfully synced ${res.syncedCount} offline record(s) to server!`);
      } else if (res.errors && res.errors.length > 0) {
        setSyncFeedback(`Notice: ${res.errors.join(", ")}`);
      } else {
        setSyncFeedback("All offline logs are already up to date with the server.");
      }
    } catch (e: any) {
      setSyncFeedback(`Sync failed: ${e.message || "Network issue"}`);
    }
    setTimeout(() => setSyncFeedback(null), 5000);
  };

  // Allows testing offline IndexedDB storage immediately
  const handleTestOfflineDose = async () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(
      now.getDate()
    ).padStart(2, "0")}`;

    const testItem: HistoryItem = {
      id: `offline-test-${Date.now()}`,
      time: timeStr,
      date: dateStr,
      patient: "Kamala Devi",
      med: "Metformin 500mg (Offline Demo)",
      status: "Taken (IndexedDB Offline Fallback)",
      offlineSaved: true,
      syncStatus: "offline",
    };

    // Store in IndexedDB
    await offlineSyncManager.storePendingLog(testItem, username);
    if (onRecordTestDose) {
      onRecordTestDose(testItem);
    }
    setSyncFeedback("✓ Test offline dose saved to IndexedDB queue! Click 'Sync to Server' to push it.");
    setTimeout(() => setSyncFeedback(null), 5000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Info & Actions */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>📜</span> Dose History & Offline Sync
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Real-time audit trail with IndexedDB offline queue and automatic server synchronization.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsDoctorReportOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
            title="Download or Print Doctor Adherence Summary Report (PDF)"
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>Export Doctor Report (PDF)</span>
          </button>

          {history.length > 0 && (
            <>
              <button
                onClick={handleExportCsv}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                title="Download CSV for doctor consultation"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>

              <button
                onClick={() => {
                  if (window.confirm("Are you sure you want to clear all history records?")) {
                    onClearHistory();
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-red-600 hover:bg-red-50 border border-transparent font-bold text-xs transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* IndexedDB Offline Fallback Status Card */}
      <div
        className={`p-5 rounded-2xl border transition-all ${
          !isOnline
            ? "bg-amber-50/90 border-amber-300 text-amber-950"
            : pendingCount > 0
            ? "bg-sky-50/90 border-sky-300 text-sky-950"
            : "bg-emerald-50/80 border-emerald-200 text-emerald-950"
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
                !isOnline
                  ? "bg-amber-500 text-white"
                  : pendingCount > 0
                  ? "bg-sky-600 text-white"
                  : "bg-emerald-600 text-white"
              }`}
            >
              {!isOnline ? (
                <WifiOff className="w-5 h-5" />
              ) : pendingCount > 0 ? (
                <Database className="w-5 h-5" />
              ) : (
                <Wifi className="w-5 h-5" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm sm:text-base">
                  {!isOnline
                    ? "Offline Mode Active (IndexedDB Fallback Safe)"
                    : pendingCount > 0
                    ? `IndexedDB Fallback: ${pendingCount} Pending Log(s)`
                    : "Online & Cloud Synchronized"}
                </span>
                <span
                  className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full font-bold ${
                    !isOnline
                      ? "bg-amber-200 text-amber-900 border border-amber-300"
                      : "bg-emerald-200 text-emerald-900 border border-emerald-300"
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      !isOnline ? "bg-amber-600" : "bg-emerald-600 animate-pulse"
                    }`}
                  />
                  {isOnline ? "Online" : "Offline"}
                </span>
              </div>

              <p className="text-xs mt-1 text-slate-700 leading-relaxed max-w-2xl">
                {!isOnline
                  ? "Device connection is currently offline. All dose confirmations and alarm actions are safely stored locally in IndexedDB storage and will automatically sync to the server when connection is restored."
                  : pendingCount > 0
                  ? `There are ${pendingCount} medicine log(s) preserved in IndexedDB awaiting synchronization with the server.`
                  : "All medicine history logs are synchronized. If the network drops, IndexedDB automatically takes over without losing data."}
              </p>

              {lastSyncTime && (
                <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-mono">
                  <span>Last server sync:</span>
                  <span className="font-semibold text-slate-700">{lastSyncTime}</span>
                </p>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap sm:flex-col items-stretch gap-2 shrink-0 self-start sm:self-center">
            <button
              onClick={handleManualSync}
              disabled={isSyncing || !isOnline}
              className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                isOnline
                  ? "bg-slate-900 hover:bg-slate-800 text-white"
                  : "bg-slate-200 text-slate-400 cursor-not-allowed"
              }`}
              title="Push pending IndexedDB records to server"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
              <span>{isSyncing ? "Syncing..." : "Sync to Server"}</span>
            </button>

            <button
              onClick={handleTestOfflineDose}
              className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
              title="Inject a test dose into IndexedDB to observe offline queuing"
            >
              <Database className="w-3 h-3 text-amber-600" />
              <span>Test Offline Log</span>
            </button>
          </div>
        </div>

        {syncFeedback && (
          <div className="mt-3 pt-3 border-t border-slate-200/80 text-xs font-bold text-emerald-800 flex items-center gap-1.5 animate-fadeIn">
            <span>⚡</span>
            <span>{syncFeedback}</span>
          </div>
        )}
      </div>

      {/* Adherence Stats Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Taken on Time
            </span>
            <div className="text-xl sm:text-2xl font-black text-slate-900">{takenCount}</div>
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Skipped / Snoozed
            </span>
            <div className="text-xl sm:text-2xl font-black text-slate-900">{skippedCount}</div>
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              IndexedDB Logs
            </span>
            <div className="text-xl sm:text-2xl font-black text-sky-900">
              {pendingCount > 0 ? `${pendingCount} pending` : `${offlineCount} saved`}
            </div>
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Adherence Rate
            </span>
            <div className="text-xl sm:text-2xl font-black text-emerald-700">{adherenceRate}%</div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search medicine or patient..."
            className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-emerald-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5 self-end sm:self-center">
          <button
            onClick={() => setStatusFilter("ALL")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              statusFilter === "ALL"
                ? "bg-slate-900 text-white"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            All ({reversedHistory.length})
          </button>
          <button
            onClick={() => setStatusFilter("TAKEN")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              statusFilter === "TAKEN"
                ? "bg-emerald-600 text-white"
                : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
            }`}
          >
            Taken ({takenCount})
          </button>
          <button
            onClick={() => setStatusFilter("SKIPPED")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              statusFilter === "SKIPPED"
                ? "bg-amber-600 text-white"
                : "bg-amber-50 text-amber-700 hover:bg-amber-100"
            }`}
          >
            Skipped ({skippedCount})
          </button>
          <button
            onClick={() => setStatusFilter("OFFLINE")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              statusFilter === "OFFLINE"
                ? "bg-sky-700 text-white"
                : "bg-sky-50 text-sky-800 hover:bg-sky-100"
            }`}
          >
            Offline/IndexedDB ({offlineCount})
          </button>
        </div>
      </div>

      {/* History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredHistory.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <History className="w-8 h-8 mx-auto text-slate-300" />
            <p className="text-sm font-semibold">Nothing recorded yet.</p>
            <p className="text-xs">
              When an alarm rings and you take or skip a dose, records will appear here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Medicine</th>
                  <th className="py-3 px-4">Status & Action</th>
                  <th className="py-3 px-4">Sync Storage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredHistory.map((item, idx) => {
                  const isTaken = item.status.toLowerCase().includes("taken");
                  const isOfflineSaved =
                    item.offlineSaved === true ||
                    item.syncStatus === "offline" ||
                    item.syncStatus === "pending";

                  return (
                    <tr key={item.id || idx} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-medium text-slate-600 whitespace-nowrap">
                        <span className="font-bold text-slate-900 block">{item.time}</span>
                        <span className="text-[11px] text-slate-400">{item.date}</span>
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">{item.patient}</td>
                      <td className="py-3.5 px-4 font-semibold text-slate-900">{item.med}</td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full font-bold text-[11px] ${
                            isTaken
                              ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                              : "bg-amber-100 text-amber-900 border border-amber-200"
                          }`}
                        >
                          {isTaken ? (
                            <Check className="w-3 h-3 text-emerald-700" />
                          ) : (
                            <Clock className="w-3 h-3 text-amber-700" />
                          )}
                          <span>{item.status}</span>
                        </span>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {isOfflineSaved ? (
                          <span
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-bold text-[11px]"
                            title="Stored in IndexedDB offline fallback queue"
                          >
                            <Database className="w-3 h-3 text-amber-600" />
                            <span>IndexedDB Queue</span>
                          </span>
                        ) : (
                          <span
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200 font-medium text-[11px]"
                            title="Synchronized to server"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            <span>Server Synced</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Doctor Clinical Adherence Report Modal */}
      <DoctorReportModal
        isOpen={isDoctorReportOpen}
        onClose={() => setIsDoctorReportOpen(false)}
        patients={patients}
        medicines={medicines}
        history={history}
        username={username}
        guardianPhone={guardianPhone}
      />
    </div>
  );
};
