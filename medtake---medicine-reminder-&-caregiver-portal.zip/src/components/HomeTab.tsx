import React, { useState, useEffect, useMemo } from "react";
import { Medicine, Patient } from "../types";
import { PatientAvatar } from "./PatientAvatar";
import {
  Bell,
  ArrowRight,
  Pill,
  Clock,
  Sparkles,
  Smartphone,
  ShieldCheck,
  Zap,
  Volume2,
  PhoneCall,
  Flame,
  Award,
  Edit3,
  Mountain,
  Sliders,
  Wind,
  Check,
  Calendar,
  Settings,
  Building2,
} from "lucide-react";
import { LOW_STOCK_LIMIT } from "../constants/ringtones";
import { soundEngine } from "../utils/audio";
import {
  createPhoneCallUrl,
  createSmsIntentUrl,
  createWhatsAppUrl,
  normalizePhoneNumber,
} from "../utils/storage";
import { useWakeLock } from "../utils/wakeLock";
import { CinematicClock } from "./CinematicClock";
import {
  NatureMountainView,
  FilmSettingsState,
  MOUNTAIN_SCENES,
} from "./NatureMountainView";
import { EditTimeModal } from "./EditTimeModal";
import { PharmacyRefillModal } from "./PharmacyRefillModal";
import { NotificationPermissionBanner } from "./NotificationPermissionBanner";

interface HomeTabProps {
  username: string;
  themeMode: "auto" | "day" | "night";
  medicines: Medicine[];
  patients: Record<string, Patient>;
  onTriggerTestAlarm: (medId?: string) => void;
  onNavigateToTab: (tabKey: string) => void;
  onUpdateStock: (medId: string, newStock: number) => void;
  onUpdateTime?: (medId: string, newTime: string) => void;
  onOpenApkModal?: () => void;
  onOpenCopyrightModal?: () => void;
  onOpenAppDetailsModal?: () => void;
  onOpenSettings?: () => void;
  clockStyle?: "chronometer" | "digital_hud" | "minimal";
  onChangeClockStyle?: (style: "chronometer" | "digital_hud" | "minimal") => void;
  activeSceneId?: string;
  onSelectScene?: (id: string) => void;
  filmSettings?: FilmSettingsState;
  onUpdateFilmSettings?: (settings: Partial<FilmSettingsState>) => void;
  userGuardianPhone?: string;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  username,
  themeMode,
  medicines,
  patients,
  onTriggerTestAlarm,
  onNavigateToTab,
  onUpdateStock,
  onUpdateTime,
  onOpenApkModal,
  onOpenCopyrightModal,
  onOpenAppDetailsModal,
  onOpenSettings,
  userGuardianPhone,
  clockStyle: propClockStyle,
  onChangeClockStyle,
  activeSceneId: propActiveSceneId,
  onSelectScene,
  filmSettings: propFilmSettings,
  onUpdateFilmSettings,
}) => {
  const [deviceTime, setDeviceTime] = useState(new Date());
  const { isBedsideActive: wakeLockActive } = useWakeLock();

  // Time Editing Modal State (addresses user request to edit time where circled in green)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const [timeUpdateToast, setTimeUpdateToast] = useState<string | null>(null);
  const [refillMed, setRefillMed] = useState<Medicine | null>(null);

  // Mountain & Nature View + Film Settings State (synced with AppSettingsModal)
  const [internalSceneId, setInternalSceneId] = useState<string>("alpine_dawn");
  const [isZenMode, setIsZenMode] = useState(false);
  const [internalClockStyle, setInternalClockStyle] = useState<"chronometer" | "digital_hud" | "minimal">("chronometer");
  const [internalFilmSettings, setInternalFilmSettings] = useState<FilmSettingsState>({
    grainIntensity: "cinema35mm",
    colorGrade: "portra",
    anamorphicBars: false,
    mountainBreezeActive: false,
    breezeVolume: 0.15,
  });

  const activeSceneId = propActiveSceneId ?? internalSceneId;
  const setActiveSceneId = onSelectScene ?? setInternalSceneId;
  const clockStyle = propClockStyle ?? internalClockStyle;
  const setClockStyle = onChangeClockStyle ?? setInternalClockStyle;
  const filmSettings = propFilmSettings ?? internalFilmSettings;
  const handleUpdateFilmSettings = onUpdateFilmSettings ?? ((updated: Partial<FilmSettingsState>) =>
    setInternalFilmSettings((prev) => ({ ...prev, ...updated }))
  );

  // Synchronize every second directly to the device's exact local hardware clock
  useEffect(() => {
    const timer = setInterval(() => {
      setDeviceTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const hours = deviceTime.getHours();
  const minutes = deviceTime.getMinutes();
  const seconds = deviceTime.getSeconds();

  // Determine daylight vs night based on exact local phone time (6 AM to 6 PM)
  const isDay = useMemo(() => {
    if (themeMode === "day") return true;
    if (themeMode === "night") return false;
    return hours >= 6 && hours < 18;
  }, [themeMode, hours]);

  // Clean greeting strictly matched to exact local time of user's device
  const greeting = useMemo(() => {
    if (hours >= 5 && hours < 12) return "Good Morning";
    if (hours >= 12 && hours < 17) return "Good Afternoon";
    if (hours >= 17 && hours < 21) return "Good Evening";
    return "Good Night";
  }, [hours]);

  // Clean formatted proper name for active user
  const displayName = useMemo(() => {
    if (!username) return "Caregiver";
    return username.trim();
  }, [username]);

  // Find next upcoming dose using the same local device clock
  const nextDoseInfo = useMemo<{
    medicine: Medicine | null;
    secondsRemaining: number;
  } | null>(() => {
    if (!medicines || medicines.length === 0) {
      return null;
    }

    let nearestMed: Medicine | null = null;
    let shortestSeconds = Infinity;

    medicines.forEach((med) => {
      const [medH, medM] = med.time.split(":").map(Number);
      const target = new Date(deviceTime);
      target.setHours(medH, medM, 0, 0);

      // If scheduled time has already passed today, target tomorrow
      if (target.getTime() <= deviceTime.getTime()) {
        target.setDate(target.getDate() + 1);
      }

      const diffSec = Math.floor((target.getTime() - deviceTime.getTime()) / 1000);
      if (diffSec < shortestSeconds) {
        shortestSeconds = diffSec;
        nearestMed = med;
      }
    });

    return {
      medicine: nearestMed,
      secondsRemaining: shortestSeconds,
    };
  }, [medicines, deviceTime]);

  const activeNextMed = nextDoseInfo?.medicine;
  const nextPatient = activeNextMed && patients ? patients[activeNextMed.patient] : null;

  // Guardian phone dynamically from active patient profile or user profile settings
  const guardianPhone = normalizePhoneNumber(
    nextPatient?.guardian_phone || userGuardianPhone || ""
  );
  const callGuardianUrl = createPhoneCallUrl(guardianPhone);

  const formatCountdown = (totalSec: number) => {
    if (totalSec <= 0 || !isFinite(totalSec)) return "-- : -- : --";
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, "0")}h : ${String(m).padStart(2, "0")}m : ${String(s).padStart(2, "0")}s`;
  };

  const lowStockMeds = medicines.filter((m) => m.stock <= LOW_STOCK_LIMIT);

  // Open edit modal for upcoming medicine or any selected medicine
  const handleOpenEditTime = (med?: Medicine) => {
    const target = med || activeNextMed || medicines[0] || null;
    if (target) {
      setEditingMedicine(target);
      setIsEditModalOpen(true);
    }
  };

  // Quick implementation of new time (green pen circle requirement)
  const handleImplementTime = (medId: string, newTime: string) => {
    if (onUpdateTime) {
      onUpdateTime(medId, newTime);
    }
    const med = medicines.find((m) => m.id === medId);
    const medName = med?.name || "Medicine";
    setTimeUpdateToast(`Scheduled time updated to ${newTime} for ${medName}! Alarm is active.`);
    setTimeout(() => {
      setTimeUpdateToast(null);
    }, 4500);
  };

  // Quick 1-minute test alarm setter
  const handleSetQuickTestTime = () => {
    const target = activeNextMed || medicines[0];
    if (!target) return;
    const d = new Date();
    d.setMinutes(d.getMinutes() + 1);
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    const newTime = `${hh}:${mm}`;
    handleImplementTime(target.id, newTime);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-10">
      {/* Prominent First-Launch Voice & Notification Permission Banner */}
      <NotificationPermissionBanner />

      {/* Toast Notification when time is updated */}
      {timeUpdateToast && (
        <div className="p-3.5 rounded-2xl bg-emerald-600 text-white text-xs font-bold shadow-lg flex items-center justify-between animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-200" />
            <span>{timeUpdateToast}</span>
          </div>
          <button
            onClick={() => setTimeUpdateToast(null)}
            className="text-white/80 hover:text-white px-2 py-0.5 rounded-md hover:bg-white/10"
          >
            ✕
          </button>
        </div>
      )}

      {/* NATURE & MOUNTAIN VIEW CONTAINER WITH 35MM FILM SETTINGS & CINEMATIC CLOCK */}
      <NatureMountainView
        activeSceneId={activeSceneId}
        onSelectScene={setActiveSceneId}
        filmSettings={filmSettings}
        onUpdateFilmSettings={handleUpdateFilmSettings}
        isZenMode={isZenMode}
        onToggleZenMode={() => setIsZenMode(!isZenMode)}
        onOpenSettings={onOpenSettings}
      >
        {/* Header Row inside Nature & Mountain Widget */}
        <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white drop-shadow-md flex items-center gap-2">
                <span>Hi, {displayName}</span>
                <span className="inline-block animate-wave origin-bottom-right">👋</span>
              </h2>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm sm:text-base font-bold text-amber-300 drop-shadow-sm">
                {greeting}
              </span>
              <span className="text-xs text-white/60">•</span>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-black/40 backdrop-blur-md text-white border border-white/20">
                {String(hours).padStart(2, "0")}:{String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")} Local Time
              </span>
            </div>
          </div>
        </div>

        {/* Center Clock (Redesigned with Alpine Chronometer / Cinema HUD & High-Precision Animation) */}
        <div className="my-2">
          <CinematicClock
            deviceTime={deviceTime}
            isDay={isDay}
            styleMode={clockStyle}
            onChangeStyle={setClockStyle}
            onOpenEditTime={() => handleOpenEditTime()}
            showStylePicker={false}
          />
        </div>

        {/* Countdown & Next Dose Display */}
        <div className="flex flex-col items-center justify-center text-center my-3 space-y-3">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-white/90 drop-shadow-sm">
              Next Scheduled Dose In
            </span>
            <div className="text-2xl sm:text-3xl font-black font-mono px-6 py-2 rounded-2xl border tracking-wider shadow-inner transition-colors bg-black/50 backdrop-blur-md text-amber-300 border-white/20 drop-shadow-lg">
              {nextDoseInfo
                ? formatCountdown(nextDoseInfo.secondsRemaining)
                : "-- : -- : --"}
            </div>
          </div>

          {/* NEXT DOSE BADGE WITH EDIT TIME OPTION (Where marked in green circle) */}
          <div className="flex flex-col sm:flex-row items-center gap-2 pt-1 flex-wrap justify-center">
            {/* Scheduled Medicine Pill Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold border shadow-lg bg-black/60 backdrop-blur-md text-white border-white/20">
              {activeNextMed ? (
                <>
                  <PatientAvatar
                    name={activeNextMed.patient}
                    avatarUrl={nextPatient?.avatar}
                    size="xs"
                    showBorder={false}
                  />
                  <span>
                    <strong className="text-amber-300 underline decoration-dotted">
                      {activeNextMed.name}
                    </strong>
                    {" "}({activeNextMed.patient}) at{" "}
                    <strong className="text-emerald-300 font-mono text-sm px-1.5 py-0.5 rounded bg-white/10">
                      {activeNextMed.time}
                    </strong>
                  </span>
                </>
              ) : (
                <>
                  <Pill className="w-3.5 h-3.5 text-emerald-400" />
                  <span>No scheduled doses yet</span>
                </>
              )}
            </div>

            {/* EDIT TIME BUTTON (Highlighted for user request in green circle) */}
            <button
              type="button"
              onClick={() => handleOpenEditTime(activeNextMed || undefined)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-white font-extrabold text-xs shadow-md border border-emerald-300 transition-all cursor-pointer"
              title="Edit scheduled time for this medicine - will be implemented immediately"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Time ✏️</span>
            </button>

            {/* Quick +1 Min Test Alarm Button */}
            <button
              type="button"
              onClick={handleSetQuickTestTime}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-full bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-black text-xs shadow-md border border-amber-300 transition-all cursor-pointer"
              title="Schedule dose 1 minute from now to test alarm"
            >
              <Sparkles className="w-3 h-3" />
              <span>+1m Test</span>
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
          <button
            onClick={() => onTriggerTestAlarm()}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 cursor-pointer bg-amber-400 hover:bg-amber-300 text-slate-950 border border-amber-300"
          >
            <Bell className="w-4 h-4" />
            <span>🔔 Ring Alarm Now</span>
          </button>

          <button
            onClick={() => onNavigateToTab("medicines")}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs transition-colors cursor-pointer bg-white/20 hover:bg-white/30 text-white border border-white/20 backdrop-blur-md"
          >
            <span>All Medicines ({medicines.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </NatureMountainView>

      {/* Dynamic Guardian Automated Alerts Card */}
      <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800">
              <Zap className="w-5 h-5 fill-emerald-600 text-emerald-600" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Guardian Automated Alerts
              </h3>
              <span className="text-xs text-emerald-700 font-semibold block">
                Direct SMS + WhatsApp • Dispatches without prompt
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {guardianPhone ? (
              <>
                <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-900 font-mono text-xs font-bold border border-emerald-200">
                  {guardianPhone}
                </span>
                <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold">
                  Active
                </span>
              </>
            ) : (
              <span className="px-3 py-1 rounded-full bg-amber-50 text-amber-900 font-mono text-xs font-bold border border-amber-200">
                Not Configured
              </span>
            )}
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
          {guardianPhone ? (
            <>
              All medicine dose confirmations, snoozes, missed dose warnings, and refill stock notices route dynamically to guardian contact <strong>{guardianPhone}</strong>.
            </>
          ) : (
            <>
              No guardian contact number configured yet. Enter a guardian phone number in Profile Settings to enable automatic SMS and WhatsApp alerts.
            </>
          )}
        </p>

        <div className="flex flex-wrap items-center gap-2.5 pt-1">
          {guardianPhone && callGuardianUrl ? (
            <a
              href={callGuardianUrl}
              className="py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              title="Call guardian now"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Emergency Call Guardian</span>
            </a>
          ) : (
            onOpenSettings && (
              <button
                onClick={onOpenSettings}
                className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              >
                <Settings className="w-4 h-4" />
                <span>Configure Guardian in Settings</span>
              </button>
            )
          )}

          <button
            onClick={() => onNavigateToTab("sms")}
            className="py-2.5 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
          >
            View Alert Outbox &rarr;
          </button>
        </div>
      </div>

      {/* Adherence Health Score Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shrink-0">
            <Flame className="w-6 h-6 fill-amber-500 text-amber-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-black text-slate-900">
                100% On-Time Adherence
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold">
                7-Day Streak 🔥
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Patients Kamala Devi & Ramachandra Sharma are adhering accurately to prescribed schedules.
            </p>
          </div>
        </div>

        {onOpenAppDetailsModal && (
          <button
            onClick={onOpenAppDetailsModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer self-start sm:self-auto shrink-0"
          >
            <Award className="w-3.5 h-3.5 text-emerald-600" />
            <span>App Details & Helpline</span>
          </button>
        )}
      </div>

      {/* Low Stock Warning Banner if applicable */}
      {lowStockMeds.length > 0 && (
        <div className="p-4 sm:p-5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2.5 text-xs font-bold">
            <span className="p-1.5 rounded-xl bg-amber-200 text-amber-900 font-extrabold text-sm">⚠️</span>
            <div>
              <span className="block font-black text-amber-950">
                Low Medicine Stock Alert ({lowStockMeds.length} medicine{lowStockMeds.length > 1 ? "s" : ""})
              </span>
              <span className="text-amber-800 text-[11px] font-normal">
                {lowStockMeds.map((m) => `${m.name} (${m.stock} left)`).join(", ")}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setRefillMed(lowStockMeds[0])}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>1-Click WhatsApp Refill</span>
            </button>

            <button
              onClick={() => onNavigateToTab("medicines")}
              className="text-xs font-bold text-amber-900 hover:underline px-2 py-1 cursor-pointer"
            >
              Manage &rarr;
            </button>
          </div>
        </div>
      )}

      {/* Time Editor Modal (Allows user to edit the time and implements it immediately) */}
      <EditTimeModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        medicine={editingMedicine}
        onUpdateTime={handleImplementTime}
      />

      {/* Pharmacy WhatsApp Refill Modal */}
      <PharmacyRefillModal
        isOpen={!!refillMed}
        onClose={() => setRefillMed(null)}
        medicine={refillMed}
        patient={refillMed && patients ? patients[refillMed.patient] : null}
      />
    </div>
  );
};
