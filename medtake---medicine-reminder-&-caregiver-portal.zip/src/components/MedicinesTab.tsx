import React, { useState, useRef } from "react";
import { Medicine, Patient, MealTiming } from "../types";
import { RINGTONE_LIST, MEAL_OPTIONS, LOW_STOCK_LIMIT } from "../constants/ringtones";
import { soundEngine } from "../utils/audio";
import { PatientAvatar } from "./PatientAvatar";
import { AiPrescriptionModal } from "./AiPrescriptionModal";
import { Pill, Plus, Bell, Trash2, Volume2, Sparkles, Upload, AlertTriangle, Clock, RefreshCw, X, Edit3, Building2 } from "lucide-react";
import { EditTimeModal } from "./EditTimeModal";
import { PharmacyRefillModal } from "./PharmacyRefillModal";

interface MedicinesTabProps {
  medicines: Medicine[];
  patients: Record<string, Patient>;
  onAddMedicine: (medicine: Omit<Medicine, "id">) => void;
  onDeleteMedicine: (id: string) => void;
  onUpdateStock: (id: string, newStock: number) => void;
  onTriggerAlarm: (medId: string) => void;
  onUpdateTime?: (id: string, newTime: string) => void;
}

export const MedicinesTab: React.FC<MedicinesTabProps> = ({
  medicines,
  patients,
  onAddMedicine,
  onDeleteMedicine,
  onUpdateStock,
  onTriggerAlarm,
  onUpdateTime,
}) => {
  const patientNames = Object.keys(patients);

  // Form states
  const [selectedPatient, setSelectedPatient] = useState(patientNames[0] || "");
  const [name, setName] = useState("");
  const [dose, setDose] = useState(1);
  const [stock, setStock] = useState(30);
  const [time, setTime] = useState("08:00");
  const [mealTiming, setMealTiming] = useState<MealTiming>("After food");
  const [ringtone, setRingtone] = useState(RINGTONE_LIST[0] || "Digital Clock Beep");
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [filterPatient, setFilterPatient] = useState<string>("ALL");
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isEditTimeModalOpen, setIsEditTimeModalOpen] = useState(false);
  const [editingMed, setEditingMed] = useState<Medicine | null>(null);
  const [refillMed, setRefillMed] = useState<Medicine | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Default patient update when patients load
  React.useEffect(() => {
    if (!selectedPatient && patientNames.length > 0) {
      setSelectedPatient(patientNames[0]);
    }
  }, [patientNames, selectedPatient]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setPhotoUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) {
      setFormError("Please select a patient.");
      return;
    }
    if (!name.trim()) {
      setFormError("Medicine name is required.");
      return;
    }

    onAddMedicine({
      patient: selectedPatient,
      name: name.trim(),
      dose: Math.max(1, Math.floor(dose)),
      stock: Math.max(0, Math.floor(stock)),
      time: time || "08:00",
      meal_timing: mealTiming,
      ringtone,
      photo: photoUrl,
    });

    // Reset fields
    setName("");
    setDose(1);
    setStock(30);
    setTime("08:00");
    setPhotoUrl(null);
    setFormError(null);
  };

  const handleApplyAiData = (data: {
    name: string;
    dose: number;
    time: string;
    mealTiming: MealTiming;
    stock: number;
  }) => {
    setName(data.name);
    setDose(data.dose);
    setTime(data.time);
    setMealTiming(data.mealTiming);
    setStock(data.stock);
  };

  // Filtered and sorted schedule
  const filteredMeds = medicines
    .filter((m) => filterPatient === "ALL" || m.patient === filterPatient)
    .sort((a, b) => a.time.localeCompare(b.time));

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Top Banner & AI Scanner trigger */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>💊</span> Medicine Schedules & Stock
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Program daily dosing times, meal alignments, tablet counts, and custom alarm ringtones.
          </p>
        </div>
        <button
          onClick={() => setIsAiModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all cursor-pointer w-fit"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Prescription Scanner</span>
        </button>
      </div>

      {/* Add Medicine Form */}
      {patientNames.length === 0 ? (
        <div className="p-8 rounded-3xl bg-amber-50 border border-amber-200 text-center space-y-2">
          <AlertTriangle className="w-8 h-8 mx-auto text-amber-600" />
          <h3 className="font-bold text-base text-amber-900">No Patients Registered</h3>
          <p className="text-xs text-amber-700">
            Please add at least one patient under the <strong>Patients</strong> tab first.
          </p>
        </div>
      ) : (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-emerald-100 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl">
                <Plus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-slate-900">Add a Medicine</h3>
                <p className="text-xs text-slate-500">
                  Set daily alarm hour, dosage, and stock refill tracker.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsAiModalOpen(true)}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Autofill with AI</span>
            </button>
          </div>

          {formError && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-medium">
              {formError}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Patient */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Patient <span className="text-red-500">*</span>
                </label>
                <select
                  value={selectedPatient}
                  onChange={(e) => setSelectedPatient(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium bg-white focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                >
                  {patientNames.map((p) => (
                    <option key={p} value={p}>
                      {p} ({patients[p]?.lang})
                    </option>
                  ))}
                </select>
              </div>

              {/* Medicine Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Medicine Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Metformin 500mg"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              {/* Time to Take */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  Time to Take (HH:MM) <span className="text-red-500">*</span>
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              {/* Tablets per Dose */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Tablets per Dose
                </label>
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={dose}
                  onChange={(e) => setDose(parseInt(e.target.value) || 1)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              {/* Tablets in Stock */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Tablets in Stock (Refill Count)
                </label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={stock}
                  onChange={(e) => setStock(parseInt(e.target.value) || 0)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              {/* Meal Timing */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Meal Timing
                </label>
                <select
                  value={mealTiming}
                  onChange={(e) => setMealTiming(e.target.value as MealTiming)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium bg-white focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                >
                  {MEAL_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>

              {/* Ringtone */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Alarm Ringtone
                  </label>
                  <button
                    type="button"
                    onClick={() => soundEngine.previewRingtone(ringtone)}
                    className="text-xs font-bold text-emerald-600 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Preview</span>
                  </button>
                </div>
                <select
                  value={ringtone}
                  onChange={(e) => setRingtone(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium bg-white focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                >
                  {RINGTONE_LIST.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              {/* Tablet Photo Upload */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Tablet Photo (Shown on alarm screen)
                </label>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 hover:border-emerald-500 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-slate-500" />
                    <span>{photoUrl ? "Change Tablet Photo" : "Upload Tablet Photo"}</span>
                  </button>
                  {photoUrl && (
                    <div className="flex items-center gap-2">
                      <img
                        src={photoUrl}
                        alt="Selected pill"
                        className="w-9 h-9 rounded-lg object-cover border border-slate-200 shadow-xs"
                        referrerPolicy="no-referrer"
                      />
                      <button
                        type="button"
                        onClick={() => setPhotoUrl(null)}
                        className="p-1 rounded-md text-red-500 hover:bg-red-50"
                        title="Remove photo"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
              >
                Save Scheduled Medicine
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Schedule Table & Quick Stock Editor */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="font-bold text-base text-slate-800 flex items-center gap-2">
            <span>Daily Schedule</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 font-semibold text-slate-600">
              {filteredMeds.length} dose{filteredMeds.length !== 1 ? "s" : ""}
            </span>
          </h3>

          {/* Filter by Patient */}
          {patientNames.length > 1 && (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-semibold">Filter:</span>
              <select
                value={filterPatient}
                onChange={(e) => setFilterPatient(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white font-medium text-slate-700"
              >
                <option value="ALL">All Patients</option>
                {patientNames.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {filteredMeds.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-dashed border-slate-300 text-center text-slate-500 space-y-2">
            <Pill className="w-8 h-8 mx-auto text-slate-300" />
            <p className="font-medium text-sm">No medicines scheduled yet.</p>
            <p className="text-xs">Add your first medicine above to start tracking doses.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3">
            {filteredMeds.map((med) => {
              const isLowStock = med.stock <= LOW_STOCK_LIMIT;
              const patient = patients[med.patient];

              return (
                <div
                  key={med.id}
                  className={`bg-white p-4 sm:p-5 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    isLowStock
                      ? "border-amber-300 bg-amber-50/20 shadow-xs"
                      : "border-slate-200 shadow-xs hover:border-emerald-200"
                  }`}
                >
                  {/* Left: Time, Pill Image, Name, Patient */}
                  <div className="flex items-center gap-4">
                    {/* Time Pill Badge - Clickable to edit time */}
                    <button
                      type="button"
                      onClick={() => {
                        setEditingMed(med);
                        setIsEditTimeModalOpen(true);
                      }}
                      className="flex flex-col items-center justify-center w-16 h-16 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 shrink-0 transition-all cursor-pointer group shadow-2xs hover:scale-105"
                      title="Click to edit alarm time"
                    >
                      <div className="flex items-center gap-0.5 text-[10px] font-mono font-extrabold leading-none text-emerald-700">
                        <span>TIME</span>
                        <Edit3 className="w-2.5 h-2.5 opacity-60 group-hover:opacity-100 text-emerald-600" />
                      </div>
                      <span className="text-sm font-black mt-0.5 tracking-tight font-mono text-emerald-950">
                        {med.time}
                      </span>
                    </button>

                    {/* Tablet Thumbnail or icon */}
                    {med.photo ? (
                      <img
                        src={med.photo}
                        alt={med.name}
                        className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0 shadow-2xs"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-400 flex items-center justify-center shrink-0">
                        <Pill className="w-6 h-6" />
                      </div>
                    )}

                    {/* Info */}
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-extrabold text-base text-slate-900">
                          {med.name}
                        </h4>
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                          <PatientAvatar
                            name={med.patient}
                            avatarUrl={patient?.avatar}
                            size="xs"
                            showBorder={false}
                          />
                          <span>{med.patient}</span>
                        </span>
                        {isLowStock && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200 animate-pulse">
                            <AlertTriangle className="w-3 h-3" />
                            Low stock (≤{LOW_STOCK_LIMIT})
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {med.dose} tablet(s) • {med.meal_timing} • Ringtone: {med.ringtone}
                        {patient && ` • Spoken: ${patient.lang}`}
                      </p>
                    </div>
                  </div>

                  {/* Right: Quick Stock Stepper + Test Alarm + Edit Time + Delete */}
                  <div className="flex items-center gap-2.5 self-end md:self-center flex-wrap">
                    {/* Stock counter */}
                    <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-medium">
                      <span className="text-slate-500 font-bold mr-1">Stock:</span>
                      <button
                        type="button"
                        onClick={() => onUpdateStock(med.id, Math.max(0, med.stock - 1))}
                        className="w-6 h-6 rounded-md bg-white border border-slate-200 text-slate-700 font-bold hover:bg-slate-100 flex items-center justify-center cursor-pointer"
                        title="Decrement stock"
                      >
                        -
                      </button>
                      <span className="font-bold font-mono text-sm px-1.5 min-w-[28px] text-center">
                        {med.stock}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateStock(med.id, med.stock + 1)}
                        className="w-6 h-6 rounded-md bg-white border border-slate-200 text-slate-700 font-bold hover:bg-slate-100 flex items-center justify-center cursor-pointer"
                        title="Increment stock"
                      >
                        +
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateStock(med.id, med.stock + 30)}
                        className="ml-1 text-[10px] px-2 py-1 bg-emerald-100 text-emerald-800 hover:bg-emerald-200 rounded font-bold transition-colors cursor-pointer"
                        title="Quick refill +30 tablets"
                      >
                        +30 Refill
                      </button>
                      <button
                        type="button"
                        onClick={() => setRefillMed(med)}
                        className={`p-2 sm:px-2.5 sm:py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-2xs ${
                          isLowStock
                            ? "bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300"
                            : "bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200"
                        }`}
                        title="Reorder from Apollo, MedPlus, or Local Chemist via WhatsApp"
                      >
                        <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                        <span className="hidden sm:inline">Refill</span>
                      </button>
                    </div>

                    {/* Edit Time button */}
                    <button
                      type="button"
                      onClick={() => {
                        setEditingMed(med);
                        setIsEditTimeModalOpen(true);
                      }}
                      className="p-2.5 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-600 font-bold transition-colors cursor-pointer flex items-center gap-1 text-xs"
                      title="Edit scheduled time for this medicine"
                    >
                      <Edit3 className="w-4 h-4 text-emerald-600" />
                      <span className="hidden sm:inline">Edit</span>
                    </button>

                    {/* Test Alarm for this medicine */}
                    <button
                      type="button"
                      onClick={() => onTriggerAlarm(med.id)}
                      className="p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold transition-colors cursor-pointer"
                      title="Test alarm & spoken voice for this medicine"
                    >
                      <Bell className="w-4 h-4" />
                    </button>

                    {/* Delete Medicine */}
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`Delete ${med.name} from schedule?`)) {
                          onDeleteMedicine(med.id);
                        }
                      }}
                      className="p-2.5 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                      title="Delete medicine"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* AI Prescription Modal */}
      <AiPrescriptionModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        onApplyMedicine={handleApplyAiData}
      />

      {/* Edit Time Modal */}
      <EditTimeModal
        isOpen={isEditTimeModalOpen}
        onClose={() => {
          setIsEditTimeModalOpen(false);
          setEditingMed(null);
        }}
        medicine={editingMed}
        onUpdateTime={(id, newTime) => {
          if (onUpdateTime) {
            onUpdateTime(id, newTime);
          }
        }}
      />

      {/* Pharmacy WhatsApp Refill Modal */}
      <PharmacyRefillModal
        isOpen={!!refillMed}
        onClose={() => setRefillMed(null)}
        medicine={refillMed}
        patient={refillMed && patients ? patients[refillMed.patient] : null}
      />
    </div>
  );
};
