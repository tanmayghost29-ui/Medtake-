import React, { useState, useEffect } from "react";
import {
  Mountain,
  Film,
  Volume2,
  VolumeX,
  Sliders,
  Maximize2,
  Minimize2,
  Sparkles,
  Wind,
  Sun,
  Eye,
  Check,
  Camera,
} from "lucide-react";
import { soundEngine } from "../utils/audio";

export interface MountainScene {
  id: string;
  name: string;
  subtitle: string;
  imageUrl: string;
  theme: "day" | "sunset" | "night" | "mist";
  accentColor: string;
}

export const MOUNTAIN_SCENES: MountainScene[] = [
  {
    id: "alpine_dawn",
    name: "Swiss Alpine Dawn",
    subtitle: "Golden morning light on snow-capped summits & glacial valleys",
    imageUrl:
      "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=2000&q=85",
    theme: "day",
    accentColor: "#10b981",
  },
  {
    id: "himalayan_sunset",
    name: "Himalayan Alpenglow",
    subtitle: "Warm amber & violet twilight over towering peaks",
    imageUrl:
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=2000&q=85",
    theme: "sunset",
    accentColor: "#f59e0b",
  },
  {
    id: "misty_pines",
    name: "Misty Alpine Forest",
    subtitle: "Emerald pine ridge enveloped in rolling morning fog",
    imageUrl:
      "https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?auto=format&fit=crop&w=2000&q=85",
    theme: "mist",
    accentColor: "#059669",
  },
  {
    id: "cosmic_night",
    name: "Cosmic Mountain Summit",
    subtitle: "Starry Milky Way sky over silent jagged ridges",
    imageUrl:
      "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=2000&q=85",
    theme: "night",
    accentColor: "#38bdf8",
  },
  {
    id: "glacial_lake",
    name: "Turquoise Glacial Valley",
    subtitle: "Mirror reflection of alpine summits in glacial waters",
    imageUrl:
      "https://images.unsplash.com/photo-1434725039720-aaad6dd32dfe?auto=format&fit=crop&w=2000&q=85",
    theme: "day",
    accentColor: "#06b6d4",
  },
];

export type FilmGrade =
  | "portra"
  | "velvia"
  | "teal_orange"
  | "noir"
  | "natural";

export interface FilmSettingsState {
  grainIntensity: "none" | "subtle" | "cinema35mm" | "heavy";
  colorGrade: FilmGrade;
  anamorphicBars: boolean;
  mountainBreezeActive: boolean;
  breezeVolume: number;
}

interface NatureMountainViewProps {
  activeSceneId: string;
  onSelectScene: (id: string) => void;
  filmSettings: FilmSettingsState;
  onUpdateFilmSettings: (settings: Partial<FilmSettingsState>) => void;
  isZenMode: boolean;
  onToggleZenMode: () => void;
  onOpenSettings?: () => void;
  children?: React.ReactNode;
}

export const NatureMountainView: React.FC<NatureMountainViewProps> = ({
  activeSceneId,
  onSelectScene,
  filmSettings,
  onUpdateFilmSettings,
  isZenMode,
  onToggleZenMode,
  onOpenSettings,
  children,
}) => {
  const activeScene =
    MOUNTAIN_SCENES.find((s) => s.id === activeSceneId) || MOUNTAIN_SCENES[0];

  // Film Color Grading CSS Filters
  const getColorGradeFilter = (grade: FilmGrade): string => {
    switch (grade) {
      case "portra":
        return "sepia(0.12) contrast(1.05) saturate(1.1) brightness(1.02)";
      case "velvia":
        return "contrast(1.15) saturate(1.35) brightness(0.98)";
      case "teal_orange":
        return "contrast(1.2) saturate(1.25) hue-rotate(-8deg)";
      case "noir":
        return "grayscale(1) contrast(1.35) brightness(0.92)";
      case "natural":
      default:
        return "none";
    }
  };

  // Film Grain Opacity
  const getGrainOpacity = (intensity: FilmSettingsState["grainIntensity"]) => {
    switch (intensity) {
      case "subtle":
        return 0.08;
      case "cinema35mm":
        return 0.16;
      case "heavy":
        return 0.28;
      case "none":
      default:
        return 0;
    }
  };

  return (
    <div
      className={`relative overflow-hidden transition-all duration-700 ${
        isZenMode
          ? "fixed inset-0 z-50 rounded-none w-screen h-screen flex flex-col justify-between p-6 sm:p-10"
          : "rounded-3xl border-2 border-emerald-400/40 shadow-2xl p-6 sm:p-8"
      }`}
      style={{ minHeight: isZenMode ? "100vh" : "560px" }}
    >
      {/* Background Scenic Mountain Image */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000 scale-105"
        style={{
          backgroundImage: `url(${activeScene.imageUrl})`,
          filter: getColorGradeFilter(filmSettings.colorGrade),
        }}
      />

      {/* Atmospheric Mist & Gradient Overlay */}
      <div
        className={`absolute inset-0 pointer-events-none transition-opacity duration-700 ${
          activeScene.theme === "night"
            ? "bg-gradient-to-b from-slate-950/70 via-slate-950/60 to-slate-950/90"
            : activeScene.theme === "sunset"
            ? "bg-gradient-to-b from-amber-950/40 via-purple-950/50 to-slate-950/80"
            : "bg-gradient-to-b from-emerald-950/35 via-teal-950/45 to-slate-950/80"
        }`}
      />

      {/* Animated Alpine Clouds / Rolling Fog Layers */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
        <div className="absolute -bottom-10 -left-20 w-[140%] h-64 bg-radial from-white/40 via-white/10 to-transparent blur-3xl animate-pulse" />
      </div>

      {/* Floating Alpine Mist / Pollen Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(16)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white/60 blur-[0.5px] animate-pulse"
            style={{
              width: `${(i % 3) + 2}px`,
              height: `${(i % 3) + 2}px`,
              top: `${(i * 13) % 90}%`,
              left: `${(i * 17) % 95}%`,
              animationDuration: `${3 + (i % 4)}s`,
              opacity: 0.2 + (i % 5) * 0.12,
            }}
          />
        ))}
      </div>

      {/* Authentic 35mm Film Grain SVG Shader Overlay */}
      {filmSettings.grainIntensity !== "none" && (
        <div
          className="absolute inset-0 pointer-events-none mix-blend-overlay"
          style={{ opacity: getGrainOpacity(filmSettings.grainIntensity) }}
        >
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <filter id="grain-noise">
              <feTurbulence
                type="fractalNoise"
                baseFrequency="0.85"
                numOctaves="3"
                stitchTiles="stitch"
              />
              <feColorMatrix type="saturate" values="0" />
            </filter>
            <rect width="100%" height="100%" filter="url(#grain-noise)" />
          </svg>
        </div>
      )}

      {/* Anamorphic 2.39:1 Cinema Letterbox Bars */}
      {filmSettings.anamorphicBars && (
        <>
          <div className="absolute top-0 left-0 right-0 h-7 sm:h-10 bg-black/95 z-10 pointer-events-none border-b border-white/10" />
          <div className="absolute bottom-0 left-0 right-0 h-7 sm:h-10 bg-black/95 z-10 pointer-events-none border-t border-white/10" />
        </>
      )}

      {/* Top Header Bar: Mountain View Title, Scene Switcher & Film Settings */}
      <div className="relative z-10 flex items-center justify-between flex-wrap gap-3">
        {/* Active Scene Title */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-black/40 backdrop-blur-md border border-white/20 text-emerald-400 shadow-md">
            <Mountain className="w-5 h-5 text-emerald-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-white text-base sm:text-lg font-black tracking-tight drop-shadow-md">
                {activeScene.name}
              </h3>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-white/20 backdrop-blur-md text-white border border-white/20">
                35mm Cinema
              </span>
            </div>
            <p className="text-xs text-white/80 font-medium drop-shadow-sm max-w-sm truncate">
              {activeScene.subtitle}
            </p>
          </div>
        </div>

        {/* Action Controls: Zen Mountain View Fullscreen Toggle */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleZenMode}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white border border-white/30 text-xs font-bold backdrop-blur-md transition-all cursor-pointer shadow-sm"
            title={
              isZenMode
                ? "Exit Zen Mountain View"
                : "Enjoy Fullscreen Mountain View with serene ambience"
            }
          >
            {isZenMode ? (
              <>
                <Minimize2 className="w-3.5 h-3.5" />
                <span>Exit Zen View</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-emerald-300" />
                <span>🏔️ Enjoy Mountain View</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container Content (Clock, Dose Info, Controls) */}
      <div className="relative z-10 flex flex-col justify-center my-auto">
        {children}
      </div>

      {/* Zen Mode Footer Notice */}
      {isZenMode && (
        <div className="relative z-10 flex items-center justify-between text-xs text-white/80 pt-4 border-t border-white/15">
          <div className="flex items-center gap-2">
            <Mountain className="w-4 h-4 text-emerald-400" />
            <span>MedTake Alpine Zen Mode • Sit back and enjoy the mountain view</span>
          </div>
          <button
            onClick={onToggleZenMode}
            className="px-4 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold transition-all cursor-pointer backdrop-blur-md"
          >
            Close Fullscreen
          </button>
        </div>
      )}
    </div>
  );
};
