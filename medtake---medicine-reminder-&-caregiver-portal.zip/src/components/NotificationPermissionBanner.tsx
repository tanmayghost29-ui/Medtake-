import React, { useState, useEffect } from "react";
import { Bell, Volume2, ShieldCheck, CheckCircle2, AlertCircle } from "lucide-react";
import { soundEngine } from "../utils/audio";

interface NotificationPermissionBannerProps {
  onPermissionResolved?: (granted: boolean) => void;
}

export const NotificationPermissionBanner: React.FC<NotificationPermissionBannerProps> = ({
  onPermissionResolved,
}) => {
  const [permissionState, setPermissionState] = useState<NotificationPermission>("default");
  const [isDismissed, setIsDismissed] = useState(false);
  const [isRequesting, setIsRequesting] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      setPermissionState(Notification.permission);
    }
  }, []);

  // If permissions are already granted or dismissed, hide the banner
  if (isDismissed || permissionState === "granted") {
    if (showSuccessToast) {
      return (
        <div className="bg-emerald-600 text-white px-4 py-2.5 rounded-2xl shadow-md flex items-center justify-between text-xs sm:text-sm font-semibold mb-4 animate-in fade-in duration-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
            <span>Voice & Dose Alerts Enabled! You will receive timely reminders.</span>
          </div>
          <button
            onClick={() => setShowSuccessToast(false)}
            className="text-emerald-100 hover:text-white px-2 py-0.5"
          >
            ✕
          </button>
        </div>
      );
    }
    return null;
  }

  const handleRequestPermission = async () => {
    if (typeof window === "undefined" || !("Notification" in window)) {
      return;
    }

    try {
      setIsRequesting(true);
      // Unlock Web Audio context on the user tap
      soundEngine.unlockContext();

      const result = await Notification.requestPermission();
      setPermissionState(result);

      if (result === "granted") {
        // Play pleasant 1-second confirmation chime
        soundEngine.playConfirmationChime();
        setShowSuccessToast(true);
        setTimeout(() => setShowSuccessToast(false), 4500);
        setIsDismissed(true);
        if (onPermissionResolved) onPermissionResolved(true);
      } else {
        if (onPermissionResolved) onPermissionResolved(false);
      }
    } catch (err) {
      console.warn("Notification request failed:", err);
    } finally {
      setIsRequesting(false);
    }
  };

  // If permission is explicitly denied
  if (permissionState === "denied") {
    return (
      <div className="bg-amber-50 border border-amber-200 text-amber-900 px-4 py-3 rounded-2xl shadow-xs mb-4 flex items-center justify-between gap-3 text-xs sm:text-sm">
        <div className="flex items-center gap-2.5">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
          <span>
            Notifications are blocked in your browser settings. Please enable them to receive medicine voice alerts.
          </span>
        </div>
        <button
          onClick={() => setIsDismissed(true)}
          className="text-amber-700 hover:text-amber-900 text-xs font-bold px-2 py-1 rounded-lg hover:bg-amber-100 shrink-0 cursor-pointer"
        >
          Dismiss
        </button>
      </div>
    );
  }

  // Default / Prompt state banner
  return (
    <div
      onClick={handleRequestPermission}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleRequestPermission();
        }
      }}
      className="bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 text-white p-3.5 sm:p-4 rounded-2xl shadow-md mb-4 flex flex-col sm:flex-row items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2 duration-300 cursor-pointer hover:brightness-105 active:scale-[0.99] transition-all select-none border border-white/20"
      title="Tap to Enable Real-Time Voice & Dose Alerts"
    >
      <div className="flex items-center gap-3 w-full sm:w-auto">
        <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/30 shadow-2xs">
          <Bell className="w-5 h-5 text-white animate-bounce" />
        </div>
        <div className="flex-1">
          <h4 className="font-bold text-sm sm:text-base flex items-center gap-1.5 leading-snug">
            <span>🔔 Tap to Enable Real-Time Voice & Dose Alerts</span>
          </h4>
          <p className="text-white/90 text-xs mt-0.5">
            Receive fullscreen audio alarms and multilingual spoken medicine instructions when doses are due.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
        <div className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white text-blue-700 font-bold text-xs sm:text-sm shadow-sm flex items-center justify-center gap-2 pointer-events-none">
          <Volume2 className="w-4 h-4 text-blue-600" />
          <span>{isRequesting ? "Enabling..." : "Enable Alerts"}</span>
        </div>
      </div>
    </div>
  );
};
