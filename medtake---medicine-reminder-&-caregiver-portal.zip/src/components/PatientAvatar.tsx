import React, { useState } from "react";
import { User } from "lucide-react";

interface PatientAvatarProps {
  name: string;
  avatarUrl?: string | null;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  showBorder?: boolean;
}

export const PatientAvatar: React.FC<PatientAvatarProps> = ({
  name,
  avatarUrl,
  size = "md",
  className = "",
  showBorder = true,
}) => {
  const [hasError, setHasError] = useState(false);

  // Size mappings
  const sizeClasses = {
    xs: "w-6 h-6 text-xs",
    sm: "w-8 h-8 text-xs",
    md: "w-11 h-11 text-sm",
    lg: "w-14 h-14 text-base",
    xl: "w-20 h-20 text-xl",
  };

  const initial = name ? name.trim().charAt(0).toUpperCase() : "?";

  // Deterministic pastel color palette based on patient name
  const getBackgroundColor = (str: string) => {
    const colors = [
      "bg-emerald-100 text-emerald-800 border-emerald-300",
      "bg-rose-100 text-rose-800 border-rose-300",
      "bg-amber-100 text-amber-800 border-amber-300",
      "bg-teal-100 text-teal-800 border-teal-300",
      "bg-sky-100 text-sky-800 border-sky-300",
      "bg-purple-100 text-purple-800 border-purple-300",
      "bg-indigo-100 text-indigo-800 border-indigo-300",
    ];
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const index = Math.abs(hash) % colors.length;
    return colors[index];
  };

  const colorClass = getBackgroundColor(name || "Patient");

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 rounded-2xl overflow-hidden shadow-2xs select-none ${
        sizeClasses[size]
      } ${showBorder ? "border-2 border-white ring-1 ring-slate-200/60" : ""} ${className}`}
    >
      {avatarUrl && !hasError ? (
        <img
          src={avatarUrl}
          alt={name}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onError={() => setHasError(true)}
        />
      ) : (
        <div
          className={`w-full h-full flex items-center justify-center font-black ${colorClass}`}
        >
          {initial || <User className="w-1/2 h-1/2" />}
        </div>
      )}
    </div>
  );
};
