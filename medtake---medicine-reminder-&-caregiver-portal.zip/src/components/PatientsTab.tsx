import React, { useState } from "react";
import { Patient, Medicine } from "../types";
import { LANGUAGE_LIST, LANGUAGES, formatVoiceMessage } from "../constants/languages";
import { soundEngine } from "../utils/audio";
import { PatientAvatar } from "./PatientAvatar";
import { AvatarPicker } from "./AvatarPicker";
import { normalizePhoneNumber, createSmsIntentUrl, createWhatsAppUrl, createPhoneCallUrl } from "../utils/storage";
import { UserPlus, User, Trash2, Volume2, Phone, Stethoscope, Building2, AlertCircle, ChevronDown, ChevronUp, Pill, Camera, Smartphone, MessageSquare, PhoneCall } from "lucide-react";

interface PatientsTabProps {
  patients: Record<string, Patient>;
  medicines: Medicine[];
  onAddPatient: (patient: Patient) => void;
  onUpdatePatient?: (patient: Patient) => void;
  onUpdatePatientAvatar?: (name: string, avatarUrl: string | null) => void;
  onDeletePatient: (name: string) => void;
}

export const PatientsTab: React.FC<PatientsTabProps> = ({
  patients,
  medicines,
  onAddPatient,
  onUpdatePatient,
  onUpdatePatientAvatar,
  onDeletePatient,
}) => {
  const [name, setName] = useState("");
  const [lang, setLang] = useState("English");
  const [disease, setDisease] = useState("");
  const [doctor, setDoctor] = useState("");
  const [pharmacy, setPharmacy] = useState("");
  const [guardianPhone, setGuardianPhone] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expandedPatient, setExpandedPatient] = useState<string | null>(null);
  const [editingAvatarFor, setEditingAvatarFor] = useState<string | null>(null);
  const [editingPhoneFor, setEditingPhoneFor] = useState<string | null>(null);
  const [editingPhoneVal, setEditingPhoneVal] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError("Patient name is required.");
      return;
    }
    if (patients[trimmed]) {
      setError("A patient with this name already exists.");
      return;
    }

    const cleanPhone = normalizePhoneNumber(guardianPhone);

    onAddPatient({
      name: trimmed,
      lang,
      disease: disease.trim(),
      doctor: doctor.trim(),
      pharmacy: pharmacy.trim(),
      guardian_phone: cleanPhone,
      avatar: selectedAvatar,
    });

    // Reset form
    setName("");
    setDisease("");
    setDoctor("");
    setPharmacy("");
    setGuardianPhone("");
    setSelectedAvatar(null);
    setError(null);
  };

  const handleTestVoice = (patientName: string, langName: string) => {
    const sample = formatVoiceMessage(langName, patientName || "Patient", "Medicine", 1);
    soundEngine.speak(sample.text, sample.code);
  };

  const patientEntries = Object.entries(patients);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header Info */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>🧑‍⚕️</span> Patient & Family Profiles
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Configure patient language for spoken voice alerts in their native mother tongue.
          </p>
        </div>
        <div className="text-xs font-semibold px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 w-fit">
          {patientEntries.length} registered patient{patientEntries.length !== 1 ? "s" : ""}
        </div>
      </div>

      {/* Form: Add Patient */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-emerald-100 shadow-sm space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl">
            <UserPlus className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-900">Add a New Patient</h3>
            <p className="text-xs text-slate-500">
              Each patient has their own alarm speech voice and guardian contact.
            </p>
          </div>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-50 text-red-700 text-sm rounded-xl border border-red-200">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Patient Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Patient Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Kamala Devi"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-sm font-medium"
              />
            </div>

            {/* Reminder Language */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Reminder Language <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => handleTestVoice(name || "Patient", lang)}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                  title="Listen to sample spoken reminder"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Preview Voice</span>
                </button>
              </div>
              <select
                value={lang}
                onChange={(e) => setLang(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-sm font-medium bg-white"
              >
                {LANGUAGE_LIST.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>

            {/* Condition / Disease */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Condition / Disease
              </label>
              <input
                type="text"
                value={disease}
                onChange={(e) => setDisease(e.target.value)}
                placeholder="e.g. Type 2 Diabetes, Hypertension"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-sm font-medium"
              />
            </div>

            {/* Doctor */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Attending Doctor
              </label>
              <input
                type="text"
                value={doctor}
                onChange={(e) => setDoctor(e.target.value)}
                placeholder="e.g. Dr. Arvind Rao, Manipal"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-sm font-medium"
              />
            </div>

            {/* Pharmacy */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Pharmacy / Chemist
              </label>
              <input
                type="text"
                value={pharmacy}
                onChange={(e) => setPharmacy(e.target.value)}
                placeholder="e.g. Apollo Pharmacy, Indiranagar"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-sm font-medium"
              />
            </div>

            {/* Guardian Phone */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Guardian Phone (SMS alerts)
              </label>
              <input
                type="text"
                value={guardianPhone}
                onChange={(e) => setGuardianPhone(e.target.value)}
                onBlur={() => {
                  if (guardianPhone.trim()) {
                    setGuardianPhone(normalizePhoneNumber(guardianPhone));
                  }
                }}
                placeholder="+91 98XXXXXXXX"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-sm font-mono"
              />
            </div>
          </div>

          {/* Avatar / Profile Photo Selector */}
          <div className="pt-2 border-t border-slate-100">
            <AvatarPicker
              patientName={name}
              selectedAvatar={selectedAvatar}
              onSelectAvatar={setSelectedAvatar}
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
            >
              Save Patient Profile
            </button>
          </div>
        </form>
      </div>

      {/* Patient List */}
      <div className="space-y-4">
        <h3 className="font-bold text-base text-slate-800">
          Saved Patients ({patientEntries.length})
        </h3>

        {patientEntries.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-dashed border-slate-300 text-center text-slate-500 space-y-2">
            <User className="w-8 h-8 mx-auto text-slate-300" />
            <p className="font-medium text-sm">No patients added yet.</p>
            <p className="text-xs">Use the form above to add your first patient profile.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {patientEntries.map(([pName, p]) => {
              const isExpanded = expandedPatient === pName;
              const isEditingAvatar = editingAvatarFor === pName;
              const patientMeds = medicines.filter((m) => m.patient === pName);

              return (
                <div
                  key={pName}
                  className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden transition-all"
                >
                  {/* Card Header with PatientAvatar */}
                  <div
                    onClick={() => setExpandedPatient(isExpanded ? null : pName)}
                    className="p-5 flex items-center justify-between cursor-pointer hover:bg-slate-50/70 transition-colors"
                  >
                    <div className="flex items-center gap-3.5">
                      <PatientAvatar
                        name={pName}
                        avatarUrl={p.avatar}
                        size="md"
                      />
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-extrabold text-base text-slate-900">
                            {pName}
                          </h4>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                            {p.lang}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {p.disease || "No condition specified"} • {patientMeds.length} scheduled medicine(s)
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleTestVoice(pName, p.lang);
                        }}
                        className="p-2 rounded-lg text-emerald-600 hover:bg-emerald-50 transition-colors"
                        title="Hear spoken alarm in their language"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        className="p-2 text-slate-400 hover:text-slate-600"
                      >
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="p-5 pt-0 border-t border-slate-100 bg-slate-50/50 space-y-4 text-xs">
                      {/* Avatar Edit Section */}
                      <div className="pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
                        <div className="flex items-center gap-3">
                          <PatientAvatar
                            name={pName}
                            avatarUrl={p.avatar}
                            size="lg"
                          />
                          <div>
                            <span className="font-bold text-slate-900 block text-xs">
                              {p.avatar ? "Custom Profile Avatar" : "Initials Avatar"}
                            </span>
                            <span className="text-[11px] text-slate-500">
                              Shown across Home dashboard, next dose countdown, and alarm alerts.
                            </span>
                          </div>
                        </div>

                        {onUpdatePatientAvatar && (
                          <button
                            type="button"
                            onClick={() => setEditingAvatarFor(isEditingAvatar ? null : pName)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-emerald-500 text-slate-700 hover:text-emerald-800 font-bold text-xs bg-slate-50 hover:bg-emerald-50/50 transition-colors cursor-pointer w-fit"
                          >
                            <Camera className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{isEditingAvatar ? "Done Editing" : "Change Photo / Avatar"}</span>
                          </button>
                        )}
                      </div>

                      {/* Inline Avatar Picker for existing patient */}
                      {isEditingAvatar && onUpdatePatientAvatar && (
                        <div className="p-4 bg-white rounded-xl border border-emerald-200 animate-in fade-in">
                          <AvatarPicker
                            patientName={pName}
                            selectedAvatar={p.avatar || null}
                            onSelectAvatar={(newUrl) => {
                              onUpdatePatientAvatar(pName, newUrl);
                            }}
                          />
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="bg-white p-3 rounded-xl border border-slate-200">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                            Condition
                          </span>
                          <span className="font-semibold text-slate-800 text-xs">
                            {p.disease || "N/A"}
                          </span>
                        </div>

                        <div className="bg-white p-3 rounded-xl border border-slate-200">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1 flex items-center gap-1">
                            <Stethoscope className="w-3 h-3 text-sky-500" /> Doctor
                          </span>
                          <span className="font-semibold text-slate-800 text-xs truncate block">
                            {p.doctor || "N/A"}
                          </span>
                        </div>

                        <div className="bg-white p-3 rounded-xl border border-slate-200">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1 flex items-center gap-1">
                            <Building2 className="w-3 h-3 text-indigo-500" /> Pharmacy
                          </span>
                          <span className="font-semibold text-slate-800 text-xs truncate block">
                            {p.pharmacy || "N/A"}
                          </span>
                        </div>

                        <div className="bg-white p-3 rounded-xl border border-slate-200">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1 flex items-center justify-between">
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3 text-emerald-600" /> Guardian Contact
                            </span>
                            {p.guardian_phone && (
                              <div className="flex items-center gap-1.5">
                                <a
                                  href={createPhoneCallUrl(p.guardian_phone)}
                                  className="text-[10px] text-amber-600 font-bold hover:underline flex items-center gap-0.5"
                                  title="Call guardian"
                                >
                                  <PhoneCall className="w-2.5 h-2.5" /> Call
                                </a>
                                <span className="text-slate-300">•</span>
                                <a
                                  href={createSmsIntentUrl(p.guardian_phone, `medtake check-in: Hello, sending health alert for ${pName}.`)}
                                  className="text-[10px] text-emerald-600 font-bold hover:underline"
                                  title="Open SMS"
                                >
                                  SMS
                                </a>
                                <span className="text-slate-300">•</span>
                                <a
                                  href={createWhatsAppUrl(p.guardian_phone, `medtake check-in: Hello, sending health alert for ${pName}.`)}
                                  target="_blank"
                                  rel="noreferrer noopener"
                                  className="text-[10px] text-emerald-700 font-bold hover:underline"
                                  title="Open WhatsApp"
                                >
                                  WA
                                </a>
                              </div>
                            )}
                          </span>

                          {editingPhoneFor === pName ? (
                            <div className="flex items-center gap-1.5 mt-1">
                              <input
                                type="tel"
                                value={editingPhoneVal}
                                onChange={(e) => setEditingPhoneVal(e.target.value)}
                                placeholder="+91 98XXXXXXXX"
                                className="flex-1 px-2 py-1 text-xs font-mono rounded border border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  if (onUpdatePatient) {
                                    onUpdatePatient({
                                      ...p,
                                      guardian_phone: normalizePhoneNumber(editingPhoneVal),
                                    });
                                  }
                                  setEditingPhoneFor(null);
                                }}
                                className="px-2 py-1 bg-emerald-600 text-white rounded text-[11px] font-bold hover:bg-emerald-700 cursor-pointer"
                              >
                                Save
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingPhoneFor(null)}
                                className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-[11px] font-medium hover:bg-slate-200 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-semibold text-slate-800 text-xs">
                                {p.guardian_phone || "Not set"}
                              </span>
                              {onUpdatePatient && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingPhoneFor(pName);
                                    setEditingPhoneVal(p.guardian_phone || "");
                                  }}
                                  className="text-[10px] font-bold text-emerald-700 hover:underline cursor-pointer"
                                >
                                  {p.guardian_phone ? "Edit" : "+ Add"}
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Native language quote sample */}
                      <div className="p-3 bg-emerald-50/80 rounded-xl border border-emerald-200 text-emerald-950 font-medium">
                        <span className="font-bold text-[11px] text-emerald-800 block mb-1">
                          Native Mother Tongue Sentence ({p.lang}):
                        </span>
                        <p className="italic text-xs">
                          {formatVoiceMessage(p.lang, pName, "[Medicine]", 1).text}
                        </p>
                      </div>

                      {/* Prescribed medicines list */}
                      {patientMeds.length > 0 && (
                        <div className="space-y-1.5">
                          <span className="font-bold text-slate-700 block">
                            Active Prescriptions ({patientMeds.length}):
                          </span>
                          <div className="flex flex-wrap gap-2">
                            {patientMeds.map((m) => (
                              <span
                                key={m.id}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 font-medium"
                              >
                                <Pill className="w-3 h-3 text-emerald-600" />
                                {m.name} ({m.time} • {m.meal_timing})
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="pt-2 flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            if (
                              window.confirm(
                                `Are you sure you want to delete ${pName} and all their medicines?`
                              )
                            ) {
                              onDeletePatient(pName);
                            }
                          }}
                          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-red-700 hover:bg-red-50 hover:border-red-200 border border-transparent font-bold transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete patient and their medicines</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
