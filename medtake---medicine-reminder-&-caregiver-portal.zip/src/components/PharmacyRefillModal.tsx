import React, { useState } from "react";
import { X, Building2, MessageSquare, PhoneCall, Check, ExternalLink, Pill, AlertTriangle } from "lucide-react";
import { Medicine, Patient } from "../types";
import { createWhatsAppUrl, createPhoneCallUrl } from "../utils/storage";

interface PharmacyRefillModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicine: Medicine | null;
  patient?: Patient | null;
}

export const PharmacyRefillModal: React.FC<PharmacyRefillModalProps> = ({
  isOpen,
  onClose,
  medicine,
  patient,
}) => {
  const [selectedPharmacy, setSelectedPharmacy] = useState<string>("apollo");
  const [customPharmacyPhone, setCustomPharmacyPhone] = useState<string>("");
  const [quantityStrips, setQuantityStrips] = useState<number>(1);
  const [deliveryNotes, setDeliveryNotes] = useState<string>("Urgent delivery to patient address.");

  if (!isOpen || !medicine) return null;

  const defaultPharmacies = [
    {
      id: "apollo",
      name: "Apollo Pharmacy",
      branch: patient?.pharmacy || "Apollo 24|7 Indiranagar Branch",
      phone: "+919845012345",
    },
    {
      id: "medplus",
      name: "MedPlus Healthcare",
      branch: "MedPlus Express Refill Counter",
      phone: "+919845067890",
    },
    {
      id: "custom",
      name: "Local Chemist / Neighbourhood Pharmacy",
      branch: "Your Neighborhood Medical Store",
      phone: customPharmacyPhone || "+919876543210",
    },
  ];

  const currentPharmacy = defaultPharmacies.find((p) => p.id === selectedPharmacy) || defaultPharmacies[0];
  const targetPhone = selectedPharmacy === "custom" ? customPharmacyPhone || "+919876543210" : currentPharmacy.phone;

  const orderMessage = `🏥 *MEDTAKE URGENT REFILL ORDER*
---------------------------------------
• *Patient*: ${patient?.name || medicine.patient}
• *Medicine*: ${medicine.name}
• *Dosage*: ${medicine.dose} tablet(s) (${medicine.meal_timing})
• *Current Remaining Stock*: ${medicine.stock} tablet(s) left
• *Quantity Required*: ${quantityStrips} Strip(s) / Box
• *Doctor*: ${patient?.doctor || "Attending Physician"}
• *Notes*: ${deliveryNotes}
---------------------------------------
Please confirm order availability and dispatch to registered address. Thank you!`;

  const waUrl = createWhatsAppUrl(targetPhone, orderMessage);
  const callUrl = createPhoneCallUrl(targetPhone);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in">
      <div
        className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-emerald-700 via-teal-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-400 text-slate-950 shadow-md">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">1-Click Pharmacy WhatsApp Refill</h3>
              <p className="text-xs text-emerald-200">
                Low-stock automatic reorder message generator
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-4 overflow-y-auto text-xs">
          {/* Medicine Refill Summary Card */}
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-amber-900 text-sm flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-amber-600" />
                {medicine.name}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-800 font-extrabold text-[10px]">
                Only {medicine.stock} tablet(s) left
              </span>
            </div>
            <p className="text-slate-600">
              For <strong>{patient?.name || medicine.patient}</strong> • Scheduled at{" "}
              <strong>{medicine.time}</strong> ({medicine.meal_timing})
            </p>
          </div>

          {/* Pharmacy Selection */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider">
              Select Pharmacy / Chemist Store:
            </label>
            <div className="grid grid-cols-1 gap-2">
              {defaultPharmacies.map((pharm) => (
                <label
                  key={pharm.id}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                    selectedPharmacy === pharm.id
                      ? "border-emerald-600 bg-emerald-50/70 shadow-xs"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="radio"
                      name="pharmacy"
                      value={pharm.id}
                      checked={selectedPharmacy === pharm.id}
                      onChange={() => setSelectedPharmacy(pharm.id)}
                      className="accent-emerald-600"
                    />
                    <div>
                      <span className="font-bold text-slate-900 block text-xs">{pharm.name}</span>
                      <span className="text-[11px] text-slate-500">{pharm.branch}</span>
                    </div>
                  </div>
                  <span className="font-mono text-[11px] text-emerald-800 font-semibold">
                    {pharm.id === "custom" && customPharmacyPhone ? customPharmacyPhone : pharm.phone}
                  </span>
                </label>
              ))}
            </div>

            {selectedPharmacy === "custom" && (
              <div className="mt-2 pt-2 border-t border-slate-100">
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  Enter Local Chemist WhatsApp / Phone Number:
                </label>
                <input
                  type="tel"
                  value={customPharmacyPhone}
                  onChange={(e) => setCustomPharmacyPhone(e.target.value)}
                  placeholder="e.g. +91 9876543210"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            )}
          </div>

          {/* Quantity & Order Notes */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-extrabold text-slate-700 mb-1">
                Refill Quantity (Strips/Boxes):
              </label>
              <input
                type="number"
                min="1"
                max="10"
                value={quantityStrips}
                onChange={(e) => setQuantityStrips(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 font-bold text-xs"
              />
            </div>
            <div>
              <label className="block text-[11px] font-extrabold text-slate-700 mb-1">
                Delivery Urgency:
              </label>
              <select
                value={deliveryNotes}
                onChange={(e) => setDeliveryNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium text-xs bg-white"
              >
                <option value="Urgent same-day delivery required.">Same-Day Urgent Delivery</option>
                <option value="Standard next-day delivery.">Next-Day Delivery</option>
                <option value="Patient will pick up from store counter.">Store Counter Pickup</option>
              </select>
            </div>
          </div>

          {/* Message Preview Box */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Pre-filled WhatsApp Message Preview:
            </span>
            <div className="p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-xl overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-32">
              {orderMessage}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2.5">
          <a
            href={callUrl}
            className="py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <PhoneCall className="w-3.5 h-3.5 text-amber-600" />
            <span>Call Store</span>
          </a>

          <a
            href={waUrl}
            target="_blank"
            rel="noreferrer noopener"
            onClick={onClose}
            className="flex-1 min-w-[200px] py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Send Refill Order via WhatsApp</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </a>
        </div>
      </div>
    </div>
  );
};
