import React, { useState, useEffect } from "react";
import {
  Sparkles,
  Smartphone,
  ArrowRight,
  ShieldCheck,
  Volume2,
  FileText,
  Clock,
  QrCode,
  ExternalLink,
  PhoneCall,
  Mail,
  Zap,
  CheckCircle2,
  Camera,
  Heart,
  ChevronRight,
  Globe2,
  Stethoscope,
  Pill,
  Download,
  AlertTriangle,
  Lock,
} from "lucide-react";
import { LANGUAGE_LIST, formatVoiceMessage } from "../constants/languages";
import { soundEngine } from "../utils/audio";

interface PublicLandingPageProps {
  onLaunchApp: () => void;
  onOpenInstallModal?: () => void;
  isLoggedIn?: boolean;
  username?: string;
}

export const PublicLandingPage: React.FC<PublicLandingPageProps> = ({
  onLaunchApp,
  onOpenInstallModal,
  isLoggedIn = false,
  username = "",
}) => {
  const [selectedDemoLang, setSelectedDemoLang] = useState<string>("Kannada (ಕನ್ನಡ)");
  const [isPlayingVoice, setIsPlayingVoice] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [installPromptEvent, setInstallPromptEvent] = useState<any>(null);

  const appLiveUrl = "https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app";
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(
    appLiveUrl
  )}&color=059669`;

  // Hardware clock sync
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Listen for beforeinstallprompt event
  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setInstallPromptEvent(e);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstall);
    return () => window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
  }, []);

  const handleInstallClick = () => {
    if (installPromptEvent) {
      installPromptEvent.prompt();
      installPromptEvent.userChoice.then(() => setInstallPromptEvent(null));
    } else if (onOpenInstallModal) {
      onOpenInstallModal();
    } else {
      window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
    }
  };

  const handlePlayVoiceSample = (lang: string) => {
    setSelectedDemoLang(lang);
    setIsPlayingVoice(true);
    const msg = formatVoiceMessage(lang, "Kamala Devi", "Metformin 500mg", 1);
    soundEngine.speak(msg.text, msg.code);
    setTimeout(() => setIsPlayingVoice(false), 3000);
  };

  const featuredLanguages = [
    "Kannada (ಕನ್ನಡ)",
    "Hindi (हिन्दी)",
    "Tamil (தமிழ்)",
    "Telugu (తెలుగు)",
    "Malayalam (മലയാളം)",
    "Marathi (मराठी)",
    "Bengali (বাংলা)",
    "Gujarati (ગુજરાતી)",
    "Punjabi (ਪੰਜਾਬੀ)",
    "English",
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-slate-950/85 backdrop-blur-md border-b border-emerald-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <svg
              width="40"
              height="40"
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="drop-shadow-md shrink-0"
            >
              <rect width="100" height="100" rx="24" fill="#059669" />
              <rect x="42" y="14" width="16" height="6" rx="3" fill="#FFFFFF" />
              <circle cx="50" cy="54" r="30" stroke="#FFFFFF" strokeWidth="7" fill="none" />
              <line x1="50" y1="54" x2="50" y2="34" stroke="#FBBF24" strokeWidth="6" strokeLinecap="round" />
              <line x1="50" y1="54" x2="68" y2="65" stroke="#FBBF24" strokeWidth="6" strokeLinecap="round" />
              <g transform="translate(62,60) rotate(35)">
                <rect x="0" y="0" width="18" height="30" rx="9" fill="#F59E0B" stroke="#FFFFFF" strokeWidth="4" />
                <line x1="0" y1="15" x2="18" y2="15" stroke="#FFFFFF" strokeWidth="3" />
              </g>
            </svg>
            <div className="flex flex-col">
              <span className="text-2xl font-black text-emerald-400 tracking-tight leading-none">
                med<span className="text-white">take</span>
              </span>
              <span className="text-[10px] text-emerald-300 font-semibold tracking-wider uppercase mt-0.5">
                Caregiver Telehealth Suite
              </span>
            </div>
          </div>

          {/* Quick Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-300">
            <a href="#features" className="hover:text-emerald-400 transition-colors">
              Features
            </a>
            <a href="#voice-alerts" className="hover:text-emerald-400 transition-colors">
              22 Languages
            </a>
            <a href="#vision-ocr" className="hover:text-emerald-400 transition-colors">
              Gemini Vision OCR
            </a>
            <a href="#guardian-sos" className="hover:text-emerald-400 transition-colors">
              Guardian SOS Watchdog
            </a>
            <a href="#doctor-reports" className="hover:text-emerald-400 transition-colors">
              Clinical Reports
            </a>
            <a href="#developer" className="hover:text-emerald-400 transition-colors">
              Helpline & Support
            </a>
          </nav>

          {/* Action CTAs */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={handleInstallClick}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-emerald-800/80 text-emerald-300 text-xs font-bold transition-all cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>📲 Install App</span>
            </button>

            <button
              onClick={onLaunchApp}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs sm:text-sm font-extrabold shadow-lg shadow-emerald-950/60 transition-all cursor-pointer"
            >
              <span>{isLoggedIn ? `Go to Dashboard (${username})` : "Launch App / Sign In"}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 sm:pt-20 sm:pb-28">
        {/* Glow backdrop */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Hero Copy */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/90 border border-emerald-700/80 text-emerald-300 text-xs font-bold shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Smart Medicine Reminder & Caregiver Emergency Suite</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.1]">
                Never miss a dose. <br className="hidden sm:inline" />
                <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 bg-clip-text text-transparent">
                  Precision Caregiver Alarms & Family Telehealth.
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto lg:mx-0 font-normal">
                MedTake turns medication schedules into keep-awake fullscreen clock alarms with spoken native voice alerts in{" "}
                <strong className="text-emerald-300 font-bold underline decoration-emerald-500">all 22 official Indian languages</strong>, Gemini Vision prescription OCR scanning, and automated emergency SMS & WhatsApp dispatch to family guardians.
              </p>

              {/* Hero Action Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={onLaunchApp}
                  className="px-6 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-sm sm:text-base shadow-xl shadow-emerald-950/80 flex items-center gap-2.5 transition-all cursor-pointer"
                >
                  <span>{isLoggedIn ? "Open Patient Dashboard" : "Launch App / Sign In"}</span>
                  <ArrowRight className="w-5 h-5" />
                </button>

                <button
                  onClick={handleInstallClick}
                  className="px-5 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-emerald-700/80 text-emerald-300 font-bold text-sm sm:text-base shadow-lg flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Smartphone className="w-5 h-5" />
                  <span>📲 Install Mobile App (PWA)</span>
                </button>

                <a
                  href="#voice-alerts"
                  className="px-4 py-4 rounded-2xl bg-transparent hover:bg-white/5 text-slate-300 hover:text-white font-semibold text-sm flex items-center gap-1.5 transition-colors"
                >
                  <Volume2 className="w-4 h-4 text-amber-400" />
                  <span>Hear Spoken Voice</span>
                </a>
              </div>

              {/* Clinical Trust Points */}
              <div className="pt-6 grid grid-cols-2 sm:grid-cols-3 gap-4 border-t border-slate-800/80 text-left">
                <div>
                  <strong className="block text-white font-extrabold text-sm sm:text-base">
                    🇮🇳 22 Languages
                  </strong>
                  <span className="text-xs text-slate-400 leading-tight">
                    Spoken native voice alerts
                  </span>
                </div>
                <div>
                  <strong className="block text-white font-extrabold text-sm sm:text-base">
                    ⚡ 0-Click SOS Watchdog
                  </strong>
                  <span className="text-xs text-slate-400 leading-tight">
                    Dual SMS & WhatsApp alerts
                  </span>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <strong className="block text-white font-extrabold text-sm sm:text-base">
                    📄 Doctor PDF Reports
                  </strong>
                  <span className="text-xs text-slate-400 leading-tight">
                    Audit compliance streaks
                  </span>
                </div>
              </div>
            </div>

            {/* Right Hero Live Interactive Mockup */}
            <div className="lg:col-span-5">
              <div className="relative mx-auto max-w-md rounded-3xl bg-gradient-to-b from-[#0F1E17] to-[#08120D] p-5 sm:p-6 border border-emerald-800/80 shadow-2xl shadow-emerald-950/90 space-y-5">
                {/* Simulated Bedside Clock Display */}
                <div className="p-4 rounded-2xl bg-black/60 border border-emerald-900/60 text-center space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                    Live Bedside Chronometer
                  </span>
                  <div className="font-mono text-3xl sm:text-4xl font-black text-amber-300 tracking-wider">
                    {currentTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Keep-Awake Active • Synchronized Local Hardware Clock
                  </div>
                </div>

                {/* Simulated Dose Card */}
                <div className="p-4 rounded-2xl bg-[#14261D] border border-emerald-700/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-full bg-emerald-900/80 text-emerald-300 font-bold text-[11px] border border-emerald-600/60">
                      Scheduled Dose: Kamala Devi
                    </span>
                    <span className="font-mono text-xs font-bold text-amber-300">
                      11:21 AM • After Food
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-2xl">
                      💊
                    </div>
                    <div>
                      <h4 className="font-extrabold text-white text-base">Metformin 500mg</h4>
                      <p className="text-xs text-slate-300">Dose: 1 tablet • Stock left: 22</p>
                    </div>
                  </div>

                  {/* Native Spoken Voice Trigger */}
                  <div className="pt-2 border-t border-emerald-900/60 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => handlePlayVoiceSample(selectedDemoLang)}
                      className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>{isPlayingVoice ? "Playing Voice..." : `Hear in ${selectedDemoLang.split(" ")[0]}`}</span>
                    </button>

                    <button
                      type="button"
                      onClick={onLaunchApp}
                      className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold text-xs border border-slate-700 cursor-pointer"
                    >
                      Take Dose
                    </button>
                  </div>
                </div>

                {/* Guardian SOS Watchdog Status */}
                <div className="p-3.5 rounded-2xl bg-[#091510] border border-emerald-900/60 flex items-center gap-3 text-xs">
                  <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                  <div className="flex-1">
                    <strong className="text-white block font-bold">Guardian SOS Watchdog Active</strong>
                    <span className="text-[11px] text-slate-400">
                      Missed doses automatically dispatch dual text alerts to caregiver phone.
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase 1: 22 Indian Language Voice Alerts */}
      <section id="voice-alerts" className="py-16 sm:py-24 bg-[#08120D] border-t border-emerald-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
              Universal Indian Accessibility
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Spoken Native Voice Alarms in 22 Official Indian Languages
            </h2>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Illiterate seniors and visually impaired patients cannot read tiny pill box text. MedTake speaks medication instructions aloud in their mother tongue with warm, natural clarity.
            </p>
          </div>

          {/* Interactive Voice Sampler */}
          <div className="bg-[#0D1C15] rounded-3xl p-6 sm:p-8 border border-emerald-800/60 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-white text-lg">Interactive Audio Language Sampler</h3>
                <p className="text-xs text-slate-400">
                  Select any Indian language to hear the real synthesised medication alert.
                </p>
              </div>

              <button
                type="button"
                onClick={() => handlePlayVoiceSample(selectedDemoLang)}
                className="py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer w-fit"
              >
                <Volume2 className="w-4 h-4" />
                <span>Play Selected Language Sample</span>
              </button>
            </div>

            {/* Language Selector Chips */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
              {featuredLanguages.map((lang) => {
                const isSelected = selectedDemoLang === lang;
                return (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => handlePlayVoiceSample(lang)}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all text-left flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? "bg-emerald-600 text-white shadow-md border border-emerald-400"
                        : "bg-[#08120D] text-slate-300 hover:bg-emerald-950/60 border border-emerald-900/60"
                    }`}
                  >
                    <span className="truncate">{lang}</span>
                    <Volume2 className={`w-3.5 h-3.5 shrink-0 ml-1.5 ${isSelected ? "text-white" : "text-emerald-500"}`} />
                  </button>
                );
              })}
            </div>

            {/* Active Voice Script Display */}
            <div className="p-4 rounded-2xl bg-black/40 border border-emerald-900/60 font-mono text-xs sm:text-sm text-emerald-300">
              <span className="text-slate-400 text-xs block mb-1">
                Audio transcript for {selectedDemoLang}:
              </span>
              "{formatVoiceMessage(selectedDemoLang, "Kamala Devi", "Metformin 500mg", 1).text}"
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase 2 & 3: Gemini Vision OCR + Guardian Watchdog */}
      <section id="features" className="py-16 sm:py-24 bg-slate-950 border-t border-emerald-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-black uppercase tracking-wider text-amber-400">
              Clinical & Engineering Highlights
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Engineered for Real-World Caregiver Reliability
            </h2>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              From camera OCR to background watchdog daemons, every feature is built to protect patients and keep guardians informed.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1: Gemini Vision Prescription OCR */}
            <div id="vision-ocr" className="bg-[#0B1712] rounded-3xl p-6 sm:p-7 border border-emerald-900/60 space-y-4 hover:border-emerald-600 transition-colors">
              <div className="w-12 h-12 rounded-2xl bg-emerald-900/60 border border-emerald-600/80 flex items-center justify-center text-emerald-400">
                <Camera className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-xl text-white">Gemini Vision Prescription OCR</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                Caregivers don't need to manually type complex medical names. Simply photograph a doctor's handwriting, printed prescription, or tablet blister foil. MedTake's Gemini AI parses dosage timing, frequency, and stock count automatically.
              </p>
              <div className="pt-2 text-xs font-mono text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Instant automated schedule extraction</span>
              </div>
            </div>

            {/* Feature 2: Emergency Guardian SOS Watchdog */}
            <div id="guardian-sos" className="bg-[#0B1712] rounded-3xl p-6 sm:p-7 border border-emerald-900/60 space-y-4 hover:border-emerald-600 transition-colors">
              <div className="w-12 h-12 rounded-2xl bg-amber-900/60 border border-amber-600/80 flex items-center justify-center text-amber-400">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-xl text-white">Emergency SOS Watchdog</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                If an elderly patient misses their morning cardiac or diabetes tablet by more than 15 minutes, or presses the Emergency SOS alarm, the server watchdog immediately dispatches dual SMS and WhatsApp alerts to the configured family guardian.
              </p>
              <div className="pt-2 text-xs font-mono text-amber-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                <span>Dual SMS + WhatsApp notification relay</span>
              </div>
            </div>

            {/* Feature 3: Doctor PDF Adherence Reports */}
            <div id="doctor-reports" className="bg-[#0B1712] rounded-3xl p-6 sm:p-7 border border-emerald-900/60 space-y-4 hover:border-emerald-600 transition-colors">
              <div className="w-12 h-12 rounded-2xl bg-sky-900/60 border border-sky-600/80 flex items-center justify-center text-sky-400">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-xl text-white">Doctor Clinical Adherence Reports</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                Export comprehensive compliance summaries with adherence scores (A+ 95%+), dose timestamp audits, medication schedules, and clinical streak counts. 1-click printable PDF for doctor reviews and hospital follow-ups.
              </p>
              <div className="pt-2 text-xs font-mono text-sky-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-sky-400" />
                <span>Printable hospital-grade compliance audit</span>
              </div>
            </div>

            {/* Feature 4: Keep-Awake Bedside Clock */}
            <div className="bg-[#0B1712] rounded-3xl p-6 sm:p-7 border border-emerald-900/60 space-y-4 hover:border-emerald-600 transition-colors">
              <div className="w-12 h-12 rounded-2xl bg-indigo-900/60 border border-indigo-600/80 flex items-center justify-center text-indigo-400">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-xl text-white">Keep-Awake Bedside Clock</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                Using the Screen Wake Lock API, older phones or tablets mounted on nightstands remain active as high-contrast bedside clocks. Synchronized chronometers, daylight dimming, and alpine mountain scenery prevent night disorientation.
              </p>
              <div className="pt-2 text-xs font-mono text-indigo-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                <span>Zero screen sleep during night alarms</span>
              </div>
            </div>

            {/* Feature 5: Offline IndexedDB Vault */}
            <div className="bg-[#0B1712] rounded-3xl p-6 sm:p-7 border border-emerald-900/60 space-y-4 hover:border-emerald-600 transition-colors">
              <div className="w-12 h-12 rounded-2xl bg-teal-900/60 border border-teal-600/80 flex items-center justify-center text-teal-400">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-xl text-white">Offline-First Resilience</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                Cellular outages never stop medication alarms. MedTake runs fully offline via Service Workers and IndexedDB. Doses recorded without internet automatically queue and sync to the cloud database the moment connection returns.
              </p>
              <div className="pt-2 text-xs font-mono text-teal-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-teal-400" />
                <span>Uninterrupted offline alarm firing</span>
              </div>
            </div>

            {/* Feature 6: Isolated Multi-User Privacy */}
            <div className="bg-[#0B1712] rounded-3xl p-6 sm:p-7 border border-emerald-900/60 space-y-4 hover:border-emerald-600 transition-colors">
              <div className="w-12 h-12 rounded-2xl bg-rose-900/60 border border-rose-600/80 flex items-center justify-center text-rose-400">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-xl text-white">Isolated Patient Privacy</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                Patient records, medical conditions, and prescriptions are strictly private to each registered user account. Multi-user isolation ensures no cross-profile data leakage between different families on shared tablet devices.
              </p>
              <div className="pt-2 text-xs font-mono text-rose-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-rose-400" />
                <span>Private end-user account workspaces</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live QR Code & PWA Mobile Installation Section */}
      <section className="py-16 sm:py-24 bg-[#08120D] border-t border-emerald-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-[#0F221A] via-[#091510] to-slate-950 rounded-3xl p-8 sm:p-12 border border-emerald-700/80 shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
              {/* QR Code Presentation */}
              <div className="lg:col-span-5 flex flex-col items-center text-center space-y-4">
                <div className="p-4 bg-white rounded-3xl shadow-2xl border-4 border-emerald-500/80 inline-block">
                  <img
                    src={qrCodeUrl}
                    alt="Scan to open and install MedTake on Mobile"
                    className="w-48 h-48 sm:w-56 sm:h-56 object-contain"
                  />
                </div>
                <div>
                  <span className="font-black text-white text-base block">Scan to Install on Mobile</span>
                  <span className="text-xs text-emerald-300 font-mono">
                    Point your phone camera to launch instantly
                  </span>
                </div>
              </div>

              {/* Install Guidance */}
              <div className="lg:col-span-7 space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-600 text-emerald-300 text-xs font-bold">
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Instant PWA Mobile Installation (Android & iOS)</span>
                </div>

                <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
                  Carry MedTake directly on your phone or bedside tablet.
                </h2>

                <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                  MedTake installs as a native mobile application without requiring an app store download. It runs in standalone fullscreen mode with hardware vibration and native exact alarms.
                </p>

                <div className="space-y-3 pt-1 text-xs sm:text-sm text-slate-300">
                  <div className="flex items-start gap-3">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-900 text-emerald-300 font-mono font-bold">
                      Android
                    </span>
                    <span>
                      Open in Google Chrome &rarr; tap the three dots (<strong className="text-white">⋮</strong>) &rarr; tap <strong className="text-emerald-400">"Install app"</strong> or <strong className="text-emerald-400">"Add to Home Screen"</strong>.
                    </span>
                  </div>

                  <div className="flex items-start gap-3">
                    <span className="px-2 py-0.5 rounded-md bg-amber-900 text-amber-300 font-mono font-bold">
                      iOS / iPhone
                    </span>
                    <span>
                      Open in Safari &rarr; tap the Share button (<strong className="text-white">⎙</strong>) &rarr; scroll down and tap <strong className="text-amber-300">"Add to Home Screen"</strong>.
                    </span>
                  </div>
                </div>

                <div className="pt-4 flex flex-wrap items-center gap-3">
                  <button
                    onClick={handleInstallClick}
                    className="py-3 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>Install App on This Device</span>
                  </button>

                  <button
                    onClick={onLaunchApp}
                    className="py-3 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-emerald-700 text-emerald-300 font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <span>Launch Web Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Official Developer Helpline & Support Section */}
      <section id="developer" className="py-16 sm:py-20 bg-slate-950 border-t border-emerald-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#0B1712] rounded-3xl p-6 sm:p-10 border border-emerald-800/60 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div className="space-y-3 max-w-2xl">
              <span className="text-xs font-black uppercase tracking-wider text-amber-400">
                Official Developer Hotline & Institutional Support
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-white">
                Tanmay TM (Architect & Lead Engineer)
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                For technical support, custom hospital EHR connectivity, telehealth integrations, or Android APK assistance, contact the developer hotline directly.
              </p>
              <div className="pt-2 flex flex-wrap items-center gap-3 text-xs font-mono">
                <span className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-white font-bold flex items-center gap-2">
                  <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                  +91 8088901642
                </span>
                <span className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-white font-bold flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-emerald-400" />
                  tanmayghost29@gmail.com
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row md:flex-col gap-3 shrink-0">
              <a
                href="tel:+918088901642"
                className="py-3 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Call Helpline Directly</span>
              </a>

              <a
                href={`https://wa.me/918088901642?text=${encodeURIComponent(
                  "Hello Tanmay, I am using the MedTake smart medicine reminder platform and need assistance."
                )}`}
                target="_blank"
                rel="noreferrer noopener"
                className="py-3 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <ExternalLink className="w-4 h-4" />
                <span>WhatsApp Developer</span>
              </a>

              <a
                href="mailto:tanmayghost29@gmail.com?subject=MedTake%20Inquiry"
                className="py-3 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-emerald-800 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition-all"
              >
                <Mail className="w-4 h-4 text-emerald-400" />
                <span>Email Developer</span>
              </a>
            </div>
          </div>

          {/* Proprietary Source Code Notice */}
          <div className="mt-6 p-4 rounded-2xl bg-[#070F0B] border border-emerald-950 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
            <Lock className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span>
              MedTake™ is proprietary clinical healthcare software engineered by Tanmay TM. Source code downloads are restricted to authorized deployments.
            </span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-10 bg-slate-950 border-t border-slate-900 text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <div className="font-bold text-slate-300">MedTake - Smart Medicine Reminder & Guardian SOS System</div>
            <div>© 2026 Tammy TM (Tanmay TM). All Rights Reserved.</div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-slate-400 font-medium">
            <button onClick={onLaunchApp} className="hover:text-emerald-400 cursor-pointer">
              Launch App
            </button>
            <span>·</span>
            <button onClick={handleInstallClick} className="hover:text-emerald-400 cursor-pointer">
              Install PWA
            </button>
            <span>·</span>
            <a href="mailto:tanmayghost29@gmail.com" className="hover:text-emerald-400">
              Support
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};
