import React, { useState } from "react";
import {
  Sparkles,
  Layers,
  Cpu,
  Smartphone,
  ShieldCheck,
  Zap,
  Mail,
  PhoneCall,
  QrCode,
  CheckCircle2,
  ExternalLink,
  Volume2,
  Clock,
  Radio,
  FileCode,
  Terminal,
  Activity,
  Heart,
  ChevronRight,
  Database,
  Eye,
} from "lucide-react";

interface ShowcaseTabProps {
  onNavigateToTab?: (tab: string) => void;
  developerEmail?: string;
  developerPhone?: string;
}

export const ShowcaseTab: React.FC<ShowcaseTabProps> = ({
  onNavigateToTab,
  developerEmail = "tanmayghost29@gmail.com",
  developerPhone = "+91 8088901642",
}) => {
  const [activeTabSection, setActiveTabSection] = useState<"architecture" | "highlights" | "mobile" | "developer">("architecture");

  const appLiveUrl = "https://ais-pre-bnspyquewcb6ftolfjx7b5-761733893464.asia-southeast1.run.app";
  // Clean SVG QR Code generator link for the live applet URL
  const qrCodeImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(
    appLiveUrl
  )}&color=059669`;

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      {/* Hero Showcase Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-950 to-slate-950 text-white p-6 sm:p-10 border border-emerald-500/30 shadow-2xl">
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>MedTake™ Enterprise Caregiver Suite v2.5</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight">
            Multilingual Telehealth Alarm System & Backend Emergency Watchdog
          </h1>

          <p className="text-sm sm:text-base text-emerald-100/90 leading-relaxed font-medium">
            Engineered for elderly patients across India with native spoken reminders in 22 official languages, 
            exact Android alarms with lock-screen wake locks, 100% offline-first IndexedDB resilience, 
            and automated guardian SMS + WhatsApp safety dispatchers.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            {onNavigateToTab && (
              <button
                onClick={() => onNavigateToTab("home")}
                className="py-3 px-5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 active:scale-95 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
              >
                <Activity className="w-4 h-4 text-slate-950" />
                <span>Open Live Patient Portal</span>
              </button>
            )}

            <a
              href={`mailto:${developerEmail}?subject=MedTake%20Architecture%20Inquiry`}
              className="py-3 px-5 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-bold text-xs sm:text-sm flex items-center gap-2 border border-white/20 transition-all"
            >
              <Mail className="w-4 h-4 text-emerald-400" />
              <span>Contact Architect</span>
            </a>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-200 overflow-x-auto no-scrollbar gap-2">
        <button
          onClick={() => setActiveTabSection("architecture")}
          className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTabSection === "architecture"
              ? "border-emerald-600 text-emerald-800"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>System Architecture & Dataflow</span>
        </button>

        <button
          onClick={() => setActiveTabSection("highlights")}
          className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTabSection === "highlights"
              ? "border-emerald-600 text-emerald-800"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Core Capabilities & Reliability</span>
        </button>

        <button
          onClick={() => setActiveTabSection("mobile")}
          className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTabSection === "mobile"
              ? "border-emerald-600 text-emerald-800"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <QrCode className="w-4 h-4" />
          <span>Live Mobile QR & PWA</span>
        </button>

        <button
          onClick={() => setActiveTabSection("developer")}
          className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTabSection === "developer"
              ? "border-emerald-600 text-emerald-800"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>Developer Helpline & Python Daemon</span>
        </button>
      </div>

      {/* SECTION 1: ARCHITECTURE DIAGRAM */}
      {activeTabSection === "architecture" && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-600" />
                <span>Multi-Tier High-Availability System Architecture</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Zero single-point-of-failure topology ensuring medicine alerts fire even if offline, asleep, or minimized.
              </p>
            </div>

            {/* Architecture Flow Chart Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              {/* Node 1: Client Front Tier */}
              <div className="p-5 rounded-2xl bg-gradient-to-b from-emerald-50 to-teal-50/50 border border-emerald-200 space-y-3">
                <div className="flex items-center gap-2 text-emerald-900 font-extrabold text-sm">
                  <Smartphone className="w-5 h-5 text-emerald-600" />
                  <span>1. Client & Hybrid App</span>
                </div>
                <ul className="space-y-2 text-slate-600 leading-relaxed">
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>React 19 + Tailwind CSS:</strong> High-contrast cinematic UI with bedside clock dial.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Capacitor Android:</strong> Native Exact Alarms via AlarmManager & high-priority channel.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>W3C Screen WakeLock:</strong> Display stays lit during nighttime alarm triggers.</span>
                  </li>
                </ul>
              </div>

              {/* Node 2: Multilingual Speech & Offline Engine */}
              <div className="p-5 rounded-2xl bg-gradient-to-b from-sky-50 to-indigo-50/50 border border-sky-200 space-y-3">
                <div className="flex items-center gap-2 text-sky-900 font-extrabold text-sm">
                  <Volume2 className="w-5 h-5 text-sky-600" />
                  <span>2. Voice & Storage Core</span>
                </div>
                <ul className="space-y-2 text-slate-600 leading-relaxed">
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                    <span><strong>22 Indian Languages:</strong> Natural speech voice alerts in Kannada, Hindi, Tamil, Telugu, etc.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                    <span><strong>IndexedDB Fallback:</strong> Dose history queues locally while offline and auto-syncs on reconnect.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                    <span><strong>Synthesized Oscillators:</strong> Gentle hospital chimes that bypass hardware silencer stubs.</span>
                  </li>
                </ul>
              </div>

              {/* Node 3: Backend Watchdog & Vision */}
              <div className="p-5 rounded-2xl bg-gradient-to-b from-amber-50 to-rose-50/50 border border-amber-200 space-y-3">
                <div className="flex items-center gap-2 text-amber-900 font-extrabold text-sm">
                  <Cpu className="w-5 h-5 text-amber-600" />
                  <span>3. Watchdog & AI Vision</span>
                </div>
                <ul className="space-y-2 text-slate-600 leading-relaxed">
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span><strong>Gemini 3.8 Flash:</strong> Prescription OCR extracts medicine, dosage, timing & food rules.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span><strong>24/7 Watchdog Daemon:</strong> Detects overdue doses (&gt;5m) and auto-escalates Emergency SOS.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span><strong>Dual Relay Dispatcher:</strong> Twilio Cellular SMS + WhatsApp CallMeBot simultaneous delivery.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Quick Flowchart ASCII Card */}
            <div className="p-4 rounded-2xl bg-slate-900 text-emerald-400 font-mono text-[11px] overflow-x-auto whitespace-pre leading-relaxed border border-slate-800">
{`[ Doctor Prescription / Blister Strip ] ---> [ Gemini 3.8 Flash Vision OCR ] ---> [ Auto-Populate Dosage & Time ]
                                                                                           |
                                                                                           v
[ Scheduled Hour ] ---> [ Android Exact Alarm / Screen Wake Lock ] ---> [ Multilingual Audio Spoken Alert ]
                                      |                                                    |
             +------------------------+----------------------------------------------------+
             | Dose Taken Confirmed                    | Overdue > 5 mins / Unanswered
             v                                         v
[ Local DB + Cloud History Sync ]            [ Backend Watchdog Daemon SOS Escalation ]
                                                       |
                                                       v
                                     [ Cellular SMS + WhatsApp Dual Dispatch to Guardian ]`}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: HIGHLIGHTS & CAPABILITIES */}
      {activeTabSection === "highlights" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in">
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
            </div>
            <h4 className="font-extrabold text-slate-900 text-base">100% Offline-First Execution</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              When an elderly patient has no WiFi or cellular data in rural homes, medicine alarms still trigger on time. 
              Dose taken events are securely logged to client-side IndexedDB and automatically synchronized when connectivity returns.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Eye className="w-5 h-5 text-amber-600" />
            </div>
            <h4 className="font-extrabold text-slate-900 text-base">Bedside Clock Mode & WakeLock</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Designed for nightstands. Prevents the mobile screen from locking or going dark during crucial alarm countdown windows, 
              ensuring immediate visual recognition of tablet name and dosage.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-sky-100 text-sky-800 flex items-center justify-center font-bold">
              <Volume2 className="w-5 h-5 text-sky-600" />
            </div>
            <h4 className="font-extrabold text-slate-900 text-base">Indian Mother Tongue Synthesis</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Elderly patients do not need to read small font English labels. The system vocalizes spoken medication reminders in 
              their native language (Kannada, Hindi, Bengali, Tamil, Telugu, Malayalam, Gujarati, Marathi, Punjabi, Odia, etc.).
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-800 flex items-center justify-center font-bold">
              <Zap className="w-5 h-5 text-rose-600" />
            </div>
            <h4 className="font-extrabold text-slate-900 text-base">Dynamic Guardian SOS Dispatcher</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              All alerts route dynamically to the guardian phone number configured in profile settings. Dual-channel dispatch guarantees 
              family members receive immediate updates on both SMS and WhatsApp without requiring user intervention.
            </p>
          </div>
        </div>
      )}

      {/* SECTION 3: LIVE MOBILE QR CODE & PWA */}
      {activeTabSection === "mobile" && (
        <div className="bg-white p-6 sm:p-10 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center gap-8 animate-in fade-in">
          <div className="p-4 bg-white rounded-3xl border-2 border-emerald-400 shadow-xl shrink-0 text-center">
            <img
              src={qrCodeImageUrl}
              alt="Scan to open MedTake on phone"
              className="w-56 h-56 mx-auto rounded-2xl"
            />
            <span className="text-[11px] font-mono font-bold text-emerald-800 mt-2 block">
              Scan with Smartphone Camera
            </span>
          </div>

          <div className="space-y-4 flex-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-black">
              <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
              <span>Instant PWA & APK Prototyping</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Test Live on Android or iOS Device
            </h3>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Scan the QR code with your phone to immediately launch MedTake in standalone PWA mode. 
              You can tap <strong>"Add to Home Screen"</strong> in your browser menu to experience fullscreen alarm wake locks and background local notification alarms.
            </p>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs space-y-1 font-mono text-slate-700">
              <div className="text-[11px] font-bold text-slate-400 uppercase">Live Shared URL:</div>
              <a
                href={appLiveUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="text-emerald-700 hover:underline break-all font-bold flex items-center gap-1"
              >
                <span>{appLiveUrl}</span>
                <ExternalLink className="w-3 h-3 shrink-0" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: DEVELOPER HELPLINE & PYTHON DAEMON */}
      {activeTabSection === "developer" && (
        <div className="space-y-6 animate-in fade-in">
          {/* Developer Contact Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-900 to-slate-950 text-white shadow-xl border border-emerald-400/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-2 max-w-xl">
              <span className="text-xs font-black uppercase tracking-wider text-amber-300">
                Official Developer Hotline & Architectural Support
              </span>
              <h3 className="text-2xl font-black text-white">
                Tanmay TM (Architect & Lead Engineer)
              </h3>
              <p className="text-xs text-emerald-200/90 leading-relaxed">
                Need customized Android APK compilation, hospital telemetry integration, or doctor EHR connectivity? Contact the developer hotline directly.
              </p>
              <div className="pt-2 flex flex-wrap items-center gap-3 text-xs font-mono">
                <span className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-white font-bold flex items-center gap-2">
                  <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                  {developerPhone}
                </span>
                <span className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-white font-bold flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-emerald-400" />
                  {developerEmail}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2.5 shrink-0 w-full sm:w-auto">
              <a
                href={`tel:${developerPhone.replace(/[^\d+]/g, "")}`}
                className="py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Call Helpline Directly</span>
              </a>

              <a
                href={`https://wa.me/918088901642?text=${encodeURIComponent(
                  "Hello Tanmay, I need assistance with the MedTake caregiver system."
                )}`}
                target="_blank"
                rel="noreferrer noopener"
                className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <ExternalLink className="w-4 h-4" />
                <span>WhatsApp Developer</span>
              </a>
            </div>
          </div>

          {/* Python Companion Daemon Overview */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-slate-900 text-amber-400 rounded-xl">
                <Terminal className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-base text-slate-900">Python Companion Engine (medtake_app.py)</h4>
                <p className="text-xs text-slate-500">
                  Command-line interface with Gemini Pro OCR, safe-keeping profile export, and 24/7 watchdog loop.
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 text-emerald-300 font-mono text-xs overflow-x-auto space-y-1.5 leading-relaxed">
              <div className="text-slate-400"># Run the 24/7 emergency watchdog monitor daemon:</div>
              <div className="text-amber-300 font-bold">$ python3 medtake_app.py --watchdog</div>
              <div className="text-slate-400 pt-2"># Trigger instant Emergency SOS to configured guardian:</div>
              <div className="text-amber-300 font-bold">$ python3 medtake_app.py --sos "Kamala Devi"</div>
              <div className="text-slate-400 pt-2"># Extract medicines from doctor prescription with Gemini Pro:</div>
              <div className="text-amber-300 font-bold">$ python3 medtake_app.py --analyze rx_photo.jpg</div>
              <div className="text-slate-400 pt-2"># Export complete patient profile backup:</div>
              <div className="text-amber-300 font-bold">$ python3 medtake_app.py --backup</div>
            </div>
          </div>
        </div>
      )}

      {/* Proprietary Architecture & Institutional Licensing Notice */}
      <div className="p-6 rounded-3xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-sm">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-extrabold text-sm sm:text-base text-slate-900">
              MedTake™ Caregiver Ecosystem & Telehealth Architecture
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Proprietary clinical healthcare software engineered by Tanmay TM. Source code and deployment assets are restricted to authorized institutional deployments.
            </p>
          </div>
        </div>

        <a
          href={`mailto:${developerEmail}?subject=MedTake%20Institutional%20Licensing%20Inquiry`}
          className="py-2.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0"
        >
          <Mail className="w-4 h-4 text-emerald-400" />
          <span>Inquire Enterprise License</span>
        </a>
      </div>
    </div>
  );
};
