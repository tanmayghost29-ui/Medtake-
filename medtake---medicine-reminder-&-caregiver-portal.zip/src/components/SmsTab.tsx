import React, { useState } from "react";
import { SmsLogItem, GuardianSettings } from "../types";
import {
  normalizePhoneNumber,
  createSmsIntentUrl,
  createWhatsAppUrl,
  createPhoneCallUrl,
} from "../utils/storage";
import {
  MessageSquare,
  Send,
  CheckCircle2,
  Smartphone,
  Trash2,
  Zap,
  PhoneCall,
  Settings,
  ShieldCheck,
  BellRing,
  ExternalLink,
} from "lucide-react";

interface SmsTabProps {
  smsOutbox: SmsLogItem[];
  guardianSettings?: GuardianSettings;
  onUpdateGuardianSettings?: (settings: GuardianSettings) => void;
  onSendDualAlert: (to: string, message: string) => Promise<any>;
  onClearSmsLog: () => void;
}

export const SmsTab: React.FC<SmsTabProps> = ({
  smsOutbox,
  guardianSettings,
  onUpdateGuardianSettings,
  onSendDualAlert,
  onClearSmsLog,
}) => {
  const [testNumber, setTestNumber] = useState(guardianSettings?.guardian_phone || "");
  const [testMessage, setTestMessage] = useState(
    "medtake ALERT: Kamala Devi has completed scheduled Dolo 650 dose."
  );
  const [isSending, setIsSending] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [filterChannel, setFilterChannel] = useState<"all" | "sms" | "whatsapp">("all");

  const cleanPhone = normalizePhoneNumber(testNumber);
  const directSmsUrl = createSmsIntentUrl(cleanPhone, testMessage);
  const directWaUrl = createWhatsAppUrl(cleanPhone, testMessage);
  const directCallUrl = createPhoneCallUrl(cleanPhone);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testNumber.trim() || !testMessage.trim()) return;

    setIsSending(true);
    setFeedback(null);
    try {
      await onSendDualAlert(cleanPhone, testMessage.trim());
      setFeedback(
        `✓ Dispatched automatically to BOTH Normal Text (SMS) & WhatsApp for ${cleanPhone}!`
      );
    } catch (e: any) {
      setFeedback("Failed to dispatch: " + e.message);
    } finally {
      setIsSending(false);
    }
  };

  const handlePhoneBlur = () => {
    if (testNumber.trim()) {
      setTestNumber(normalizePhoneNumber(testNumber));
    }
  };

  const reversedSms = [...smsOutbox].reverse().filter((item) => {
    if (filterChannel === "all") return true;
    if (filterChannel === "whatsapp") return item.channel === "whatsapp" || item.channel === "dual";
    if (filterChannel === "sms") return item.channel === "sms" || item.channel === "dual" || !item.channel;
    return true;
  });

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-10">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
              <Zap className="w-5 h-5 fill-emerald-600 text-emerald-600" />
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Dual Automated Guardian Alerts
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
            Delivers notifications simultaneously to <strong>Normal Text (SMS)</strong> and <strong>WhatsApp</strong> automatically without prompting or asking.
          </p>
        </div>

        {smsOutbox.length > 0 && (
          <button
            onClick={() => {
              if (window.confirm("Clear all alert records from outbox?")) {
                onClearSmsLog();
              }
            }}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-red-600 hover:bg-red-50 text-xs font-bold transition-colors cursor-pointer self-start md:self-auto border border-red-200/60"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Outbox</span>
          </button>
        )}
      </div>

      {/* Automatic Dual Dispatch Feature Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-900 to-teal-900 text-white shadow-xl space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="font-extrabold text-sm uppercase tracking-wider text-emerald-300">
              Automatic Dual-Delivery Active
            </span>
          </div>
          <span className="px-3 py-1 rounded-full bg-emerald-800/80 text-[11px] font-bold border border-emerald-600 text-emerald-200">
            SMS + WhatsApp • Zero User Prompts
          </span>
        </div>

        <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
          Whenever a medicine dose is confirmed, snoozed, missed, or inventory falls low, medtake triggers the automated dual dispatcher to send alerts to both cellular SMS and WhatsApp instantly.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs">
          <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
            <Smartphone className="w-4 h-4 text-emerald-300 shrink-0" />
            <div>
              <span className="font-bold block text-white">Normal Text (SMS)</span>
              <span className="text-[11px] text-emerald-200">Carrier Telecom Network</span>
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
            <MessageSquare className="w-4 h-4 text-emerald-300 shrink-0" />
            <div>
              <span className="font-bold block text-white">WhatsApp Messaging</span>
              <span className="text-[11px] text-emerald-200">Direct WhatsApp Dispatch</span>
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
            <BellRing className="w-4 h-4 text-emerald-300 shrink-0" />
            <div>
              <span className="font-bold block text-white">Missed Dose Auto-Alert</span>
              <span className="text-[11px] text-emerald-200">Escalates after 2 mins</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dispatch Test Alert Form */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
              <Send className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Send Dual Test Alert (SMS + WhatsApp)
              </h3>
              <p className="text-xs text-slate-500">
                Tests immediate automatic delivery to both channels.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-slate-600">Quick Actions:</span>
            {cleanPhone && (
              <>
                <a
                  href={directCallUrl}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold flex items-center gap-1 transition-colors"
                  title="Call this number directly"
                >
                  <PhoneCall className="w-3 h-3 text-amber-700" />
                  <span>Call</span>
                </a>
                <a
                  href={directSmsUrl}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold flex items-center gap-1 transition-colors"
                  title="Open in native SMS app"
                >
                  <Smartphone className="w-3 h-3 text-emerald-600" />
                  <span>SMS</span>
                </a>
                <a
                  href={directWaUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="px-2.5 py-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold flex items-center gap-1 transition-colors"
                  title="Open in WhatsApp"
                >
                  <MessageSquare className="w-3 h-3 text-emerald-700" />
                  <span>WhatsApp</span>
                </a>
              </>
            )}
          </div>
        </div>

        {feedback && (
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-semibold flex items-center gap-2.5 animate-in fade-in duration-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        <form onSubmit={handleSend} className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                Guardian Phone Number
              </label>
              <input
                type="text"
                value={testNumber}
                onChange={(e) => setTestNumber(e.target.value)}
                onBlur={handlePhoneBlur}
                placeholder="e.g. +91 9876543210"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-mono font-medium focus:outline-hidden focus:border-emerald-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Auto-normalizes to E.164 (e.g. +91 98765 43210)
              </span>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                Message Content
              </label>
              <input
                type="text"
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Zap className="w-3.5 h-3.5 text-emerald-600" />
              <span>Sends simultaneously to SMS and WhatsApp without asking.</span>
            </div>

            <button
              type="submit"
              disabled={isSending}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-700/20 flex items-center gap-2 cursor-pointer disabled:bg-slate-300 transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSending ? "Auto-Dispatching..." : "⚡ Auto-Dispatch Both (No Prompt)"}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Outbox Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h4 className="font-black text-sm uppercase tracking-wider text-slate-800">
              Dispatched Alerts Outbox ({smsOutbox.length})
            </h4>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
              Dual Channel
            </span>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-200/70 text-xs">
            <button
              onClick={() => setFilterChannel("all")}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                filterChannel === "all" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              All Channels
            </button>
            <button
              onClick={() => setFilterChannel("sms")}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                filterChannel === "sms" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              📱 SMS Only
            </button>
            <button
              onClick={() => setFilterChannel("whatsapp")}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                filterChannel === "whatsapp" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              💬 WhatsApp
            </button>
          </div>
        </div>

        {reversedSms.length === 0 ? (
          <div className="p-10 text-center text-slate-400 space-y-2">
            <MessageSquare className="w-8 h-8 mx-auto text-slate-300" />
            <p className="text-sm font-semibold">No messages in this filter.</p>
            <p className="text-xs">
              When dose actions, snoozes, or low-stock alerts occur, guardian notices appear here.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {reversedSms.map((item, idx) => {
              const itemPhone = normalizePhoneNumber(item.to);
              const itemSmsUrl = item.smsUrl || createSmsIntentUrl(itemPhone, item.body);
              const itemWaUrl = item.whatsappUrl || createWhatsAppUrl(itemPhone, item.body);
              const itemCallUrl = createPhoneCallUrl(itemPhone);

              return (
                <div
                  key={item.id || idx}
                  className="p-4 sm:p-5 hover:bg-slate-50/70 transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1.5 max-w-xl">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                        {item.to}
                      </span>
                      <span className="text-slate-400">•</span>
                      <span className="text-slate-500 font-medium">{item.time}</span>
                      <span className="text-slate-400">•</span>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">
                        {item.status}
                      </span>
                    </div>
                    <p className="text-slate-800 text-sm font-medium leading-relaxed">
                      "{item.body}"
                    </p>
                  </div>

                  {/* Direct delivery & call shortcuts */}
                  {itemPhone && (
                    <div className="shrink-0 flex items-center gap-2 pt-1 md:pt-0">
                      <a
                        href={itemCallUrl}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold text-xs transition-colors"
                        title="Call guardian"
                      >
                        <PhoneCall className="w-3 h-3 text-amber-700" />
                        <span>Call</span>
                      </a>

                      <a
                        href={itemSmsUrl}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-colors"
                        title="View in SMS app"
                      >
                        <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                        <span>SMS</span>
                      </a>

                      <a
                        href={itemWaUrl}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors"
                        title="View in WhatsApp"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
