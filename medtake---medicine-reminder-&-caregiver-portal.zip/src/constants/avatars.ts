export interface PresetAvatar {
  id: string;
  name: string;
  url: string;
  bgColor: string;
}

// Crisp, high quality vector portrait SVGs for instant selection without external network delays
export const PRESET_AVATARS: PresetAvatar[] = [
  {
    id: "elder-woman-1",
    name: "Grandmother (Kamala)",
    bgColor: "bg-rose-100 text-rose-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23FCE7F3'/%3E%3Ccircle cx='50' cy='42' r='20' fill='%23F472B6'/%3E%3Ccircle cx='50' cy='38' r='18' fill='%23FDE047'/%3E%3Cpath d='M30,36 C30,22 70,22 70,36 C70,28 65,22 50,22 C35,22 30,28 30,36 Z' fill='%239CA3AF'/%3E%3Ccircle cx='43' cy='40' r='2' fill='%231F2937'/%3E%3Ccircle cx='57' cy='40' r='2' fill='%231F2937'/%3E%3Ccircle cx='50' cy='36' r='2' fill='%23DC2626'/%3E%3Cpath d='M44,47 Q50,52 56,47' stroke='%23DC2626' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M20,95 C25,65 75,65 80,95 Z' fill='%23BE185D'/%3E%3Cpath d='M35,70 L65,70 L50,95 Z' fill='%23FBCFE8'/%3E%3C/svg%3E",
  },
  {
    id: "elder-man-1",
    name: "Grandfather (Sharma)",
    bgColor: "bg-amber-100 text-amber-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23FEF3C7'/%3E%3Ccircle cx='50' cy='42' r='20' fill='%23FCD34D'/%3E%3Cpath d='M28,34 C28,18 72,18 72,34 C68,26 62,22 50,22 C38,22 32,26 28,34 Z' fill='%23E5E7EB'/%3E%3Crect x='36' y='36' width='11' height='8' rx='2' stroke='%234B5563' stroke-width='2' fill='none'/%3E%3Crect x='53' y='36' width='11' height='8' rx='2' stroke='%234B5563' stroke-width='2' fill='none'/%3E%3Cline x1='47' y1='40' x2='53' y2='40' stroke='%234B5563' stroke-width='2'/%3E%3Cpath d='M40,50 Q50,55 60,50' stroke='%239CA3AF' stroke-width='4' fill='none' stroke-linecap='round'/%3E%3Cpath d='M18,95 C22,64 78,64 82,95 Z' fill='%23D97706'/%3E%3Cpath d='M45,68 L55,68 L50,95 Z' fill='%23FEF3C7'/%3E%3C/svg%3E",
  },
  {
    id: "young-woman-1",
    name: "Daughter (Ananya)",
    bgColor: "bg-teal-100 text-teal-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23CCFBF1'/%3E%3Cpath d='M25,48 C25,20 75,20 75,48 C75,70 65,75 50,75 C35,75 25,70 25,48 Z' fill='%231F2937'/%3E%3Ccircle cx='50' cy='44' r='18' fill='%23FDE68A'/%3E%3Ccircle cx='43' cy='43' r='2.5' fill='%23111827'/%3E%3Ccircle cx='57' cy='43' r='2.5' fill='%23111827'/%3E%3Cpath d='M45,51 Q50,56 55,51' stroke='%23E11D48' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M18,95 C24,65 76,65 82,95 Z' fill='%230D9488'/%3E%3C/svg%3E",
  },
  {
    id: "adult-man-1",
    name: "Father / Adult Male",
    bgColor: "bg-sky-100 text-sky-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23E0F2FE'/%3E%3Cpath d='M30,30 C30,18 70,18 70,30 Z' fill='%23374151'/%3E%3Ccircle cx='50' cy='44' r='19' fill='%23FDE047'/%3E%3Ccircle cx='43' cy='42' r='2.5' fill='%231F2937'/%3E%3Ccircle cx='57' cy='42' r='2.5' fill='%231F2937'/%3E%3Cpath d='M44,52 Q50,56 56,52' stroke='%23374151' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M16,95 C22,66 78,66 84,95 Z' fill='%230284C7'/%3E%3Cpath d='M46,67 L54,67 L50,95 Z' fill='%23BAE6FD'/%3E%3C/svg%3E",
  },
  {
    id: "adult-woman-1",
    name: "Mother / Adult Female",
    bgColor: "bg-purple-100 text-purple-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23F3E8FF'/%3E%3Cpath d='M26,35 C26,18 74,18 74,35 C74,58 70,68 50,68 C30,68 26,58 26,35 Z' fill='%234C1D95'/%3E%3Ccircle cx='50' cy='43' r='18' fill='%23FDE047'/%3E%3Ccircle cx='43' cy='42' r='2.5' fill='%231F2937'/%3E%3Ccircle cx='57' cy='42' r='2.5' fill='%231F2937'/%3E%3Cpath d='M44,51 Q50,55 56,51' stroke='%239333EA' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3Cpath d='M18,95 C24,65 76,65 82,95 Z' fill='%237E22CE'/%3E%3C/svg%3E",
  },
  {
    id: "child-1",
    name: "Child / Kid",
    bgColor: "bg-emerald-100 text-emerald-800",
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23D1FAE5'/%3E%3Ccircle cx='50' cy='44' r='19' fill='%23FDE68A'/%3E%3Cpath d='M30,32 C30,18 70,18 70,32 Z' fill='%23B45309'/%3E%3Ccircle cx='42' cy='43' r='3' fill='%231F2937'/%3E%3Ccircle cx='58' cy='43' r='3' fill='%231F2937'/%3E%3Cpath d='M42,52 Q50,60 58,52' stroke='%23DC2626' stroke-width='2.5' fill='none' stroke-linecap='round'/%3E%3Cpath d='M20,95 C26,68 74,68 80,95 Z' fill='%23059669'/%3E%3C/svg%3E",
  },
];
