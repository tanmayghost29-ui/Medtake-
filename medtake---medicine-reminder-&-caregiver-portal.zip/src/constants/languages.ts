import { LanguageInfo } from "../types";

export const LANGUAGES: Record<string, LanguageInfo> = {
  "English": {
    code: "en-US",
    text: "Hey {name}, it's time to take your medicine. Please take your medicine, {med}, {dose}.",
  },
  "Kannada (ಕನ್ನಡ)": {
    code: "kn-IN",
    text: "ಹಲೋ {name}, ನಿಮ್ಮ ಔಷಧಿಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುವ ಸಮಯವಾಯಿತು. ದಯವಿಟ್ಟು {med} ತೆಗೆದುಕೊಳ್ಳಿ, ಪ್ರಮಾಣ: {dose}.",
  },
  "Hindi (हिन्दी)": {
    code: "hi-IN",
    text: "नमस्ते {name}, आपके दवाई लेने का समय हो गया है। कृपया {med} लें, मात्रा: {dose}।",
  },
  "Tamil (தமிழ்)": {
    code: "ta-IN",
    text: "வணக்கம் {name}, உங்கள் மருந்தை உட்கொள்ளும் நேரம் வந்துவிட்டது. தயவுசெய்து {med} எடுத்துக் கொள்ளுங்கள், அளவு: {dose}.",
  },
  "Telugu (తెలుగు)": {
    code: "te-IN",
    text: "హలో {name}, మీ మందులు వేసుకునే సమయం అయింది. దయచేసి మీ ఔషధం {med}, మోతాదు: {dose} వేసుకోండి.",
  },
  "Malayalam (മലയാളം)": {
    code: "ml-IN",
    text: "ഹലോ {name}, നിങ്ങളുടെ മരുന്ന് കഴിക്കാനുള്ള സമയമായി. ദയവായി {med}, {dose} കഴിക്കുക.",
  },
  "Marathi (मराठी)": {
    code: "mr-IN",
    text: "नमस्कार {name}, तुमची औषध घेण्याची वेळ झाली आहे. कृपया {med} घ्या, प्रमाण: {dose}.",
  },
  "Gujarati (ગુજરાતી)": {
    code: "gu-IN",
    text: "નમસ્તે {name}, તમારી દવા લેવાનો સમય થઈ ગયો છે. કૃપા કરીને {med} લો, માત્રા: {dose}.",
  },
  "Bengali (বাংলা)": {
    code: "bn-IN",
    text: "নমস্কার {name}, আপনার ওষুধ খাওয়ার সময় হয়েছে। অনুগ্রহ করে {med} খান, মাত্রা: {dose}।",
  },
  "Punjabi (ਪੰਜਾਬੀ)": {
    code: "pa-IN",
    text: "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ {name}, ਤੁਹਾਡੀ ਦਵਾਈ ਲੈਣ ਦਾ ਸਮਾਂ ਹੋ ਗਿਆ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ {med} ਲਵੋ, ਖੁਰਾਕ: {dose}.",
  },
  "Odia (ଓଡ଼ିଆ)": {
    code: "or-IN",
    text: "ନମସ୍କାର {name}, ଆପଣଙ୍କର ଔଷଧ ଖାଇବାର ସମୟ ହୋଇଛି। ଦୟାକରି {med} ଖାଆନ୍ତୁ, ମାତ୍ରା: {dose}।",
  },
  "Assamese (অসমীয়া)": {
    code: "as-IN",
    text: "নমস্কাৰ {name}, আপোনাৰ ঔষধ খোৱাৰ সময় হৈছে। অনুগ্ৰহ কৰি {med} খাওক, মাত্ৰা: {dose}।",
  },
  "Urdu (اردو)": {
    code: "ur-IN",
    text: "ہیلو {name}، آپ کی دوا لینے کا وقت ہو گیا ہے۔ براہ کرم {med} لیں، خوراک: {dose}۔",
  },
  "Sanskrit (संस्कृतम्)": {
    code: "sa-IN",
    text: "नमस्ते {name}, भवतः औषधसेवनस्य समयः जातः। कृपया {med} स्वीकरोतु, मात्रा: {dose}।",
  },
  "Konkani (कोंकणी)": {
    code: "kok-IN",
    text: "नमस्कार {name}, तुजें वखद घेवपाचो वेळ जालो. उपकार करून {med} घे, प्रमाण: {dose}.",
  },
  "Maithili (मैथिली)": {
    code: "mai-IN",
    text: "प्रणाम {name}, अहाँक दवाई लेबाक समय भ' गेल अछि। कृपया {med} लिअ', मात्रा: {dose}।",
  },
  "Kashmiri (کٲشُر / कश्मीरी)": {
    code: "ks-IN",
    text: "سلام {name}، تۄہہِ چھُو دَوا کھؠنُک وَقٕت آمُت۔ مہرَبانی کٔرِتھ کھؠو {med}، خوراک: {dose}۔",
  },
  "Nepali (नेपाली)": {
    code: "ne-NP",
    text: "नमस्ते {name}, तपाईंको औषधि लिने समय भएको छ। कृपया {med} लिनुहोस्, मात्रा: {dose}।",
  },
  "Sindhi (سنڌي / सिन्धी)": {
    code: "sd-IN",
    text: "سلام {name}، توهان جي دوا وٺڻ جو وقت ٿي ويو آهي. مهرباني ڪري {med} وٺو، مقدار: {dose}.",
  },
  "Dogri (डोगरी)": {
    code: "doi-IN",
    text: "नमस्ते {name}, तुंदी दवाई लेने दा टेम होई गेआ ऐ। कृपया {med} लैओ, मात्रा: {dose}।",
  },
  "Bodo (बड़ो)": {
    code: "brx-IN",
    text: "खुमबिला {name}, नोंनि मुलु लानि समा जाबाय। अननानै {med} लादो, बिबां: {dose}।",
  },
  "Santali (ᱥᱟᱱᱛᱟᱲᱤ)": {
    code: "sat-IN",
    text: "ᱡᱚᱦᱟᱨ {name}, ᱟᱢᱟᱜ ᱨᱟᱱ ᱡᱚᱢ ᱚᱠᱛᱚ ᱦᱩᱭ ᱮᱱᱟ। ᱫᱟᱭᱟᱠᱟᱛᱮ {med} ᱡᱚᱢ ᱢᱮ, ᱦᱟᱹᱴᱤᱧ: {dose}।",
  },
  "Manipuri (মৈতৈলোন্)": {
    code: "mni-IN",
    text: "খোৰুমজৰি {name}, নহাক্কী হিদাক চাবগী মতম ওইরে। চানবীদুনা {med} চাবিয়ু, চাবগী চাং: {dose}।",
  },
};

export const LANGUAGE_LIST = Object.keys(LANGUAGES);

export function formatVoiceMessage(
  langKey: string,
  patientName: string,
  medName: string,
  doseCount: number
): { text: string; code: string } {
  const lang = LANGUAGES[langKey] || LANGUAGES["English"];
  const doseStr = `${doseCount} tablet${doseCount > 1 ? "s" : ""}`;
  const text = lang.text
    .replace("{name}", patientName)
    .replace("{med}", medName)
    .replace("{dose}", doseStr);
  return { text, code: lang.code };
}
