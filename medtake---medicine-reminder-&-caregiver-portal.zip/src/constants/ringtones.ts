import { RingtoneInfo, MealTiming } from "../types";

export const RINGTONES: Record<string, RingtoneInfo> = {
  "Digital Clock Beep": {
    freq: 880,
    type: "sawtooth",
    pattern: [0, 250, 500, 750],
  },
  "Loud Emergency Siren": {
    freq: 1200,
    type: "square",
    pattern: [0, 200, 400, 600, 800],
  },
  "Gentle Hospital Chime": {
    freq: 523.25,
    type: "sine",
    pattern: [0, 400, 800],
  },
  "Zen Singing Bowl": {
    freq: 432,
    type: "sine",
    pattern: [0, 600, 1200],
  },
  "Soft Marimba Pulse": {
    freq: 659.25,
    type: "triangle",
    pattern: [0, 220, 440, 660],
  },
};

export const RINGTONE_LIST = Object.keys(RINGTONES);

export const MEAL_OPTIONS: MealTiming[] = [
  "Before food",
  "After food",
  "With food",
  "Empty stomach",
  "Anytime",
];

export const LOW_STOCK_LIMIT = 3;
export const SNOOZE_MINUTES = 5;
