import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { registerSW } from "virtual:pwa-register";

// Enhanced Service Worker registration for background tasks and alarms
const updateSW = registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log("[SW] New content available, updating service worker...");
    updateSW(true);
  },
  onOfflineReady() {
    console.log("[SW] MedTake is ready for offline background monitoring.");
  },
  onRegisteredSW(swScriptUrl, registration) {
    console.log("[SW] Service Worker successfully registered at:", swScriptUrl);
    if (registration) {
      // Periodically check for SW updates
      setInterval(() => {
        registration.update().catch((e) => console.warn("[SW] Update check error:", e));
      }, 60 * 60 * 1000); // Hourly
    }
  },
  onRegisterError(error) {
    console.warn("[SW] Registration error:", error);
  },
});

// Direct native Service Worker registration fallback for /sw.js
if (typeof window !== "undefined" && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .then((reg) => {
        console.log("[SW] /sw.js registered successfully:", reg.scope);
      })
      .catch((err) => {
        console.warn("[SW] /sw.js fallback registration warning:", err);
      });
  });
}

createRoot(document.getElementById("root")!).render(<App />);
