import { GoogleGenAI, Type } from "@google/genai";

const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

export interface PrescriptionAnalysisResult {
  medicineName: string;
  dosageTablets: number;
  frequencyTimesPerDay: number;
  recommendedTime: string;
  mealTiming: "Before food" | "After food" | "With food" | "Empty stomach" | "Anytime";
  conditions: string;
  precautions: string;
  instructions: string;
}

export async function analyzePrescription(
  promptText: string,
  base64Image?: { data: string; mimeType: string }
): Promise<PrescriptionAnalysisResult> {
  const ai = getGeminiClient();
  if (!ai) {
    // Graceful fallback if no API key is set in dev
    return {
      medicineName: promptText.trim() ? promptText.split(/\s+/)[0] : "Metformin 500mg",
      dosageTablets: 1,
      frequencyTimesPerDay: 2,
      recommendedTime: "08:00",
      mealTiming: "After food",
      conditions: "Type 2 Diabetes / Blood sugar management",
      precautions: "Take with meals to minimize stomach upset. Avoid excessive alcohol.",
      instructions: "Take 1 tablet twice daily with or immediately after meals.",
    };
  }

  const parts: any[] = [];
  if (base64Image && base64Image.data) {
    parts.push({
      inlineData: {
        data: base64Image.data,
        mimeType: base64Image.mimeType || "image/jpeg",
      },
    });
  }

  const prompt = `You are a clinical pharmacist assistant for a medicine reminder app.
Analyze this medicine image or prescription notes:
${promptText ? `Notes: "${promptText}"` : "Please extract the medicine details from the image."}

Extract:
1. medicineName: Brand and generic name with strength (e.g., 'Metformin 500mg', 'Amlodipine 5mg').
2. dosageTablets: Number of tablets per dose (integer, default 1).
3. frequencyTimesPerDay: How many times per day (e.g. 1, 2, 3).
4. recommendedTime: Suggested first time in 24-hr format (e.g. '08:00' or '20:00').
5. mealTiming: Exactly one of: 'Before food', 'After food', 'With food', 'Empty stomach', 'Anytime'.
6. conditions: Common condition or disease treated (brief, 3-6 words).
7. precautions: Important warnings, dietary interactions, or side effects (1-2 sentences).
8. instructions: Simple patient-friendly instructions (1-2 sentences).`;

  parts.push({ text: prompt });

  const response = await ai.models.generateContent({
    model: "gemini-3.8-flash",
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          medicineName: { type: Type.STRING },
          dosageTablets: { type: Type.INTEGER },
          frequencyTimesPerDay: { type: Type.INTEGER },
          recommendedTime: { type: Type.STRING },
          mealTiming: {
            type: Type.STRING,
            enum: ["Before food", "After food", "With food", "Empty stomach", "Anytime"],
          },
          conditions: { type: Type.STRING },
          precautions: { type: Type.STRING },
          instructions: { type: Type.STRING },
        },
        required: [
          "medicineName",
          "dosageTablets",
          "recommendedTime",
          "mealTiming",
          "conditions",
          "precautions",
          "instructions",
        ],
      },
    },
  });

  const text = response.text || "{}";
  return JSON.parse(text) as PrescriptionAnalysisResult;
}
