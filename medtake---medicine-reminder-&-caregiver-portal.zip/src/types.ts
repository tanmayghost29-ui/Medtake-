export type MealTiming =
  | "Before food"
  | "After food"
  | "With food"
  | "Empty stomach"
  | "Anytime";

export interface Patient {
  name: string;
  lang: string;
  disease?: string;
  doctor?: string;
  pharmacy?: string;
  guardian_phone?: string;
  avatar?: string | null;
}

export interface Medicine {
  id: string;
  patient: string;
  name: string;
  dose: number;
  stock: number;
  time: string; // "HH:MM" 24hr format
  meal_timing: MealTiming;
  ringtone: string;
  photo?: string | null;
  snooze_until?: string | null;
  last_fired?: string | null;
}

export interface HistoryItem {
  id?: string;
  time: string;
  date: string;
  patient: string;
  med: string;
  status: string;
  syncStatus?: "synced" | "pending" | "offline";
  offlineSaved?: boolean;
  syncedAt?: string;
}

export type AlertChannel = "sms" | "whatsapp" | "dual";

export interface SmsLogItem {
  id?: string;
  time: string;
  to: string;
  body: string;
  status: string;
  channel?: AlertChannel;
  whatsappUrl?: string;
  smsUrl?: string;
}

export interface GuardianSettings {
  autoSendSms: boolean;
  autoSendWhatsApp: boolean;
  notifyOnTaken: boolean;
  notifyOnSnooze: boolean;
  notifyOnMissed: boolean;
  notifyOnLowStock: boolean;
  callMeBotApiKey?: string;
  guardian_phone?: string;
}

export interface UserData {
  username: string;
  email: string;
  guardian_phone?: string;
  patients: Record<string, Patient>;
  medicines: Medicine[];
  history: HistoryItem[];
  sms_outbox: SmsLogItem[];
  guardian_settings?: GuardianSettings;
}

export interface LanguageInfo {
  code: string;
  text: string;
}

export interface RingtoneInfo {
  freq: number;
  type: OscillatorType;
  pattern: number[];
}
