import { RINGTONES } from "../constants/ringtones";

class SoundEngine {
  private audioCtx: AudioContext | null = null;
  private chimeInterval: number | null = null;
  private speakInterval: number | null = null;
  private isAlarmActive = false;
  private isSpeaking = false;
  private voicesLoaded = false;

  constructor() {
    if (typeof window !== "undefined") {
      // Pre-load voices if speech synthesis available
      if ("speechSynthesis" in window) {
        window.speechSynthesis.onvoiceschanged = () => {
          this.voicesLoaded = true;
        };
        // Trigger initial voice fetch
        window.speechSynthesis.getVoices();
      }

      // Unlock audio context on first user interaction anywhere
      const unlockAudio = () => {
        this.unlockContext();
        window.removeEventListener("click", unlockAudio);
        window.removeEventListener("touchstart", unlockAudio);
      };
      window.addEventListener("click", unlockAudio, { passive: true });
      window.addEventListener("touchstart", unlockAudio, { passive: true });
    }
  }

  public unlockContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioContextClass =
        window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === "suspended") {
      this.audioCtx.resume();
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
    return this.audioCtx!;
  }

  private getContext(): AudioContext | null {
    try {
      return this.unlockContext();
    } catch (e) {
      return null;
    }
  }

  /**
   * Play a gentle, soft chime (low volume: 0.04 max, gentle sine wave)
   * so it never overpowers the spoken reminder voice.
   */
  public playSoftChime(ringtoneName: string = "Gentle Hospital Chime") {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const ring = RINGTONES[ringtoneName] || RINGTONES["Gentle Hospital Chime"];
      const { pattern } = ring;
      // Use warm soothing frequency (520Hz)
      const freq = 523.25;

      pattern.forEach((offsetMs) => {
        setTimeout(() => {
          try {
            if (!this.isAlarmActive && this.chimeInterval === null) return;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();

            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.type = "sine";
            osc.frequency.setValueAtTime(freq, ctx.currentTime);

            // Very soft, low volume envelope (0.04 max)
            const now = ctx.currentTime;
            gain.gain.setValueAtTime(0.001, now);
            gain.gain.exponentialRampToValueAtTime(0.04, now + 0.04);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

            osc.start(now);
            osc.stop(now + 0.36);
          } catch {
            // Ignore context tick error
          }
        }, offsetMs);
      });
    } catch (e) {
      console.warn("Audio Context playback error:", e);
    }
  }

  /**
   * Play a pleasant 1-second confirmation chime when permissions or actions are granted
   */
  public playConfirmationChime() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      // Ascending pleasant major triad (C5 -> E5 -> G5)
      const notes = [523.25, 659.25, 783.99];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.12);

        gain.gain.setValueAtTime(0.001, now + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.12, now + idx * 0.12 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.12 + 0.45);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.12);
        osc.stop(now + idx * 0.12 + 0.5);
      });
    } catch (e) {
      console.warn("Confirmation chime error:", e);
    }
  }

  /**
   * Speak voice reminder at HIGH volume (1.0) and clear articulate cadence (0.85)
   */
  public speak(text: string, langCode: string = "en-US", onEnd?: () => void) {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      if (onEnd) onEnd();
      return;
    }

    try {
      const synth = window.speechSynthesis;
      // Resume if browser suspended speech synthesis
      if (synth.paused) {
        synth.resume();
      }
      synth.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = 1.0; // MAXIMUM VOICE VOLUME (loud & clear)
      utterance.rate = 0.85; // Natural, deliberate, clear speed
      utterance.pitch = 1.05; // Friendly, clear pitch
      utterance.lang = langCode;

      const voices = synth.getVoices();
      const prefix = langCode.split("-")[0].toLowerCase();

      // Find best matching voice for this language
      let voice = voices.find(
        (v) => v.lang.toLowerCase().startsWith(prefix)
      );

      // Fallback for Indian voices
      if (!voice) {
        voice = voices.find(
          (v) =>
            v.lang.toLowerCase().includes("hi") ||
            v.lang.toLowerCase().includes("in") ||
            v.name.toLowerCase().includes("india")
        );
      }

      if (voice) {
        utterance.voice = voice;
      }

      utterance.onstart = () => {
        this.isSpeaking = true;
      };

      utterance.onend = () => {
        this.isSpeaking = false;
        if (onEnd) onEnd();
      };

      utterance.onerror = () => {
        this.isSpeaking = false;
        if (onEnd) onEnd();
      };

      synth.speak(utterance);
    } catch (e) {
      console.warn("Speech synthesis error:", e);
      this.isSpeaking = false;
      if (onEnd) onEnd();
    }
  }

  /**
   * Start Alarm loop:
   * 1. Plays gentle soft opening chime.
   * 2. Speaks loud voice reminder immediately.
   * 3. Loops speech every 10 seconds with soft background chimes spaced out.
   */
  public startAlarmLoop(
    ringtoneName: string,
    voiceText: string,
    langCode: string
  ) {
    this.stopAlarmLoop();
    this.isAlarmActive = true;

    this.unlockContext();

    // 1. Soft chime intro
    this.playSoftChime(ringtoneName);

    // 2. Play high-volume spoken voice after short 350ms intro
    setTimeout(() => {
      if (this.isAlarmActive) {
        this.speak(voiceText, langCode);
      }
    }, 350);

    // 3. Gentle chime every 4 seconds when NOT speaking
    this.chimeInterval = window.setInterval(() => {
      if (this.isAlarmActive && !this.isSpeaking) {
        this.playSoftChime(ringtoneName);
      }
    }, 4000);

    // 4. Repeat loud voice reminder every 10 seconds
    this.speakInterval = window.setInterval(() => {
      if (this.isAlarmActive) {
        this.speak(voiceText, langCode);
      }
    }, 10000);
  }

  public stopAlarmLoop() {
    this.isAlarmActive = false;
    this.isSpeaking = false;
    if (this.chimeInterval !== null) {
      clearInterval(this.chimeInterval);
      this.chimeInterval = null;
    }
    if (this.speakInterval !== null) {
      clearInterval(this.speakInterval);
      this.speakInterval = null;
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  }

  public previewRingtone(ringtoneName: string) {
    this.playSoftChime(ringtoneName);
  }

  // --- AMBIENT MOUNTAIN BREEZE SYNTHESIZER (Web Audio API) ---
  private breezeGainNode: GainNode | null = null;
  private breezeSourceNode: AudioNode | null = null;
  private isBreezePlaying = false;

  public toggleMountainBreeze(volume: number = 0.15): boolean {
    if (this.isBreezePlaying) {
      this.stopMountainBreeze();
      return false;
    } else {
      this.startMountainBreeze(volume);
      return true;
    }
  }

  public isMountainBreezeActive(): boolean {
    return this.isBreezePlaying;
  }

  public setMountainBreezeVolume(vol: number) {
    if (this.breezeGainNode && this.audioCtx) {
      const clamped = Math.max(0, Math.min(1, vol));
      this.breezeGainNode.gain.setValueAtTime(clamped * 0.25, this.audioCtx.currentTime);
    }
  }

  public startMountainBreeze(volume: number = 0.15) {
    try {
      this.stopMountainBreeze();
      const ctx = this.getContext();
      if (!ctx) return;

      // Generate 4 seconds of smooth pink/brown noise buffer for natural mountain wind
      const bufferSize = ctx.sampleRate * 4;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.06;
        b6 = white * 0.115926;
      }

      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      // Resonant lowpass filter to mimic mountain wind whistling across peaks
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(320, ctx.currentTime);
      filter.Q.setValueAtTime(3.0, ctx.currentTime);

      // Low frequency oscillator for gentle wind gusts
      const lfo = ctx.createOscillator();
      lfo.frequency.setValueAtTime(0.18, ctx.currentTime); // slow rolling gust every ~5.5s
      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(140, ctx.currentTime);
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);

      const gain = ctx.createGain();
      const targetGain = Math.max(0.01, Math.min(0.25, volume * 0.25));
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(targetGain, ctx.currentTime + 1.2);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      whiteNoise.start(0);
      lfo.start(0);

      this.breezeSourceNode = whiteNoise;
      this.breezeGainNode = gain;
      this.isBreezePlaying = true;
    } catch (err) {
      console.warn("Unable to start mountain breeze audio:", err);
    }
  }

  public stopMountainBreeze() {
    try {
      if (this.breezeGainNode && this.audioCtx) {
        this.breezeGainNode.gain.setValueAtTime(this.breezeGainNode.gain.value, this.audioCtx.currentTime);
        this.breezeGainNode.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + 0.5);
      }
      setTimeout(() => {
        if (this.breezeSourceNode) {
          try {
            (this.breezeSourceNode as any).stop?.();
            this.breezeSourceNode.disconnect();
          } catch {}
          this.breezeSourceNode = null;
        }
        this.breezeGainNode = null;
        this.isBreezePlaying = false;
      }, 550);
    } catch {
      this.isBreezePlaying = false;
    }
  }
}

export const soundEngine = new SoundEngine();

