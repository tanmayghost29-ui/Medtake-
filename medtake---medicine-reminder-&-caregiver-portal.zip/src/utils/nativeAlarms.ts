import { Capacitor } from "@capacitor/core";
import { LocalNotifications, ActionType } from "@capacitor/local-notifications";
import { Medicine } from "../types";

/**
 * Native Android Exact Alarm & Local Notifications Manager
 *
 * Utilizes @capacitor/local-notifications and Android AlarmManager (allowWhileIdle: true)
 * to guarantee exact alarm execution even when the screen is locked, the device is
 * in deep sleep (Doze mode), or the app is killed.
 */

export const ALARM_CHANNEL_ID = "medtake_high_priority_alarms";
export const ACTION_TYPE_ID = "MEDTAKE_ALARM_ACTIONS";

export type NativeAlarmActionCallback = (action: "take" | "snooze" | "open", medicineId: string) => void;

class NativeAlarmService {
  private isInitialized = false;
  private actionListeners = new Set<NativeAlarmActionCallback>();

  /**
   * Generates a consistent 32-bit integer ID from a medicine ID string.
   */
  private hashMedicineId(medId: string): number {
    let hash = 0;
    for (let i = 0; i < medId.length; i++) {
      const char = medId.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0; // Convert to 32bit integer
    }
    return Math.abs(hash) % 2147483647;
  }

  /**
   * Checks if the app is currently running as a native Android or iOS Capacitor application.
   */
  public isNative(): boolean {
    try {
      return Capacitor.isNativePlatform();
    } catch {
      return false;
    }
  }

  /**
   * Initializes notification channels, action types, and response listeners.
   */
  public async init(): Promise<void> {
    if (this.isInitialized) return;

    // Local notifications channels & action types are specific to native platforms (Android/iOS).
    // On web/iframe environments, channels are unimplemented in Capacitor and throw errors.
    if (!this.isNative()) {
      this.isInitialized = true;
      return;
    }

    try {
      if (Capacitor.isPluginAvailable("LocalNotifications")) {
        // 1. Create High-Priority Android Alarm Notification Channel
        await LocalNotifications.createChannel({
          id: ALARM_CHANNEL_ID,
          name: "MedTake Exact Medicine Alarms",
          description: "High-priority alarms that wake device from sleep/lock screen",
          importance: 5, // MAX importance in Android (heads-up notification & loud audio)
          visibility: 1, // Public (visible on lock screen without unlocking)
          sound: "alarm.wav",
          vibration: true,
          lights: true,
          lightColor: "#10b981",
        }).catch((err) => {
          console.warn("[NativeAlarms] Channel creation note:", err);
        });

        // 2. Register Interactive Notification Actions (Taken, Snooze)
        await LocalNotifications.registerActionTypes({
          types: [
            {
              id: ACTION_TYPE_ID,
              actions: [
                {
                  id: "take",
                  title: "✓ Mark Taken",
                  foreground: true,
                },
                {
                  id: "snooze",
                  title: "💤 Snooze (5m)",
                  foreground: false,
                },
              ],
            },
          ],
        }).catch(() => {});

        // 3. Listen for Action Clicks
        LocalNotifications.addListener(
          "localNotificationActionPerformed",
          (notificationAction) => {
            const actionId = notificationAction.actionId;
            const extra = notificationAction.notification.extra;
            const medId = extra?.medicineId;

            if (medId) {
              if (actionId === "take") {
                this.notifyActionListeners("take", medId);
              } else if (actionId === "snooze") {
                this.notifyActionListeners("snooze", medId);
              } else {
                this.notifyActionListeners("open", medId);
              }
            }
          }
        );

        // 4. Listen for Notification Received while app is in foreground
        LocalNotifications.addListener(
          "localNotificationReceived",
          (notification) => {
            const medId = notification.extra?.medicineId;
            if (medId) {
              this.notifyActionListeners("open", medId);
            }
          }
        );

        this.isInitialized = true;
      }
    } catch (err) {
      console.warn("[NativeAlarms] Init note:", err);
    }
  }

  public addActionListener(callback: NativeAlarmActionCallback): () => void {
    this.actionListeners.add(callback);
    return () => {
      this.actionListeners.delete(callback);
    };
  }

  private notifyActionListeners(action: "take" | "snooze" | "open", medicineId: string) {
    this.actionListeners.forEach((fn) => {
      try {
        fn(action, medicineId);
      } catch (err) {
        console.warn("[NativeAlarms] Action listener warning:", err);
      }
    });
  }

  /**
   * Request native Android notification and exact alarm permissions.
   */
  public async requestPermissions(): Promise<boolean> {
    // If running in browser or iframe environment, check standard web notification permission gracefully
    if (!this.isNative()) {
      if (typeof window !== "undefined" && "Notification" in window) {
        try {
          if (Notification.permission === "granted") return true;
          if (Notification.permission === "denied") return false;
          const status = await Notification.requestPermission();
          return status === "granted";
        } catch {
          return false;
        }
      }
      return false;
    }

    if (!Capacitor.isPluginAvailable("LocalNotifications")) {
      return false;
    }

    try {
      const status = await LocalNotifications.requestPermissions();
      return status.display === "granted";
    } catch (e) {
      console.warn("[NativeAlarms] Permission request note:", e);
      return false;
    }
  }

  /**
   * Schedules exact native Android alarms for all prescribed medicines.
   * Uses `allowWhileIdle: true` to trigger Android exact alarms (SetExactAndAllowWhileIdle)
   * which wakes the phone even from deep Doze battery-saving mode and lock screen.
   */
  public async scheduleExactAlarms(medicines: Medicine[]): Promise<void> {
    // On web platforms, native Android AlarmManager exact alarms are not applicable.
    // The web Service Worker (serviceWorkerManager) and app interval timer reliably manage web alarms.
    if (!this.isNative()) {
      return;
    }

    if (!Capacitor.isPluginAvailable("LocalNotifications")) {
      return;
    }

    await this.init();

    try {
      // 1. Cancel pending native notifications first to avoid stale dupes
      const pending = await LocalNotifications.getPending();
      if (pending && pending.notifications && pending.notifications.length > 0) {
        await LocalNotifications.cancel({
          notifications: pending.notifications.map((n) => ({ id: n.id })),
        });
      }

      if (!medicines || medicines.length === 0) return;

      const now = new Date();
      const scheduledNotifications = [];

      for (const med of medicines) {
        let targetDate: Date;

        // Check if there is an active snooze
        if (med.snooze_until) {
          const snoozeDate = new Date(med.snooze_until);
          if (snoozeDate > now) {
            targetDate = snoozeDate;
          } else {
            // Snooze already passed, schedule regular time
            targetDate = this.calculateNextOccurrence(med.time, now);
          }
        } else {
          targetDate = this.calculateNextOccurrence(med.time, now);
        }

        const numericId = this.hashMedicineId(med.id);

        scheduledNotifications.push({
          id: numericId,
          title: `⏰ MEDICINE ALARM: ${med.name}`,
          body: `High-priority alert for ${med.patient}: Take ${med.dose} tablet of ${med.name}. (Scheduled for ${med.time})`,
          schedule: {
            at: targetDate,
            allowWhileIdle: true, // Wakes phone up even in deep sleep/lock screen!
          },
          sound: "alarm.wav",
          channelId: ALARM_CHANNEL_ID,
          smallIcon: "ic_stat_alarm",
          actionTypeId: ACTION_TYPE_ID,
          extra: {
            medicineId: med.id,
            patientName: med.patient,
            medicineName: med.name,
            scheduledTime: med.time,
          },
          ongoing: false,
          autoCancel: true,
        });
      }

      if (scheduledNotifications.length > 0) {
        await LocalNotifications.schedule({
          notifications: scheduledNotifications,
        });
      }
    } catch (err) {
      console.warn("[NativeAlarms] Note scheduling exact native alarms:", err);
    }
  }

  /**
   * Calculates the next occurrence timestamp for HH:MM time string.
   */
  private calculateNextOccurrence(timeStr: string, fromDate: Date): Date {
    const [hours, minutes] = timeStr.split(":").map(Number);
    const target = new Date(fromDate);
    target.setHours(hours, minutes, 0, 0);

    // If target has already passed today, schedule for tomorrow
    if (target.getTime() <= fromDate.getTime()) {
      target.setDate(target.getDate() + 1);
    }

    return target;
  }
}

export const nativeAlarmService = new NativeAlarmService();
