import { HistoryItem } from "../types";

/**
 * MedTake IndexedDB Offline Storage & Fallback Synchronization Manager
 *
 * Provides a resilient offline fallback using the browser's IndexedDB engine:
 * 1. When the device is offline or the network is unreachable, pending medicine
 *    history logs are securely saved into IndexedDB ('pending_history_logs').
 * 2. As soon as the device reconnects to the network ('online' event),
 *    the pending logs are automatically drained and synchronized to the server (/api/sync-history).
 * 3. Provides real-time connection status monitoring and manual synchronization triggers.
 */

export interface PendingHistoryLog {
  id: string;
  username: string;
  time: string;
  date: string;
  patient: string;
  med: string;
  status: string;
  createdAt: number;
  attempts: number;
  offlineSaved: boolean;
  lastError?: string;
}

export interface SyncStatus {
  isOnline: boolean;
  pendingCount: number;
  lastSyncTime: string | null;
  isSyncing: boolean;
}

const DB_NAME = "medtake_offline_vault_v1";
const DB_VERSION = 1;
const STORE_NAME = "pending_history_logs";

class OfflineSyncManager {
  private dbPromise: Promise<IDBDatabase> | null = null;
  private listeners: Set<(status: SyncStatus) => void> = new Set();
  private isSyncing = false;
  private lastSyncTime: string | null = null;
  private cachedPendingCount = 0;

  constructor() {
    if (typeof window !== "undefined") {
      // Listen for network state transitions
      window.addEventListener("online", () => {
        console.log("[OfflineSync] Device returned ONLINE. Auto-syncing pending medicine logs...");
        this.notifyListeners();
        // Allow network stack 1 second to settle before syncing
        setTimeout(() => {
          this.autoDrainQueue();
        }, 1000);
      });

      window.addEventListener("offline", () => {
        console.log("[OfflineSync] Device went OFFLINE. IndexedDB fallback active.");
        this.notifyListeners();
      });

      // Initialize DB & refresh count
      this.getPendingCount().then((count) => {
        this.cachedPendingCount = count;
        this.notifyListeners();
      }).catch(() => {});
    }
  }

  /**
   * Initializes or returns the open IndexedDB instance
   */
  private getDB(): Promise<IDBDatabase> {
    if (typeof window === "undefined" || !("indexedDB" in window)) {
      return Promise.reject(new Error("IndexedDB is not supported in this environment"));
    }

    if (this.dbPromise) {
      return this.dbPromise;
    }

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
          store.createIndex("by_username", "username", { unique: false });
          store.createIndex("by_createdAt", "createdAt", { unique: false });
        }
      };

      request.onsuccess = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        resolve(db);
      };

      request.onerror = (event) => {
        console.error("[OfflineSync] IndexedDB open error:", (event.target as IDBOpenDBRequest).error);
        reject((event.target as IDBOpenDBRequest).error);
      };
    });

    return this.dbPromise;
  }

  /**
   * Check if client considers itself online
   */
  public isOnline(): boolean {
    if (typeof navigator !== "undefined" && typeof navigator.onLine === "boolean") {
      return navigator.onLine;
    }
    return true;
  }

  /**
   * Store a pending history log into IndexedDB fallback queue
   */
  public async storePendingLog(
    item: HistoryItem,
    username: string
  ): Promise<PendingHistoryLog> {
    const db = await this.getDB();
    const id = item.id || `offline-log-${Date.now()}-${Math.random().toString(36).substr(2, 7)}`;

    const pendingRecord: PendingHistoryLog = {
      id,
      username: username || "default",
      time: item.time,
      date: item.date,
      patient: item.patient,
      med: item.med,
      status: item.status,
      createdAt: Date.now(),
      attempts: 0,
      offlineSaved: true,
    };

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(pendingRecord);

      req.onsuccess = () => {
        console.log(`[OfflineSync] Stored pending medicine log into IndexedDB: ${id} (${item.med})`);
        this.cachedPendingCount++;
        this.notifyListeners();
        resolve(pendingRecord);
      };

      req.onerror = () => {
        console.error("[OfflineSync] Failed to put log into IndexedDB:", req.error);
        reject(req.error);
      };
    });
  }

  /**
   * Retrieve all pending history logs from IndexedDB
   */
  public async getAllPendingLogs(username?: string): Promise<PendingHistoryLog[]> {
    try {
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readonly");
        const store = tx.objectStore(STORE_NAME);
        const req = store.getAll();

        req.onsuccess = () => {
          const all: PendingHistoryLog[] = req.result || [];
          if (username) {
            resolve(all.filter((log) => log.username === username));
          } else {
            resolve(all);
          }
        };

        req.onerror = () => reject(req.error);
      });
    } catch {
      return [];
    }
  }

  /**
   * Get the current count of pending logs in IndexedDB
   */
  public async getPendingCount(username?: string): Promise<number> {
    const list = await this.getAllPendingLogs(username);
    this.cachedPendingCount = list.length;
    return list.length;
  }

  /**
   * Delete a successfully synced log from IndexedDB
   */
  public async removePendingLog(id: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);

      req.onsuccess = () => {
        this.cachedPendingCount = Math.max(0, this.cachedPendingCount - 1);
        this.notifyListeners();
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  }

  /**
   * Clear all pending logs
   */
  public async clearAllPendingLogs(): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      const store = tx.objectStore(STORE_NAME);
      const req = store.clear();

      req.onsuccess = () => {
        this.cachedPendingCount = 0;
        this.notifyListeners();
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  }

  /**
   * Synchronize pending medicine history logs to the server.
   * If online, flushes logs from IndexedDB to /api/sync-history and purges synced records.
   */
  public async syncPendingLogsToServer(username: string): Promise<{
    syncedCount: number;
    remainingCount: number;
    errors: string[];
  }> {
    if (this.isSyncing) {
      return { syncedCount: 0, remainingCount: this.cachedPendingCount, errors: ["Sync already in progress"] };
    }

    if (!this.isOnline()) {
      return { syncedCount: 0, remainingCount: this.cachedPendingCount, errors: ["Device is currently offline"] };
    }

    const pendingLogs = await this.getAllPendingLogs(username);
    if (pendingLogs.length === 0) {
      return { syncedCount: 0, remainingCount: 0, errors: [] };
    }

    this.isSyncing = true;
    this.notifyListeners();

    let syncedCount = 0;
    const errors: string[] = [];

    try {
      const payload = {
        username: username || "default",
        logs: pendingLogs.map((p) => ({
          id: p.id,
          time: p.time,
          date: p.date,
          patient: p.patient,
          med: p.med,
          status: p.status,
          offlineSaved: true,
          offlineTimestamp: p.createdAt,
        })),
      };

      const response = await fetch("/api/sync-history", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      if (result.success && Array.isArray(result.syncedIds)) {
        // Remove synced items from IndexedDB
        for (const syncedId of result.syncedIds) {
          await this.removePendingLog(syncedId);
          syncedCount++;
        }
        this.lastSyncTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        console.log(`[OfflineSync] Successfully synced ${syncedCount} offline logs to server!`);
      } else {
        throw new Error(result.error || "Unexpected server response format");
      }
    } catch (err: any) {
      console.warn("[OfflineSync] Failed to sync pending logs to server:", err);
      errors.push(err.message || "Network sync failed");
    } finally {
      this.isSyncing = false;
      await this.getPendingCount();
      this.notifyListeners();
    }

    return {
      syncedCount,
      remainingCount: this.cachedPendingCount,
      errors,
    };
  }

  /**
   * Processes a new medicine history item:
   * - Attempts immediate cloud sync if online.
   * - Falls back seamlessly to IndexedDB if offline or if network request errors.
   */
  public async recordHistoryItem(
    item: HistoryItem,
    username: string
  ): Promise<{ enrichedItem: HistoryItem; savedToIndexedDB: boolean }> {
    const id = item.id || `log-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    const baseItem: HistoryItem = { ...item, id };

    // Case 1: Offline -> Immediately save to IndexedDB fallback
    if (!this.isOnline()) {
      console.log("[OfflineSync] Device is offline. Saving directly into IndexedDB fallback.");
      await this.storePendingLog(baseItem, username);
      return {
        enrichedItem: {
          ...baseItem,
          syncStatus: "offline",
          offlineSaved: true,
        },
        savedToIndexedDB: true,
      };
    }

    // Case 2: Online -> Try immediate cloud push to /api/sync-history
    try {
      const response = await fetch("/api/sync-history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          logs: [baseItem],
        }),
      });

      if (response.ok) {
        const json = await response.json();
        if (json.success) {
          this.lastSyncTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
          this.notifyListeners();
          return {
            enrichedItem: {
              ...baseItem,
              syncStatus: "synced",
              syncedAt: this.lastSyncTime,
            },
            savedToIndexedDB: false,
          };
        }
      }
      throw new Error(`Sync HTTP ${response.status}`);
    } catch (err) {
      // Case 3: Network error or server unreachable -> Fallback to IndexedDB!
      console.warn("[OfflineSync] Server sync failed. Saving to IndexedDB fallback queue:", err);
      await this.storePendingLog(baseItem, username);
      return {
        enrichedItem: {
          ...baseItem,
          syncStatus: "offline",
          offlineSaved: true,
        },
        savedToIndexedDB: true,
      };
    }
  }

  /**
   * Helper that automatically drains queue for active user
   */
  private autoDrainQueue(): void {
    if (typeof localStorage !== "undefined") {
      const activeUser = localStorage.getItem("medtake_active_user");
      if (activeUser && activeUser.trim()) {
        this.syncPendingLogsToServer(activeUser.trim());
      }
    }
  }

  /**
   * Register a state subscriber
   */
  public subscribe(callback: (status: SyncStatus) => void): () => void {
    this.listeners.add(callback);
    // Send immediate initial status
    callback(this.getStatus());
    return () => {
      this.listeners.delete(callback);
    };
  }

  public getStatus(): SyncStatus {
    return {
      isOnline: this.isOnline(),
      pendingCount: this.cachedPendingCount,
      lastSyncTime: this.lastSyncTime,
      isSyncing: this.isSyncing,
    };
  }

  private notifyListeners(): void {
    const status = this.getStatus();
    this.listeners.forEach((listener) => {
      try {
        listener(status);
      } catch (e) {
        console.error("[OfflineSync] Subscriber error:", e);
      }
    });
  }
}

export const offlineSyncManager = new OfflineSyncManager();

// React hook for convenient component integration
import { useState, useEffect } from "react";

export function useOfflineSync() {
  const [status, setStatus] = useState<SyncStatus>(() => offlineSyncManager.getStatus());

  useEffect(() => {
    return offlineSyncManager.subscribe(setStatus);
  }, []);

  return {
    ...status,
    syncNow: (username: string) => offlineSyncManager.syncPendingLogsToServer(username),
    getAllPendingLogs: (username?: string) => offlineSyncManager.getAllPendingLogs(username),
    clearAllPending: () => offlineSyncManager.clearAllPendingLogs(),
  };
}
