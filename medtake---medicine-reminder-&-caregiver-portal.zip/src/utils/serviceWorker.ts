import { Medicine } from "../types";

/**
 * MedTake Service Worker & Background Task Integration
 * Ensures system notifications, background alarm sync, and lock-screen alerts
 * work properly even when the device is locked or the app is minimized.
 */

type SWActionHandler = (action: "take" | "snooze" | "open", medicineId?: string) => void;

class ServiceWorkerManager {
  private registration: ServiceWorkerRegistration | null = null;
  private actionListeners = new Set<SWActionHandler>();

  constructor() {
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      this.init();
    }
  }

  private async init() {
    try {
      // Listen for messages from the service worker (e.g. user clicked "Taken" on lock screen notification)
      navigator.serviceWorker.addEventListener("message", (event) => {
        if (!event.data) return;

        if (event.data.type === "NOTIFICATION_ACTION_CLICKED") {
          const { action, medicineId } = event.data;
          this.actionListeners.forEach((fn) => fn(action, medicineId));
        }

        if (event.data.type === "SW_ALARM_DUE") {
          const { medicineId } = event.data;
          this.actionListeners.forEach((fn) => fn("open", medicineId));
        }

        if (event.data.type === "TRIGGER_OFFLINE_SYNC") {
          import("./offlineSync").then(({ offlineSyncManager }) => {
            const user = localStorage.getItem("medtake_active_user");
            if (user && user.trim()) {
              offlineSyncManager.syncPendingLogsToServer(user.trim()).catch(() => {});
            }
          });
        }
      });

      // Obtain existing active registration
      const reg = await navigator.serviceWorker.ready;
      this.registration = reg;

      // Register background sync for offline queue if supported
      if ("sync" in reg) {
        try {
          await (reg as any).sync.register("sync-pending-medicine-logs");
        } catch {
          // Silent fallback to standard online event
        }
      }

      // Register periodic background sync if supported (Chrome on Android)
      if ("periodicSync" in reg) {
        try {
          const status = await (navigator as any).permissions.query({
            name: "periodic-background-sync",
          });
          if (status.state === "granted") {
            await (reg as any).periodicSync.register("check-medtake-alarms", {
              minInterval: 12 * 60 * 1000, // 12 minutes
            });
          }
        } catch (e) {
          // Periodic sync not available or denied; silent fallback to internal SW timers
        }
      }
    } catch (err) {
      console.warn("[ServiceWorkerManager] Init notice:", err);
    }
  }

  /**
   * Request system notification permissions for background alerts.
   */
  public async requestNotificationPermission(): Promise<NotificationPermission> {
    if (typeof window === "undefined" || !("Notification" in window)) {
      return "denied";
    }

    try {
      const permission = await Notification.requestPermission();
      return permission;
    } catch (e) {
      console.warn("Notification permission error:", e);
      return "denied";
    }
  }

  /**
   * Push medicine schedule to the Service Worker so it monitors in the background.
   */
  public async syncAlarms(medicines: Medicine[]): Promise<void> {
    if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return;

    try {
      const reg = this.registration || (await navigator.serviceWorker.ready);
      this.registration = reg;

      const messagePayload = {
        type: "SYNC_ALARMS",
        medicines: medicines.map((m) => ({
          id: m.id,
          name: m.name,
          time: m.time,
          dose: m.dose,
          stock: m.stock,
          patient: m.patient,
          snooze_until: m.snooze_until,
          last_fired: m.last_fired,
        })),
      };

      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage(messagePayload);
      } else if (reg.active) {
        reg.active.postMessage(messagePayload);
      }
    } catch (err) {
      console.warn("[ServiceWorkerManager] Alarm sync error:", err);
    }
  }

  /**
   * Show a high-priority system notification via the Service Worker registration.
   * On mobile Android, ServiceWorkerRegistration.showNotification() is required for lock-screen display.
   */
  public async triggerSystemNotification(medicine: Medicine): Promise<void> {
    if (typeof window === "undefined") return;

    const title = `⏰ Medicine Alert: ${medicine.name}`;
    const body = `Time for ${medicine.patient} to take ${medicine.name} (${medicine.dose} tablet). Tap to open alarm.`;

    try {
      if ("serviceWorker" in navigator) {
        const reg = this.registration || (await navigator.serviceWorker.ready);
        await reg.showNotification(title, {
          body,
          icon: "/pwa-192x192.png",
          badge: "/icon.svg",
          tag: `medtake-alarm-${medicine.id}`,
          renotify: true,
          requireInteraction: true,
          vibrate: [500, 250, 500, 250, 500, 250, 1000],
          data: {
            medicineId: medicine.id,
            patient: medicine.patient,
            url: `/?alarm=${encodeURIComponent(medicine.id)}`,
          },
          actions: [
            {
              action: "take",
              title: "✓ I Have Taken It",
            },
            {
              action: "snooze",
              title: "⏱ Snooze 5 Min",
            },
          ],
        } as any);
        return;
      }
    } catch (swErr) {
      console.warn("[ServiceWorkerManager] SW notification failed, trying fallback:", swErr);
    }

    // Window Notification fallback (desktop only)
    if ("Notification" in window && Notification.permission === "granted") {
      try {
        new Notification(title, {
          body,
          icon: "/pwa-192x192.png",
          tag: `medtake-alarm-${medicine.id}`,
          requireInteraction: true,
        });
      } catch (e) {
        console.warn("[ServiceWorkerManager] Fallback notification failed:", e);
      }
    }
  }

  /**
   * Subscribe to notification click events received from the Service Worker.
   */
  public onNotificationAction(callback: SWActionHandler): () => void {
    this.actionListeners.add(callback);
    return () => {
      this.actionListeners.delete(callback);
    };
  }
}

export const serviceWorkerManager = new ServiceWorkerManager();
