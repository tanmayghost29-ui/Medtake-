import { UserData, Medicine, HistoryItem, SmsLogItem, Patient, GuardianSettings } from "../types";

const DB_KEY = "medtake_web_db_v1";
const SESSION_USER_KEY = "medtake_active_user";

interface AppDatabase {
  users: Record<string, UserData & { passwordPlain?: string }>;
}

export const DEFAULT_GUARDIAN_SETTINGS: GuardianSettings = {
  autoSendSms: true,
  autoSendWhatsApp: true,
  notifyOnTaken: true,
  notifyOnSnooze: true,
  notifyOnMissed: true,
  notifyOnLowStock: true,
  callMeBotApiKey: "",
};



/**
 * Validates and normalizes phone numbers into international E.164 standard.
 * If 10 digits (e.g. 7259569474), automatically adds +91 (India).
 */
export function normalizePhoneNumber(raw: string): string {
  if (!raw) return "";
  let digits = raw.replace(/[^\d+]/g, "").trim();
  if (digits.startsWith("+")) {
    return digits;
  }
  // If 10 digits Indian mobile, prepend +91
  if (digits.length === 10) {
    return `+91${digits}`;
  }
  // If 12 digits starting with 91
  if (digits.length === 12 && digits.startsWith("91")) {
    return `+${digits}`;
  }
  return digits.length > 0 ? `+${digits}` : "";
}

/**
 * Generates direct SMS intent link for mobile Chrome / Android / iOS
 */
export function createSmsIntentUrl(phoneNumber: string, message: string): string {
  const clean = normalizePhoneNumber(phoneNumber);
  if (!clean) return "";
  return `sms:${clean}?body=${encodeURIComponent(message)}`;
}

/**
 * Generates direct WhatsApp intent link
 */
export function createWhatsAppUrl(phoneNumber: string, message: string): string {
  const clean = normalizePhoneNumber(phoneNumber).replace(/\+/g, "");
  if (!clean) return "";
  return `https://wa.me/${clean}?text=${encodeURIComponent(message)}`;
}

/**
 * Generates direct tel phone call link
 */
export function createPhoneCallUrl(phoneNumber: string): string {
  const clean = normalizePhoneNumber(phoneNumber);
  return clean ? `tel:${clean}` : "";
}

export function loadDatabase(): AppDatabase {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.users === "object") {
        return parsed;
      }
    }
  } catch (e) {
    console.error("Failed to load local DB", e);
  }

  // Start with clean database
  const initialDb: AppDatabase = {
    users: {},
  };
  saveDatabase(initialDb);
  return initialDb;
}

export function saveDatabase(db: AppDatabase): void {
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
  } catch (e) {
    console.error("Failed to save local DB", e);
  }
}

/**
 * Returns currently active logged-in username if session exists, or empty string if not logged in.
 * Verifies session against local database to prevent ghost or invalid logins.
 */
export function getActiveUsername(): string {
  const stored = localStorage.getItem(SESSION_USER_KEY);
  if (!stored || !stored.trim()) return "";

  const clean = stored.trim().toLowerCase();
  const db = loadDatabase();
  for (const uname of Object.keys(db.users)) {
    if (uname.toLowerCase() === clean) {
      return uname;
    }
  }

  // If stored username no longer exists in DB, clear stale session
  localStorage.removeItem(SESSION_USER_KEY);
  return "";
}

/**
 * Persists or clears active session in device storage.
 */
export function setActiveUsername(username: string | null): void {
  if (username && username.trim()) {
    localStorage.setItem(SESSION_USER_KEY, username.trim());
  } else {
    localStorage.removeItem(SESSION_USER_KEY);
  }
}

/**
 * Retrieves isolated UserData for a specific account.
 * Ensures strict privacy: each user's patients, medicines, and history are isolated.
 */
export function getUserData(username: string): UserData {
  if (!username || !username.trim()) {
    return {
      username: "",
      email: "",
      guardian_phone: "",
      patients: {},
      medicines: [],
      history: [],
      sms_outbox: [],
      guardian_settings: { ...DEFAULT_GUARDIAN_SETTINGS },
    };
  }

  const clean = username.trim().toLowerCase();
  const db = loadDatabase();
  let user: (UserData & { passwordPlain?: string }) | undefined = db.users[username];

  if (!user) {
    for (const [k, u] of Object.entries(db.users)) {
      if (k.toLowerCase() === clean || (u.email && u.email.toLowerCase() === clean)) {
        user = u;
        break;
      }
    }
  }

  if (!user) {
    // Create new fresh isolated workspace for user
    const freshUser: UserData & { passwordPlain?: string } = {
      username: username.trim(),
      email: "",
      guardian_phone: "",
      patients: {},
      medicines: [],
      history: [],
      sms_outbox: [],
      guardian_settings: { ...DEFAULT_GUARDIAN_SETTINGS },
    };
    db.users[freshUser.username] = freshUser;
    saveDatabase(db);
    user = freshUser;
  }

  return {
    username: user.username,
    email: user.email || "",
    guardian_phone: user.guardian_phone || "",
    patients: user.patients || {},
    medicines: user.medicines || [],
    history: user.history || [],
    sms_outbox: user.sms_outbox || [],
    guardian_settings: user.guardian_settings || { ...DEFAULT_GUARDIAN_SETTINGS },
  };
}

export function saveUserData(data: UserData): void {
  if (!data.username || !data.username.trim()) return;
  const db = loadDatabase();
  const uname = data.username.trim();
  const existing = db.users[uname] || {};
  db.users[uname] = {
    ...existing,
    ...data,
    username: uname,
  };
  saveDatabase(db);
}

/**
 * Standard User Registration (Create Account):
 * Validates inputs, prevents duplicate names/emails (case-insensitive),
 * persists credentials locally, creates an isolated fresh workspace,
 * and seamlessly activates the user's session.
 */
export function registerUser(
  nameOrUsername: string,
  email: string,
  password: string
): { success: boolean; username?: string; message?: string } {
  const cleanName = (nameOrUsername || "").trim();
  const cleanEmail = (email || "").trim().toLowerCase();
  const cleanPass = (password || "").trim();

  if (!cleanName) {
    return { success: false, message: "Please enter your name or username." };
  }
  if (!cleanEmail || !cleanEmail.includes("@") || !cleanEmail.includes(".")) {
    return { success: false, message: "Please enter a valid email address." };
  }
  if (!cleanPass) {
    return { success: false, message: "Please enter a password." };
  }
  if (cleanPass.length < 6) {
    return { success: false, message: "Password must be at least 6 characters long." };
  }

  const db = loadDatabase();

  // Validate unique name and email
  for (const [u, val] of Object.entries(db.users)) {
    if (u.toLowerCase() === cleanName.toLowerCase()) {
      return {
        success: false,
        message: "An account with this name or username already exists. Please sign in or choose another name.",
      };
    }
    if (val.email && val.email.trim().toLowerCase() === cleanEmail) {
      return {
        success: false,
        message: "An account with this email address already exists. Please sign in.",
      };
    }
  }

  // Create isolated fresh workspace with empty patients and medicines
  const newUser: UserData & { passwordPlain: string } = {
    username: cleanName,
    email: cleanEmail,
    passwordPlain: cleanPass,
    guardian_phone: "",
    patients: {},
    medicines: [],
    history: [],
    sms_outbox: [],
    guardian_settings: { ...DEFAULT_GUARDIAN_SETTINGS },
  };

  db.users[cleanName] = newUser;
  saveDatabase(db);
  setActiveUsername(cleanName);

  return { success: true, username: cleanName };
}

/**
 * Robust User Authentication:
 * Compares credentials accurately with case-insensitive identifier (email or username)
 * matching and exact password matching (no bypasses).
 * Returns clear user-facing error messages on failure.
 */
export function authenticateUser(
  identifier: string,
  password: string
): { success: boolean; username?: string; message?: string } {
  const cleanId = (identifier || "").trim().toLowerCase();
  const cleanPass = (password || "").trim();

  if (!cleanId || !cleanPass) {
    return {
      success: false,
      message: "Please enter both your email/username and password.",
    };
  }

  const db = loadDatabase();
  let matchedUser: (UserData & { passwordPlain?: string }) | null = null;
  let matchedUsername = "";

  for (const [uname, user] of Object.entries(db.users)) {
    if (
      uname.toLowerCase() === cleanId ||
      (user.email && user.email.toLowerCase() === cleanId)
    ) {
      matchedUser = user;
      matchedUsername = user.username || uname;
      break;
    }
  }

  if (!matchedUser) {
    return {
      success: false,
      message: "Account not found. Please sign up.",
    };
  }

  // Exact password comparison without developer bypasses
  if (matchedUser.passwordPlain !== cleanPass) {
    return {
      success: false,
      message: "Incorrect password. Please try again.",
    };
  }

  // Persist session on device
  setActiveUsername(matchedUsername);
  return {
    success: true,
    username: matchedUsername,
  };
}
