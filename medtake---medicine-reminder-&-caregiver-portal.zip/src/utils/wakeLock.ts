/**
 * MedTake Screen Wake Lock API Manager
 *
 * Keeps the device display lit and CPU awake during:
 * 1. Bedside Clock Mode (nightstand medication watcher)
 * 2. Active Alarm Ringing (ensures screen stays awake while alarm is chiming & speaking)
 *
 * Automatically re-acquires the Wake Lock when the app regains visibility
 * (after being minimized, screen unlocked, or restored from background).
 */

type WakeLockReason = "bedside" | "alarm";

class WakeLockManager {
  private sentinel: any = null;
  private activeReasons = new Set<WakeLockReason>();
  private isAcquiring = false;
  private listeners = new Set<(active: boolean) => void>();

  constructor() {
    if (typeof window !== "undefined" && typeof document !== "undefined") {
      document.addEventListener("visibilitychange", this.handleVisibilityChange);
      window.addEventListener("focus", this.handleVisibilityChange);
      window.addEventListener("pageshow", this.handleVisibilityChange);
    }
  }

  /**
   * Check if the Screen Wake Lock API is supported by the current browser/device.
   */
  public isSupported(): boolean {
    return typeof navigator !== "undefined" && "wakeLock" in navigator;
  }

  /**
   * Check if a wake lock is actively held.
   */
  public isActive(): boolean {
    return this.sentinel !== null && !this.sentinel.released;
  }

  /**
   * Check if a specific reason (e.g. "bedside" or "alarm") is active.
   */
  public isReasonActive(reason: WakeLockReason): boolean {
    return this.activeReasons.has(reason);
  }

  /**
   * Request a wake lock for a given reason.
   */
  public async requestLock(reason: WakeLockReason): Promise<boolean> {
    this.activeReasons.add(reason);
    return this.acquire();
  }

  /**
   * Release a wake lock for a given reason.
   * Only releases the actual system sentinel if no other reasons remain active.
   */
  public async releaseLock(reason: WakeLockReason): Promise<void> {
    this.activeReasons.delete(reason);
    if (this.activeReasons.size === 0) {
      await this.releaseSentinel();
    }
  }

  /**
   * Toggle Bedside Clock mode wake lock.
   */
  public async toggleBedsideLock(): Promise<boolean> {
    if (this.activeReasons.has("bedside")) {
      await this.releaseLock("bedside");
      return false;
    } else {
      return await this.requestLock("bedside");
    }
  }

  private async acquire(): Promise<boolean> {
    if (!this.isSupported()) {
      this.notifyListeners(false);
      return false;
    }

    if (this.isActive()) {
      this.notifyListeners(true);
      return true;
    }

    if (this.isAcquiring) return false;
    this.isAcquiring = true;

    try {
      if (typeof document !== "undefined" && document.visibilityState === "visible") {
        const sentinel = await (navigator as any).wakeLock.request("screen");
        this.sentinel = sentinel;

        sentinel.addEventListener("release", () => {
          this.sentinel = null;
          this.notifyListeners(false);
        });

        this.notifyListeners(true);
        return true;
      }
    } catch (err: any) {
      console.warn("[WakeLock] Request failed or disallowed in background:", err?.message || err);
    } finally {
      this.isAcquiring = false;
    }

    return false;
  }

  private async releaseSentinel(): Promise<void> {
    if (this.sentinel) {
      try {
        await this.sentinel.release();
      } catch (err) {
        console.warn("[WakeLock] Error releasing sentinel:", err);
      }
      this.sentinel = null;
    }
    this.notifyListeners(false);
  }

  /**
   * Automatically re-acquire the Wake Lock when the page becomes visible again.
   * Browsers release the wake lock when the tab is minimized or device is locked.
   */
  private handleVisibilityChange = async () => {
    if (typeof document === "undefined") return;
    if (document.visibilityState === "visible" && this.activeReasons.size > 0) {
      await this.acquire();
    }
  };

  /**
   * Subscribe to wake lock state changes.
   */
  public subscribe(listener: (active: boolean) => void): () => void {
    this.listeners.add(listener);
    listener(this.isActive());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(active: boolean) {
    this.listeners.forEach((fn) => {
      try {
        fn(active);
      } catch (err) {
        console.error("[WakeLock] Listener error:", err);
      }
    });
  }
}

export const wakeLockManager = new WakeLockManager();

import { useState, useEffect } from "react";

export function useWakeLock() {
  const [isSupported] = useState(() => wakeLockManager.isSupported());
  const [isActive, setIsActive] = useState(() => wakeLockManager.isActive());
  const [isBedsideActive, setIsBedsideActive] = useState(() =>
    wakeLockManager.isReasonActive("bedside")
  );

  useEffect(() => {
    return wakeLockManager.subscribe((active) => {
      setIsActive(active);
      setIsBedsideActive(wakeLockManager.isReasonActive("bedside"));
    });
  }, []);

  const toggleBedside = async () => {
    const res = await wakeLockManager.toggleBedsideLock();
    setIsBedsideActive(res);
    return res;
  };

  const requestLock = (reason: "bedside" | "alarm") =>
    wakeLockManager.requestLock(reason);
  const releaseLock = (reason: "bedside" | "alarm") =>
    wakeLockManager.releaseLock(reason);

  return {
    isSupported,
    isActive,
    isBedsideActive,
    toggleBedside,
    requestLock,
    releaseLock,
  };
}
